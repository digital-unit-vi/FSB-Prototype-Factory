import "expose-loader?exposes=React!react";
import "expose-loader?exposes=ReactDOM!react-dom";

import "expose-loader?exposes=Vorwerk!./build-assets/libraryExport.js";

import {Button} from './build-assets/libraryExport.js';

console.log(Button);