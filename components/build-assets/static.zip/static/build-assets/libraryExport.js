import * as P from "react";
import v, { useCallback as ue, createContext as de, useMemo as fe, createElement as D, useContext as H, useLayoutEffect as Er, useRef as A, useEffect as k, useState as B, forwardRef as K, Children as ce, isValidElement as je, cloneElement as Pe, Fragment as Go, useReducer as cc, useInsertionEffect as Ko, useId as Sr, useImperativeHandle as lc } from "react";
import { flushSync as Zo, createPortal as uc } from "react-dom";
var Ot = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function dc(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
function fc(e) {
  var t = typeof e;
  return e != null && (t == "object" || t == "function");
}
var Yo = fc, hc = typeof Ot == "object" && Ot && Ot.Object === Object && Ot, mc = hc, pc = mc, vc = typeof self == "object" && self && self.Object === Object && self, gc = pc || vc || Function("return this")(), Xo = gc, yc = Xo, bc = function() {
  return yc.Date.now();
}, wc = bc, Ec = /\s/;
function Sc(e) {
  for (var t = e.length; t-- && Ec.test(e.charAt(t)); )
    ;
  return t;
}
var xc = Sc, Cc = xc, Tc = /^\s+/;
function Pc(e) {
  return e && e.slice(0, Cc(e) + 1).replace(Tc, "");
}
var _c = Pc, Rc = Xo, Ac = Rc.Symbol, Qo = Ac, ni = Qo, Jo = Object.prototype, Dc = Jo.hasOwnProperty, Mc = Jo.toString, ft = ni ? ni.toStringTag : void 0;
function kc(e) {
  var t = Dc.call(e, ft), n = e[ft];
  try {
    e[ft] = void 0;
    var r = !0;
  } catch {
  }
  var i = Mc.call(e);
  return r && (t ? e[ft] = n : delete e[ft]), i;
}
var $c = kc, Vc = Object.prototype, Lc = Vc.toString;
function Nc(e) {
  return Lc.call(e);
}
var Oc = Nc, ri = Qo, qc = $c, Bc = Oc, Fc = "[object Null]", Ic = "[object Undefined]", ii = ri ? ri.toStringTag : void 0;
function zc(e) {
  return e == null ? e === void 0 ? Ic : Fc : ii && ii in Object(e) ? qc(e) : Bc(e);
}
var jc = zc;
function Hc(e) {
  return e != null && typeof e == "object";
}
var Wc = Hc, Uc = jc, Gc = Wc, Kc = "[object Symbol]";
function Zc(e) {
  return typeof e == "symbol" || Gc(e) && Uc(e) == Kc;
}
var Yc = Zc, Xc = _c, oi = Yo, Qc = Yc, si = 0 / 0, Jc = /^[-+]0x[0-9a-f]+$/i, el = /^0b[01]+$/i, tl = /^0o[0-7]+$/i, nl = parseInt;
function rl(e) {
  if (typeof e == "number")
    return e;
  if (Qc(e))
    return si;
  if (oi(e)) {
    var t = typeof e.valueOf == "function" ? e.valueOf() : e;
    e = oi(t) ? t + "" : t;
  }
  if (typeof e != "string")
    return e === 0 ? e : +e;
  e = Xc(e);
  var n = el.test(e);
  return n || tl.test(e) ? nl(e.slice(2), n ? 2 : 8) : Jc.test(e) ? si : +e;
}
var il = rl, ol = Yo, _n = wc, ai = il, sl = "Expected a function", al = Math.max, cl = Math.min;
function ll(e, t, n) {
  var r, i, o, s, a, c, l = 0, u = !1, d = !1, f = !0;
  if (typeof e != "function")
    throw new TypeError(sl);
  t = ai(t) || 0, ol(n) && (u = !!n.leading, d = "maxWait" in n, o = d ? al(ai(n.maxWait) || 0, t) : o, f = "trailing" in n ? !!n.trailing : f);
  function h(C) {
    var T = r, S = i;
    return r = i = void 0, l = C, s = e.apply(S, T), s;
  }
  function p(C) {
    return l = C, a = setTimeout(w, t), u ? h(C) : s;
  }
  function m(C) {
    var T = C - c, S = C - l, R = t - T;
    return d ? cl(R, o - S) : R;
  }
  function b(C) {
    var T = C - c, S = C - l;
    return c === void 0 || T >= t || T < 0 || d && S >= o;
  }
  function w() {
    var C = _n();
    if (b(C))
      return y(C);
    a = setTimeout(w, m(C));
  }
  function y(C) {
    return a = void 0, f && r ? h(C) : (r = i = void 0, s);
  }
  function g() {
    a !== void 0 && clearTimeout(a), l = 0, r = c = i = a = void 0;
  }
  function E() {
    return a === void 0 ? s : y(_n());
  }
  function x() {
    var C = _n(), T = b(C);
    if (r = arguments, i = this, c = C, T) {
      if (a === void 0)
        return p(c);
      if (d)
        return clearTimeout(a), a = setTimeout(w, t), h(c);
    }
    return a === void 0 && (a = setTimeout(w, t)), s;
  }
  return x.cancel = g, x.flush = E, x;
}
var ul = ll;
const es = /* @__PURE__ */ dc(ul), L = (...e) => (e == null ? void 0 : e.filter((n) => typeof n != "string" || !n.length ? !1 : n.trim())).join(" ").trim();
var Ne = "eit9bw1";
var ts = "isActive", dl = "_1qyxb2gf", Rn = { transparent: "_1qyxb2gb _1qyxb2ga", invertedTransparent: "_1qyxb2gc _1qyxb2ga", blackGradient: "_1qyxb2gd _1qyxb2ga", solidWhite: "_1qyxb2ge _1qyxb2ga" }, ns = "_1qyxb2g9", fl = "_1qyxb2g4", hl = "_1qyxb2g2", ml = "_1qyxb2g3", pl = { sticky: "_1qyxb2g5 _1qyxb2g0", normal: "_1qyxb2g6 _1qyxb2g0", semiSticky: "_1qyxb2g7 _1qyxb2g0" }, ci = "_1qyxb2g1", vl = "_1qyxb2g8", gl = "w5nxqn2", yl = "w5nxqn0", bl = "w5nxqn1";
const Qn = ({
  label: e,
  children: t,
  count: n,
  ...r
}) => /* @__PURE__ */ React.createElement("button", { className: yl, ...r }, n && /* @__PURE__ */ React.createElement("span", { className: gl }, n), t, /* @__PURE__ */ React.createElement("span", { className: bl }, e)), wl = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "M3.02 4.6h17.96v1.8H3.02V4.6Zm0 6.5h17.96v1.8H3.02v-1.8Zm0 6.5h17.96v1.8H3.02v-1.8Z",
      fill: "currentColor",
      fillRule: "evenodd"
    }
  )
);
function ee() {
  return ee = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var n = arguments[t];
      for (var r in n)
        Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
    }
    return e;
  }, ee.apply(this, arguments);
}
function ot(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
  return function(i) {
    if (e == null || e(i), n === !1 || !i.defaultPrevented)
      return t == null ? void 0 : t(i);
  };
}
function El(e, t) {
  typeof e == "function" ? e(t) : e != null && (e.current = t);
}
function rs(...e) {
  return (t) => e.forEach(
    (n) => El(n, t)
  );
}
function Rt(...e) {
  return ue(rs(...e), e);
}
function Sl(e, t = []) {
  let n = [];
  function r(o, s) {
    const a = /* @__PURE__ */ de(s), c = n.length;
    n = [
      ...n,
      s
    ];
    function l(d) {
      const { scope: f, children: h, ...p } = d, m = (f == null ? void 0 : f[e][c]) || a, b = fe(
        () => p,
        Object.values(p)
      );
      return /* @__PURE__ */ D(m.Provider, {
        value: b
      }, h);
    }
    function u(d, f) {
      const h = (f == null ? void 0 : f[e][c]) || a, p = H(h);
      if (p)
        return p;
      if (s !== void 0)
        return s;
      throw new Error(`\`${d}\` must be used within \`${o}\``);
    }
    return l.displayName = o + "Provider", [
      l,
      u
    ];
  }
  const i = () => {
    const o = n.map((s) => /* @__PURE__ */ de(s));
    return function(a) {
      const c = (a == null ? void 0 : a[e]) || o;
      return fe(
        () => ({
          [`__scope${e}`]: {
            ...a,
            [e]: c
          }
        }),
        [
          a,
          c
        ]
      );
    };
  };
  return i.scopeName = e, [
    r,
    xl(i, ...t)
  ];
}
function xl(...e) {
  const t = e[0];
  if (e.length === 1)
    return t;
  const n = () => {
    const r = e.map(
      (i) => ({
        useScope: i(),
        scopeName: i.scopeName
      })
    );
    return function(o) {
      const s = r.reduce((a, { useScope: c, scopeName: l }) => {
        const d = c(o)[`__scope${l}`];
        return {
          ...a,
          ...d
        };
      }, {});
      return fe(
        () => ({
          [`__scope${t.scopeName}`]: s
        }),
        [
          s
        ]
      );
    };
  };
  return n.scopeName = t.scopeName, n;
}
const Jn = globalThis != null && globalThis.document ? Er : () => {
}, Cl = P["useId".toString()] || (() => {
});
let Tl = 0;
function An(e) {
  const [t, n] = P.useState(Cl());
  return Jn(() => {
    e || n(
      (r) => r ?? String(Tl++)
    );
  }, [
    e
  ]), e || (t ? `radix-${t}` : "");
}
function He(e) {
  const t = A(e);
  return k(() => {
    t.current = e;
  }), fe(
    () => (...n) => {
      var r;
      return (r = t.current) === null || r === void 0 ? void 0 : r.call(t, ...n);
    },
    []
  );
}
function Pl({ prop: e, defaultProp: t, onChange: n = () => {
} }) {
  const [r, i] = _l({
    defaultProp: t,
    onChange: n
  }), o = e !== void 0, s = o ? e : r, a = He(n), c = ue((l) => {
    if (o) {
      const d = typeof l == "function" ? l(e) : l;
      d !== e && a(d);
    } else
      i(l);
  }, [
    o,
    e,
    i,
    a
  ]);
  return [
    s,
    c
  ];
}
function _l({ defaultProp: e, onChange: t }) {
  const n = B(e), [r] = n, i = A(r), o = He(t);
  return k(() => {
    i.current !== r && (o(r), i.current = r);
  }, [
    r,
    i,
    o
  ]), n;
}
const xr = /* @__PURE__ */ K((e, t) => {
  const { children: n, ...r } = e, i = ce.toArray(n), o = i.find(Al);
  if (o) {
    const s = o.props.children, a = i.map((c) => c === o ? ce.count(s) > 1 ? ce.only(null) : /* @__PURE__ */ je(s) ? s.props.children : null : c);
    return /* @__PURE__ */ D(er, ee({}, r, {
      ref: t
    }), /* @__PURE__ */ je(s) ? /* @__PURE__ */ Pe(s, void 0, a) : null);
  }
  return /* @__PURE__ */ D(er, ee({}, r, {
    ref: t
  }), n);
});
xr.displayName = "Slot";
const er = /* @__PURE__ */ K((e, t) => {
  const { children: n, ...r } = e;
  return /* @__PURE__ */ je(n) ? /* @__PURE__ */ Pe(n, {
    ...Dl(r, n.props),
    ref: t ? rs(t, n.ref) : n.ref
  }) : ce.count(n) > 1 ? ce.only(null) : null;
});
er.displayName = "SlotClone";
const Rl = ({ children: e }) => /* @__PURE__ */ D(Go, null, e);
function Al(e) {
  return /* @__PURE__ */ je(e) && e.type === Rl;
}
function Dl(e, t) {
  const n = {
    ...t
  };
  for (const r in t) {
    const i = e[r], o = t[r];
    /^on[A-Z]/.test(r) ? i && o ? n[r] = (...a) => {
      o(...a), i(...a);
    } : i && (n[r] = i) : r === "style" ? n[r] = {
      ...i,
      ...o
    } : r === "className" && (n[r] = [
      i,
      o
    ].filter(Boolean).join(" "));
  }
  return {
    ...e,
    ...n
  };
}
const Ml = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
], Cr = Ml.reduce((e, t) => {
  const n = /* @__PURE__ */ K((r, i) => {
    const { asChild: o, ...s } = r, a = o ? xr : t;
    return k(() => {
      window[Symbol.for("radix-ui")] = !0;
    }, []), /* @__PURE__ */ D(a, ee({}, s, {
      ref: i
    }));
  });
  return n.displayName = `Primitive.${t}`, {
    ...e,
    [t]: n
  };
}, {});
function kl(e, t) {
  e && Zo(
    () => e.dispatchEvent(t)
  );
}
function $l(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = He(e);
  k(() => {
    const r = (i) => {
      i.key === "Escape" && n(i);
    };
    return t.addEventListener("keydown", r), () => t.removeEventListener("keydown", r);
  }, [
    n,
    t
  ]);
}
const tr = "dismissableLayer.update", Vl = "dismissableLayer.pointerDownOutside", Ll = "dismissableLayer.focusOutside";
let li;
const Nl = /* @__PURE__ */ de({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), Ol = /* @__PURE__ */ K((e, t) => {
  var n;
  const { disableOutsidePointerEvents: r = !1, onEscapeKeyDown: i, onPointerDownOutside: o, onFocusOutside: s, onInteractOutside: a, onDismiss: c, ...l } = e, u = H(Nl), [d, f] = B(null), h = (n = d == null ? void 0 : d.ownerDocument) !== null && n !== void 0 ? n : globalThis == null ? void 0 : globalThis.document, [, p] = B({}), m = Rt(
    t,
    (S) => f(S)
  ), b = Array.from(u.layers), [w] = [
    ...u.layersWithOutsidePointerEventsDisabled
  ].slice(-1), y = b.indexOf(w), g = d ? b.indexOf(d) : -1, E = u.layersWithOutsidePointerEventsDisabled.size > 0, x = g >= y, C = ql((S) => {
    const R = S.target, N = [
      ...u.branches
    ].some(
      (W) => W.contains(R)
    );
    !x || N || (o == null || o(S), a == null || a(S), S.defaultPrevented || c == null || c());
  }, h), T = Bl((S) => {
    const R = S.target;
    [
      ...u.branches
    ].some(
      (W) => W.contains(R)
    ) || (s == null || s(S), a == null || a(S), S.defaultPrevented || c == null || c());
  }, h);
  return $l((S) => {
    g === u.layers.size - 1 && (i == null || i(S), !S.defaultPrevented && c && (S.preventDefault(), c()));
  }, h), k(() => {
    if (d)
      return r && (u.layersWithOutsidePointerEventsDisabled.size === 0 && (li = h.body.style.pointerEvents, h.body.style.pointerEvents = "none"), u.layersWithOutsidePointerEventsDisabled.add(d)), u.layers.add(d), ui(), () => {
        r && u.layersWithOutsidePointerEventsDisabled.size === 1 && (h.body.style.pointerEvents = li);
      };
  }, [
    d,
    h,
    r,
    u
  ]), k(() => () => {
    d && (u.layers.delete(d), u.layersWithOutsidePointerEventsDisabled.delete(d), ui());
  }, [
    d,
    u
  ]), k(() => {
    const S = () => p({});
    return document.addEventListener(tr, S), () => document.removeEventListener(tr, S);
  }, []), /* @__PURE__ */ D(Cr.div, ee({}, l, {
    ref: m,
    style: {
      pointerEvents: E ? x ? "auto" : "none" : void 0,
      ...e.style
    },
    onFocusCapture: ot(e.onFocusCapture, T.onFocusCapture),
    onBlurCapture: ot(e.onBlurCapture, T.onBlurCapture),
    onPointerDownCapture: ot(e.onPointerDownCapture, C.onPointerDownCapture)
  }));
});
function ql(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = He(e), r = A(!1), i = A(() => {
  });
  return k(() => {
    const o = (a) => {
      if (a.target && !r.current) {
        let l = function() {
          is(Vl, n, c, {
            discrete: !0
          });
        };
        const c = {
          originalEvent: a
        };
        a.pointerType === "touch" ? (t.removeEventListener("click", i.current), i.current = l, t.addEventListener("click", i.current, {
          once: !0
        })) : l();
      } else
        t.removeEventListener("click", i.current);
      r.current = !1;
    }, s = window.setTimeout(() => {
      t.addEventListener("pointerdown", o);
    }, 0);
    return () => {
      window.clearTimeout(s), t.removeEventListener("pointerdown", o), t.removeEventListener("click", i.current);
    };
  }, [
    t,
    n
  ]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => r.current = !0
  };
}
function Bl(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = He(e), r = A(!1);
  return k(() => {
    const i = (o) => {
      o.target && !r.current && is(Ll, n, {
        originalEvent: o
      }, {
        discrete: !1
      });
    };
    return t.addEventListener("focusin", i), () => t.removeEventListener("focusin", i);
  }, [
    t,
    n
  ]), {
    onFocusCapture: () => r.current = !0,
    onBlurCapture: () => r.current = !1
  };
}
function ui() {
  const e = new CustomEvent(tr);
  document.dispatchEvent(e);
}
function is(e, t, n, { discrete: r }) {
  const i = n.originalEvent.target, o = new CustomEvent(e, {
    bubbles: !1,
    cancelable: !0,
    detail: n
  });
  t && i.addEventListener(e, t, {
    once: !0
  }), r ? kl(i, o) : i.dispatchEvent(o);
}
const Dn = "focusScope.autoFocusOnMount", Mn = "focusScope.autoFocusOnUnmount", di = {
  bubbles: !1,
  cancelable: !0
}, Fl = /* @__PURE__ */ K((e, t) => {
  const { loop: n = !1, trapped: r = !1, onMountAutoFocus: i, onUnmountAutoFocus: o, ...s } = e, [a, c] = B(null), l = He(i), u = He(o), d = A(null), f = Rt(
    t,
    (m) => c(m)
  ), h = A({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  k(() => {
    if (r) {
      let m = function(g) {
        if (h.paused || !a)
          return;
        const E = g.target;
        a.contains(E) ? d.current = E : Ae(d.current, {
          select: !0
        });
      }, b = function(g) {
        if (h.paused || !a)
          return;
        const E = g.relatedTarget;
        E !== null && (a.contains(E) || Ae(d.current, {
          select: !0
        }));
      }, w = function(g) {
        if (document.activeElement === document.body)
          for (const x of g)
            x.removedNodes.length > 0 && Ae(a);
      };
      document.addEventListener("focusin", m), document.addEventListener("focusout", b);
      const y = new MutationObserver(w);
      return a && y.observe(a, {
        childList: !0,
        subtree: !0
      }), () => {
        document.removeEventListener("focusin", m), document.removeEventListener("focusout", b), y.disconnect();
      };
    }
  }, [
    r,
    a,
    h.paused
  ]), k(() => {
    if (a) {
      hi.add(h);
      const m = document.activeElement;
      if (!a.contains(m)) {
        const w = new CustomEvent(Dn, di);
        a.addEventListener(Dn, l), a.dispatchEvent(w), w.defaultPrevented || (Il(Ul(os(a)), {
          select: !0
        }), document.activeElement === m && Ae(a));
      }
      return () => {
        a.removeEventListener(Dn, l), setTimeout(() => {
          const w = new CustomEvent(Mn, di);
          a.addEventListener(Mn, u), a.dispatchEvent(w), w.defaultPrevented || Ae(m ?? document.body, {
            select: !0
          }), a.removeEventListener(Mn, u), hi.remove(h);
        }, 0);
      };
    }
  }, [
    a,
    l,
    u,
    h
  ]);
  const p = ue((m) => {
    if (!n && !r || h.paused)
      return;
    const b = m.key === "Tab" && !m.altKey && !m.ctrlKey && !m.metaKey, w = document.activeElement;
    if (b && w) {
      const y = m.currentTarget, [g, E] = zl(y);
      g && E ? !m.shiftKey && w === E ? (m.preventDefault(), n && Ae(g, {
        select: !0
      })) : m.shiftKey && w === g && (m.preventDefault(), n && Ae(E, {
        select: !0
      })) : w === y && m.preventDefault();
    }
  }, [
    n,
    r,
    h.paused
  ]);
  return /* @__PURE__ */ D(Cr.div, ee({
    tabIndex: -1
  }, s, {
    ref: f,
    onKeyDown: p
  }));
});
function Il(e, { select: t = !1 } = {}) {
  const n = document.activeElement;
  for (const r of e)
    if (Ae(r, {
      select: t
    }), document.activeElement !== n)
      return;
}
function zl(e) {
  const t = os(e), n = fi(t, e), r = fi(t.reverse(), e);
  return [
    n,
    r
  ];
}
function os(e) {
  const t = [], n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (r) => {
      const i = r.tagName === "INPUT" && r.type === "hidden";
      return r.disabled || r.hidden || i ? NodeFilter.FILTER_SKIP : r.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; n.nextNode(); )
    t.push(n.currentNode);
  return t;
}
function fi(e, t) {
  for (const n of e)
    if (!jl(n, {
      upTo: t
    }))
      return n;
}
function jl(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden")
    return !0;
  for (; e; ) {
    if (t !== void 0 && e === t)
      return !1;
    if (getComputedStyle(e).display === "none")
      return !0;
    e = e.parentElement;
  }
  return !1;
}
function Hl(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function Ae(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const n = document.activeElement;
    e.focus({
      preventScroll: !0
    }), e !== n && Hl(e) && t && e.select();
  }
}
const hi = Wl();
function Wl() {
  let e = [];
  return {
    add(t) {
      const n = e[0];
      t !== n && (n == null || n.pause()), e = mi(e, t), e.unshift(t);
    },
    remove(t) {
      var n;
      e = mi(e, t), (n = e[0]) === null || n === void 0 || n.resume();
    }
  };
}
function mi(e, t) {
  const n = [
    ...e
  ], r = n.indexOf(t);
  return r !== -1 && n.splice(r, 1), n;
}
function Ul(e) {
  return e.filter(
    (t) => t.tagName !== "A"
  );
}
function Gl(e, t) {
  return cc((n, r) => {
    const i = t[n][r];
    return i ?? n;
  }, e);
}
const Tr = (e) => {
  const { present: t, children: n } = e, r = Kl(t), i = typeof n == "function" ? n({
    present: r.isPresent
  }) : ce.only(n), o = Rt(r.ref, i.ref);
  return typeof n == "function" || r.isPresent ? /* @__PURE__ */ Pe(i, {
    ref: o
  }) : null;
};
Tr.displayName = "Presence";
function Kl(e) {
  const [t, n] = B(), r = A({}), i = A(e), o = A("none"), s = e ? "mounted" : "unmounted", [a, c] = Gl(s, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return k(() => {
    const l = qt(r.current);
    o.current = a === "mounted" ? l : "none";
  }, [
    a
  ]), Jn(() => {
    const l = r.current, u = i.current;
    if (u !== e) {
      const f = o.current, h = qt(l);
      e ? c("MOUNT") : h === "none" || (l == null ? void 0 : l.display) === "none" ? c("UNMOUNT") : c(u && f !== h ? "ANIMATION_OUT" : "UNMOUNT"), i.current = e;
    }
  }, [
    e,
    c
  ]), Jn(() => {
    if (t) {
      const l = (d) => {
        const h = qt(r.current).includes(d.animationName);
        d.target === t && h && Zo(
          () => c("ANIMATION_END")
        );
      }, u = (d) => {
        d.target === t && (o.current = qt(r.current));
      };
      return t.addEventListener("animationstart", u), t.addEventListener("animationcancel", l), t.addEventListener("animationend", l), () => {
        t.removeEventListener("animationstart", u), t.removeEventListener("animationcancel", l), t.removeEventListener("animationend", l);
      };
    } else
      c("ANIMATION_END");
  }, [
    t,
    c
  ]), {
    isPresent: [
      "mounted",
      "unmountSuspended"
    ].includes(a),
    ref: ue((l) => {
      l && (r.current = getComputedStyle(l)), n(l);
    }, [])
  };
}
function qt(e) {
  return (e == null ? void 0 : e.animationName) || "none";
}
let kn = 0;
function Zl() {
  k(() => {
    var e, t;
    const n = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", (e = n[0]) !== null && e !== void 0 ? e : pi()), document.body.insertAdjacentElement("beforeend", (t = n[1]) !== null && t !== void 0 ? t : pi()), kn++, () => {
      kn === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach(
        (r) => r.remove()
      ), kn--;
    };
  }, []);
}
function pi() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e;
}
var ge = function() {
  return ge = Object.assign || function(t) {
    for (var n, r = 1, i = arguments.length; r < i; r++) {
      n = arguments[r];
      for (var o in n)
        Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o]);
    }
    return t;
  }, ge.apply(this, arguments);
};
function ss(e, t) {
  var n = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
      t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
  return n;
}
function Yl(e, t, n) {
  if (n || arguments.length === 2)
    for (var r = 0, i = t.length, o; r < i; r++)
      (o || !(r in t)) && (o || (o = Array.prototype.slice.call(t, 0, r)), o[r] = t[r]);
  return e.concat(o || Array.prototype.slice.call(t));
}
var Yt = "right-scroll-bar-position", Xt = "width-before-scroll-bar", Xl = "with-scroll-bars-hidden", Ql = "--removed-body-scroll-bar-size";
function Jl(e, t) {
  return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
function eu(e, t) {
  var n = B(function() {
    return {
      // value
      value: e,
      // last callback
      callback: t,
      // "memoized" public interface
      facade: {
        get current() {
          return n.value;
        },
        set current(r) {
          var i = n.value;
          i !== r && (n.value = r, n.callback(r, i));
        }
      }
    };
  })[0];
  return n.callback = t, n.facade;
}
function tu(e, t) {
  return eu(t || null, function(n) {
    return e.forEach(function(r) {
      return Jl(r, n);
    });
  });
}
function nu(e) {
  return e;
}
function ru(e, t) {
  t === void 0 && (t = nu);
  var n = [], r = !1, i = {
    read: function() {
      if (r)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return n.length ? n[n.length - 1] : e;
    },
    useMedium: function(o) {
      var s = t(o, r);
      return n.push(s), function() {
        n = n.filter(function(a) {
          return a !== s;
        });
      };
    },
    assignSyncMedium: function(o) {
      for (r = !0; n.length; ) {
        var s = n;
        n = [], s.forEach(o);
      }
      n = {
        push: function(a) {
          return o(a);
        },
        filter: function() {
          return n;
        }
      };
    },
    assignMedium: function(o) {
      r = !0;
      var s = [];
      if (n.length) {
        var a = n;
        n = [], a.forEach(o), s = n;
      }
      var c = function() {
        var u = s;
        s = [], u.forEach(o);
      }, l = function() {
        return Promise.resolve().then(c);
      };
      l(), n = {
        push: function(u) {
          s.push(u), l();
        },
        filter: function(u) {
          return s = s.filter(u), n;
        }
      };
    }
  };
  return i;
}
function iu(e) {
  e === void 0 && (e = {});
  var t = ru(null);
  return t.options = ge({ async: !0, ssr: !1 }, e), t;
}
var as = function(e) {
  var t = e.sideCar, n = ss(e, ["sideCar"]);
  if (!t)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var r = t.read();
  if (!r)
    throw new Error("Sidecar medium not found");
  return P.createElement(r, ge({}, n));
};
as.isSideCarExport = !0;
function ou(e, t) {
  return e.useMedium(t), as;
}
var cs = iu(), $n = function() {
}, hn = P.forwardRef(function(e, t) {
  var n = P.useRef(null), r = P.useState({
    onScrollCapture: $n,
    onWheelCapture: $n,
    onTouchMoveCapture: $n
  }), i = r[0], o = r[1], s = e.forwardProps, a = e.children, c = e.className, l = e.removeScrollBar, u = e.enabled, d = e.shards, f = e.sideCar, h = e.noIsolation, p = e.inert, m = e.allowPinchZoom, b = e.as, w = b === void 0 ? "div" : b, y = ss(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as"]), g = f, E = tu([n, t]), x = ge(ge({}, y), i);
  return P.createElement(
    P.Fragment,
    null,
    u && P.createElement(g, { sideCar: cs, removeScrollBar: l, shards: d, noIsolation: h, inert: p, setCallbacks: o, allowPinchZoom: !!m, lockRef: n }),
    s ? P.cloneElement(P.Children.only(a), ge(ge({}, x), { ref: E })) : P.createElement(w, ge({}, x, { className: c, ref: E }), a)
  );
});
hn.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
hn.classNames = {
  fullWidth: Xt,
  zeroRight: Yt
};
var vi, su = function() {
  if (vi)
    return vi;
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function au() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = su();
  return t && e.setAttribute("nonce", t), e;
}
function cu(e, t) {
  e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function lu(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var uu = function() {
  var e = 0, t = null;
  return {
    add: function(n) {
      e == 0 && (t = au()) && (cu(t, n), lu(t)), e++;
    },
    remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    }
  };
}, du = function() {
  var e = uu();
  return function(t, n) {
    P.useEffect(function() {
      return e.add(t), function() {
        e.remove();
      };
    }, [t && n]);
  };
}, ls = function() {
  var e = du(), t = function(n) {
    var r = n.styles, i = n.dynamic;
    return e(r, i), null;
  };
  return t;
}, fu = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, Vn = function(e) {
  return parseInt(e || "", 10) || 0;
}, hu = function(e) {
  var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], i = t[e === "padding" ? "paddingRight" : "marginRight"];
  return [Vn(n), Vn(r), Vn(i)];
}, mu = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return fu;
  var t = hu(e), n = document.documentElement.clientWidth, r = window.innerWidth;
  return {
    left: t[0],
    top: t[1],
    right: t[2],
    gap: Math.max(0, r - n + t[2] - t[0])
  };
}, pu = ls(), vu = function(e, t, n, r) {
  var i = e.left, o = e.top, s = e.right, a = e.gap;
  return n === void 0 && (n = "margin"), `
  .`.concat(Xl, ` {
   overflow: hidden `).concat(r, `;
   padding-right: `).concat(a, "px ").concat(r, `;
  }
  body {
    overflow: hidden `).concat(r, `;
    overscroll-behavior: contain;
    `).concat([
    t && "position: relative ".concat(r, ";"),
    n === "margin" && `
    padding-left: `.concat(i, `px;
    padding-top: `).concat(o, `px;
    padding-right: `).concat(s, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(a, "px ").concat(r, `;
    `),
    n === "padding" && "padding-right: ".concat(a, "px ").concat(r, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(Yt, ` {
    right: `).concat(a, "px ").concat(r, `;
  }
  
  .`).concat(Xt, ` {
    margin-right: `).concat(a, "px ").concat(r, `;
  }
  
  .`).concat(Yt, " .").concat(Yt, ` {
    right: 0 `).concat(r, `;
  }
  
  .`).concat(Xt, " .").concat(Xt, ` {
    margin-right: 0 `).concat(r, `;
  }
  
  body {
    `).concat(Ql, ": ").concat(a, `px;
  }
`);
}, gu = function(e) {
  var t = e.noRelative, n = e.noImportant, r = e.gapMode, i = r === void 0 ? "margin" : r, o = P.useMemo(function() {
    return mu(i);
  }, [i]);
  return P.createElement(pu, { styles: vu(o, !t, i, n ? "" : "!important") });
}, nr = !1;
if (typeof window < "u")
  try {
    var Bt = Object.defineProperty({}, "passive", {
      get: function() {
        return nr = !0, !0;
      }
    });
    window.addEventListener("test", Bt, Bt), window.removeEventListener("test", Bt, Bt);
  } catch {
    nr = !1;
  }
var Xe = nr ? { passive: !1 } : !1, yu = function(e) {
  return e.tagName === "TEXTAREA";
}, us = function(e, t) {
  var n = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    n[t] !== "hidden" && // contains scroll inside self
    !(n.overflowY === n.overflowX && !yu(e) && n[t] === "visible")
  );
}, bu = function(e) {
  return us(e, "overflowY");
}, wu = function(e) {
  return us(e, "overflowX");
}, gi = function(e, t) {
  var n = t;
  do {
    typeof ShadowRoot < "u" && n instanceof ShadowRoot && (n = n.host);
    var r = ds(e, n);
    if (r) {
      var i = fs(e, n), o = i[1], s = i[2];
      if (o > s)
        return !0;
    }
    n = n.parentNode;
  } while (n && n !== document.body);
  return !1;
}, Eu = function(e) {
  var t = e.scrollTop, n = e.scrollHeight, r = e.clientHeight;
  return [
    t,
    n,
    r
  ];
}, Su = function(e) {
  var t = e.scrollLeft, n = e.scrollWidth, r = e.clientWidth;
  return [
    t,
    n,
    r
  ];
}, ds = function(e, t) {
  return e === "v" ? bu(t) : wu(t);
}, fs = function(e, t) {
  return e === "v" ? Eu(t) : Su(t);
}, xu = function(e, t) {
  return e === "h" && t === "rtl" ? -1 : 1;
}, Cu = function(e, t, n, r, i) {
  var o = xu(e, window.getComputedStyle(t).direction), s = o * r, a = n.target, c = t.contains(a), l = !1, u = s > 0, d = 0, f = 0;
  do {
    var h = fs(e, a), p = h[0], m = h[1], b = h[2], w = m - b - o * p;
    (p || w) && ds(e, a) && (d += w, f += p), a = a.parentNode;
  } while (
    // portaled content
    !c && a !== document.body || // self content
    c && (t.contains(a) || t === a)
  );
  return (u && (i && d === 0 || !i && s > d) || !u && (i && f === 0 || !i && -s > f)) && (l = !0), l;
}, Ft = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, yi = function(e) {
  return [e.deltaX, e.deltaY];
}, bi = function(e) {
  return e && "current" in e ? e.current : e;
}, Tu = function(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}, Pu = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, _u = 0, Qe = [];
function Ru(e) {
  var t = P.useRef([]), n = P.useRef([0, 0]), r = P.useRef(), i = P.useState(_u++)[0], o = P.useState(function() {
    return ls();
  })[0], s = P.useRef(e);
  P.useEffect(function() {
    s.current = e;
  }, [e]), P.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(i));
      var m = Yl([e.lockRef.current], (e.shards || []).map(bi), !0).filter(Boolean);
      return m.forEach(function(b) {
        return b.classList.add("allow-interactivity-".concat(i));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(i)), m.forEach(function(b) {
          return b.classList.remove("allow-interactivity-".concat(i));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var a = P.useCallback(function(m, b) {
    if ("touches" in m && m.touches.length === 2)
      return !s.current.allowPinchZoom;
    var w = Ft(m), y = n.current, g = "deltaX" in m ? m.deltaX : y[0] - w[0], E = "deltaY" in m ? m.deltaY : y[1] - w[1], x, C = m.target, T = Math.abs(g) > Math.abs(E) ? "h" : "v";
    if ("touches" in m && T === "h" && C.type === "range")
      return !1;
    var S = gi(T, C);
    if (!S)
      return !0;
    if (S ? x = T : (x = T === "v" ? "h" : "v", S = gi(T, C)), !S)
      return !1;
    if (!r.current && "changedTouches" in m && (g || E) && (r.current = x), !x)
      return !0;
    var R = r.current || x;
    return Cu(R, b, m, R === "h" ? g : E, !0);
  }, []), c = P.useCallback(function(m) {
    var b = m;
    if (!(!Qe.length || Qe[Qe.length - 1] !== o)) {
      var w = "deltaY" in b ? yi(b) : Ft(b), y = t.current.filter(function(x) {
        return x.name === b.type && x.target === b.target && Tu(x.delta, w);
      })[0];
      if (y && y.should) {
        b.cancelable && b.preventDefault();
        return;
      }
      if (!y) {
        var g = (s.current.shards || []).map(bi).filter(Boolean).filter(function(x) {
          return x.contains(b.target);
        }), E = g.length > 0 ? a(b, g[0]) : !s.current.noIsolation;
        E && b.cancelable && b.preventDefault();
      }
    }
  }, []), l = P.useCallback(function(m, b, w, y) {
    var g = { name: m, delta: b, target: w, should: y };
    t.current.push(g), setTimeout(function() {
      t.current = t.current.filter(function(E) {
        return E !== g;
      });
    }, 1);
  }, []), u = P.useCallback(function(m) {
    n.current = Ft(m), r.current = void 0;
  }, []), d = P.useCallback(function(m) {
    l(m.type, yi(m), m.target, a(m, e.lockRef.current));
  }, []), f = P.useCallback(function(m) {
    l(m.type, Ft(m), m.target, a(m, e.lockRef.current));
  }, []);
  P.useEffect(function() {
    return Qe.push(o), e.setCallbacks({
      onScrollCapture: d,
      onWheelCapture: d,
      onTouchMoveCapture: f
    }), document.addEventListener("wheel", c, Xe), document.addEventListener("touchmove", c, Xe), document.addEventListener("touchstart", u, Xe), function() {
      Qe = Qe.filter(function(m) {
        return m !== o;
      }), document.removeEventListener("wheel", c, Xe), document.removeEventListener("touchmove", c, Xe), document.removeEventListener("touchstart", u, Xe);
    };
  }, []);
  var h = e.removeScrollBar, p = e.inert;
  return P.createElement(
    P.Fragment,
    null,
    p ? P.createElement(o, { styles: Pu(i) }) : null,
    h ? P.createElement(gu, { gapMode: "margin" }) : null
  );
}
const Au = ou(cs, Ru);
var hs = P.forwardRef(function(e, t) {
  return P.createElement(hn, ge({}, e, { ref: t, sideCar: Au }));
});
hs.classNames = hn.classNames;
const Du = hs;
var Mu = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, Je = /* @__PURE__ */ new WeakMap(), It = /* @__PURE__ */ new WeakMap(), zt = {}, Ln = 0, ms = function(e) {
  return e && (e.host || ms(e.parentNode));
}, ku = function(e, t) {
  return t.map(function(n) {
    if (e.contains(n))
      return n;
    var r = ms(n);
    return r && e.contains(r) ? r : (console.error("aria-hidden", n, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(n) {
    return !!n;
  });
}, $u = function(e, t, n, r) {
  var i = ku(t, Array.isArray(e) ? e : [e]);
  zt[n] || (zt[n] = /* @__PURE__ */ new WeakMap());
  var o = zt[n], s = [], a = /* @__PURE__ */ new Set(), c = new Set(i), l = function(d) {
    !d || a.has(d) || (a.add(d), l(d.parentNode));
  };
  i.forEach(l);
  var u = function(d) {
    !d || c.has(d) || Array.prototype.forEach.call(d.children, function(f) {
      if (a.has(f))
        u(f);
      else {
        var h = f.getAttribute(r), p = h !== null && h !== "false", m = (Je.get(f) || 0) + 1, b = (o.get(f) || 0) + 1;
        Je.set(f, m), o.set(f, b), s.push(f), m === 1 && p && It.set(f, !0), b === 1 && f.setAttribute(n, "true"), p || f.setAttribute(r, "true");
      }
    });
  };
  return u(t), a.clear(), Ln++, function() {
    s.forEach(function(d) {
      var f = Je.get(d) - 1, h = o.get(d) - 1;
      Je.set(d, f), o.set(d, h), f || (It.has(d) || d.removeAttribute(r), It.delete(d)), h || d.removeAttribute(n);
    }), Ln--, Ln || (Je = /* @__PURE__ */ new WeakMap(), Je = /* @__PURE__ */ new WeakMap(), It = /* @__PURE__ */ new WeakMap(), zt = {});
  };
}, Vu = function(e, t, n) {
  n === void 0 && (n = "data-aria-hidden");
  var r = Array.from(Array.isArray(e) ? e : [e]), i = t || Mu(e);
  return i ? (r.push.apply(r, Array.from(i.querySelectorAll("[aria-live]"))), $u(r, i, n, "aria-hidden")) : function() {
    return null;
  };
};
const ps = "Dialog", [vs, dg] = Sl(ps), [Lu, lt] = vs(ps), Nu = (e) => {
  const { __scopeDialog: t, children: n, open: r, defaultOpen: i, onOpenChange: o, modal: s = !0 } = e, a = A(null), c = A(null), [l = !1, u] = Pl({
    prop: r,
    defaultProp: i,
    onChange: o
  });
  return /* @__PURE__ */ D(Lu, {
    scope: t,
    triggerRef: a,
    contentRef: c,
    contentId: An(),
    titleId: An(),
    descriptionId: An(),
    open: l,
    onOpenChange: u,
    onOpenToggle: ue(
      () => u(
        (d) => !d
      ),
      [
        u
      ]
    ),
    modal: s
  }, n);
}, Ou = "DialogPortal", [fg, gs] = vs(Ou, {
  forceMount: void 0
}), rr = "DialogOverlay", qu = /* @__PURE__ */ K((e, t) => {
  const n = gs(rr, e.__scopeDialog), { forceMount: r = n.forceMount, ...i } = e, o = lt(rr, e.__scopeDialog);
  return o.modal ? /* @__PURE__ */ D(Tr, {
    present: r || o.open
  }, /* @__PURE__ */ D(Bu, ee({}, i, {
    ref: t
  }))) : null;
}), Bu = /* @__PURE__ */ K((e, t) => {
  const { __scopeDialog: n, ...r } = e, i = lt(rr, n);
  return (
    // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
    // ie. when `Overlay` and `Content` are siblings
    /* @__PURE__ */ D(Du, {
      as: xr,
      allowPinchZoom: !0,
      shards: [
        i.contentRef
      ]
    }, /* @__PURE__ */ D(Cr.div, ee({
      "data-state": bs(i.open)
    }, r, {
      ref: t,
      style: {
        pointerEvents: "auto",
        ...r.style
      }
    })))
  );
}), Ct = "DialogContent", Fu = /* @__PURE__ */ K((e, t) => {
  const n = gs(Ct, e.__scopeDialog), { forceMount: r = n.forceMount, ...i } = e, o = lt(Ct, e.__scopeDialog);
  return /* @__PURE__ */ D(Tr, {
    present: r || o.open
  }, o.modal ? /* @__PURE__ */ D(Iu, ee({}, i, {
    ref: t
  })) : /* @__PURE__ */ D(zu, ee({}, i, {
    ref: t
  })));
}), Iu = /* @__PURE__ */ K((e, t) => {
  const n = lt(Ct, e.__scopeDialog), r = A(null), i = Rt(t, n.contentRef, r);
  return k(() => {
    const o = r.current;
    if (o)
      return Vu(o);
  }, []), /* @__PURE__ */ D(ys, ee({}, e, {
    ref: i,
    trapFocus: n.open,
    disableOutsidePointerEvents: !0,
    onCloseAutoFocus: ot(e.onCloseAutoFocus, (o) => {
      var s;
      o.preventDefault(), (s = n.triggerRef.current) === null || s === void 0 || s.focus();
    }),
    onPointerDownOutside: ot(e.onPointerDownOutside, (o) => {
      const s = o.detail.originalEvent, a = s.button === 0 && s.ctrlKey === !0;
      (s.button === 2 || a) && o.preventDefault();
    }),
    onFocusOutside: ot(
      e.onFocusOutside,
      (o) => o.preventDefault()
    )
  }));
}), zu = /* @__PURE__ */ K((e, t) => {
  const n = lt(Ct, e.__scopeDialog), r = A(!1), i = A(!1);
  return /* @__PURE__ */ D(ys, ee({}, e, {
    ref: t,
    trapFocus: !1,
    disableOutsidePointerEvents: !1,
    onCloseAutoFocus: (o) => {
      var s;
      if ((s = e.onCloseAutoFocus) === null || s === void 0 || s.call(e, o), !o.defaultPrevented) {
        var a;
        r.current || (a = n.triggerRef.current) === null || a === void 0 || a.focus(), o.preventDefault();
      }
      r.current = !1, i.current = !1;
    },
    onInteractOutside: (o) => {
      var s, a;
      (s = e.onInteractOutside) === null || s === void 0 || s.call(e, o), o.defaultPrevented || (r.current = !0, o.detail.originalEvent.type === "pointerdown" && (i.current = !0));
      const c = o.target;
      ((a = n.triggerRef.current) === null || a === void 0 ? void 0 : a.contains(c)) && o.preventDefault(), o.detail.originalEvent.type === "focusin" && i.current && o.preventDefault();
    }
  }));
}), ys = /* @__PURE__ */ K((e, t) => {
  const { __scopeDialog: n, trapFocus: r, onOpenAutoFocus: i, onCloseAutoFocus: o, ...s } = e, a = lt(Ct, n), c = A(null), l = Rt(t, c);
  return Zl(), /* @__PURE__ */ D(Go, null, /* @__PURE__ */ D(Fl, {
    asChild: !0,
    loop: !0,
    trapped: r,
    onMountAutoFocus: i,
    onUnmountAutoFocus: o
  }, /* @__PURE__ */ D(Ol, ee({
    role: "dialog",
    id: a.contentId,
    "aria-describedby": a.descriptionId,
    "aria-labelledby": a.titleId,
    "data-state": bs(a.open)
  }, s, {
    ref: l,
    onDismiss: () => a.onOpenChange(!1)
  }))), !1);
});
function bs(e) {
  return e ? "open" : "closed";
}
const At = Nu, Pr = qu, Dt = Fu;
var ju = "qn51an4", Hu = "qn51an3", Wu = "qn51an0";
const we = () => {
  const [e, t] = B([
    window.innerHeight,
    window.innerWidth
  ]), n = () => {
    t([window.innerWidth, window.innerHeight]);
  }, r = es(n, 40);
  return k(() => (window.addEventListener("resize", r), n(), () => {
    window.removeEventListener("resize", r);
  }), []), e;
};
var Ee = { xs: "375px", m: "768px", l: "992px", xl: "1200px", xxl: "1400px" }, _r = { color: { brand: { orange: { O500: "var(--_1epihgq1)", O75: "var(--_1epihgq2)", O15: "var(--_1epihgq3)" }, yellow: { Y500: "var(--_1epihgq4)", Y75: "var(--_1epihgq5)", Y15: "var(--_1epihgq6)" }, red: { R500: "var(--_1epihgq7)", R75: "var(--_1epihgq8)", R15: "var(--_1epihgq9)" }, blue: { B500: "var(--_1epihgqa)", B75: "var(--_1epihgqb)", B15: "var(--_1epihgqc)" }, purple: { P500: "var(--_1epihgqd)", P75: "var(--_1epihgqe)", P15: "var(--_1epihgqf)" }, green: { G900: "var(--_1epihgqg)", G800: "var(--_1epihgqh)", G700: "var(--_1epihgqi)", G600: "var(--_1epihgqj)", G500: "var(--_1epihgqk)", G400: "var(--_1epihgql)", G300: "var(--_1epihgqm)", G200: "var(--_1epihgqn)", G100: "var(--_1epihgqo)", G20: "var(--_1epihgqp)", G15: "var(--_1epihgqq)" } }, neutrals: { neutrals: { N100: "var(--_1epihgqr)", N100Bold: "var(--_1epihgqs)", N100Bolder: "var(--_1epihgqt)", N200: "var(--_1epihgqu)", N200Bold: "var(--_1epihgqv)", N200Bolder: "var(--_1epihgqw)", N300: "var(--_1epihgqx)", N400: "var(--_1epihgqy)", N500: "var(--_1epihgqz)", N600: "var(--_1epihgq10)", N700: "var(--_1epihgq11)", N800: "var(--_1epihgq12)", N900: "var(--_1epihgq13)", N1000: "var(--_1epihgq14)" }, whites: { W100: "var(--_1epihgq15)", W75: "var(--_1epihgq16)", W50: "var(--_1epihgq17)", W30: "var(--_1epihgq18)", W15: "var(--_1epihgq19)", W5: "var(--_1epihgq1a)", W0: "var(--_1epihgq1b)" }, blacks: { B100: "var(--_1epihgq1c)", B60: "var(--_1epihgq1d)", B40: "var(--_1epihgq1e)", B20: "var(--_1epihgq1f)", B16: "var(--_1epihgq1g)", B7: "var(--_1epihgq1h)" } }, contextual: { informative: { Blue1000: "var(--_1epihgq1i)", Blue900: "var(--_1epihgq1j)", Blue800: "var(--_1epihgq1k)", Blue700: "var(--_1epihgq1l)", Blue600: "var(--_1epihgq1m)", Blue500: "var(--_1epihgq1n)", Blue400: "var(--_1epihgq1o)", Blue300: "var(--_1epihgq1p)", Blue200: "var(--_1epihgq1q)", Blue100: "var(--_1epihgq1r)" }, positive: { Green1000: "var(--_1epihgq1s)", Green900: "var(--_1epihgq1t)", Green800: "var(--_1epihgq1u)", Green700: "var(--_1epihgq1v)", Green600: "var(--_1epihgq1w)", Green500: "var(--_1epihgq1x)", Green400: "var(--_1epihgq1y)", Green300: "var(--_1epihgq1z)", Green200: "var(--_1epihgq20)", Green100: "var(--_1epihgq21)" }, negative: { Red1000: "var(--_1epihgq22)", Red900: "var(--_1epihgq23)", Red800: "var(--_1epihgq24)", Red700: "var(--_1epihgq25)", Red600: "var(--_1epihgq26)", Red500: "var(--_1epihgq27)", Red400: "var(--_1epihgq28)", Red300: "var(--_1epihgq29)", Red200: "var(--_1epihgq2a)", Red100: "var(--_1epihgq2b)" }, notice: { yellow1000: "var(--_1epihgq2c)", yellow900: "var(--_1epihgq2d)", yellow800: "var(--_1epihgq2e)", yellow700: "var(--_1epihgq2f)", yellow600: "var(--_1epihgq2g)", yellow500: "var(--_1epihgq2h)", yellow400: "var(--_1epihgq2i)", yellow300: "var(--_1epihgq2j)", yellow200: "var(--_1epihgq2k)", yellow100: "var(--_1epihgq2l)" } }, icon: { inverted: "var(--_1epihgq2m)", facebookMessengerOne: "var(--_1epihgq2n)", facebookMessengerTwo: "var(--_1epihgq2o)", facebookMessengerThree: "var(--_1epihgq2p)" }, background: { backgroundPrimary: "var(--_1epihgq2q)", backgroundPrimaryBold: "var(--_1epihgq2r)", backgroundPrimaryBolder: "var(--_1epihgq2s)", backgroundSecondary: "var(--_1epihgq2t)", backgroundSecondaryBolder: "var(--_1epihgq2u)", backgroundAccent: "var(--_1epihgq2v)", backgroundAccentBold: "var(--_1epihgq2w)", backgroundAccentBolder: "var(--_1epihgq2x)", backgroundFourth: "var(--_1epihgq2y)", backgroundBoldPrimary: "var(--_1epihgq2z)", backgroundBoldFourth: "var(--_1epihgq30)", backgroundBoldTertiary: "var(--_1epihgq31)", backgroundBoldFifth: "var(--_1epihgq32)", backgroundBlack7: "var(--_1epihgq33)", backgroundBlack16: "var(--_1epihgq34)", backgroundBlack20: "var(--_1epihgq35)", backgroundBlack40: "var(--_1epihgq36)", backgroundWhite5: "var(--_1epihgq37)", backgroundWhite15: "var(--_1epihgq38)", backgroundWhite30: "var(--_1epihgq39)", backgroundWhite50: "var(--_1epihgq3a)", backgroundWhite75: "var(--_1epihgq3b)", backgroundAccentSubtlest: "var(--_1epihgq3c)", backgroundBrandPurple: "var(--_1epihgq3d)" }, content: { contentOnColorPrimary: "var(--_1epihgq3e)", contentOnColorSecondary: "var(--_1epihgq3f)", contentOnColorTertiary: "var(--_1epihgq3g)", contentAccent: "var(--_1epihgq3h)", contentAccentBold: "var(--_1epihgq3i)", contentAccentBolder: "var(--_1epihgq3j)", contentPrimary: "var(--_1epihgq3k)", contentSecondary: "var(--_1epihgq3l)", contentTertiary: "var(--_1epihgq3m)", contentBrandPurple: "var(--_1epihgq3n)", contentError: "var(--_1epihgq3o)" }, border: { borderDefault: "var(--_1epihgq3p)", borderOnColorDisabled: "var(--_1epihgq3q)", borderAccent: "var(--_1epihgq3r)", borderAccentBold: "var(--_1epihgq3s)", borderAccentBolder: "var(--_1epihgq3t)", borderDisabled: "var(--_1epihgq3u)", borderWhite15: "var(--_1epihgq3v)", borderWhite100: "var(--_1epihgq3w)" } }, font: { body: "var(--_1epihgq3x)" }, typography: { header1: { fontFamily: "var(--_1epihgq3y)", fontSize: "var(--_1epihgq3z)", lineHeight: "var(--_1epihgq40)" }, header1L: { fontSize: "var(--_1epihgq41)", lineHeight: "var(--_1epihgq42)" }, header1XL: { fontSize: "var(--_1epihgq43)", lineHeight: "var(--_1epihgq44)" }, header2: { fontFamily: "var(--_1epihgq45)", fontSize: "var(--_1epihgq46)", lineHeight: "var(--_1epihgq47)" }, header2L: { fontSize: "var(--_1epihgq48)", lineHeight: "var(--_1epihgq49)" }, header2XL: { fontSize: "var(--_1epihgq4a)", lineHeight: "var(--_1epihgq4b)" }, header3: { fontFamily: "var(--_1epihgq4c)", fontSize: "var(--_1epihgq4d)", lineHeight: "var(--_1epihgq4e)" }, header3L: { fontSize: "var(--_1epihgq4f)", lineHeight: "var(--_1epihgq4g)" }, header3XL: { fontSize: "var(--_1epihgq4h)", lineHeight: "var(--_1epihgq4i)" }, header4: { fontFamily: "var(--_1epihgq4j)", fontSize: "var(--_1epihgq4k)", lineHeight: "var(--_1epihgq4l)" }, header4L: { fontSize: "var(--_1epihgq4m)", lineHeight: "var(--_1epihgq4n)" }, header4XL: { fontSize: "var(--_1epihgq4o)", lineHeight: "var(--_1epihgq4p)" }, header5: { fontFamily: "var(--_1epihgq4q)", fontSize: "var(--_1epihgq4r)", lineHeight: "var(--_1epihgq4s)" }, header5L: { fontSize: "var(--_1epihgq4t)", lineHeight: "var(--_1epihgq4u)" }, header5XL: { fontSize: "var(--_1epihgq4v)", lineHeight: "var(--_1epihgq4w)" }, header6: { fontFamily: "var(--_1epihgq4x)", fontSize: "var(--_1epihgq4y)", lineHeight: "var(--_1epihgq4z)" }, header6L: { fontSize: "var(--_1epihgq50)", lineHeight: "var(--_1epihgq51)" }, header6XL: { fontSize: "var(--_1epihgq52)", lineHeight: "var(--_1epihgq53)" }, paragraph8: { fontFamily: "var(--_1epihgq54)", fontSize: "var(--_1epihgq55)", lineHeight: "var(--_1epihgq56)" }, paragraph10: { fontFamily: "var(--_1epihgq57)", fontSize: "var(--_1epihgq58)", lineHeight: "var(--_1epihgq59)" }, paragraph12: { fontFamily: "var(--_1epihgq5a)", fontSize: "var(--_1epihgq5b)", lineHeight: "var(--_1epihgq5c)" }, paragraph14: { fontFamily: "var(--_1epihgq5d)", fontSize: "var(--_1epihgq5e)", lineHeight: "var(--_1epihgq5f)" }, paragraph16: { fontFamily: "var(--_1epihgq5g)", fontSize: "var(--_1epihgq5h)", lineHeight: "var(--_1epihgq5i)" }, paragraph18: { fontFamily: "var(--_1epihgq5j)", fontSize: "var(--_1epihgq5k)", lineHeight: "var(--_1epihgq5l)" } }, spacings: { 0: "var(--_1epihgq5m)", "16s": "var(--_1epihgq5n)", "14s": "var(--_1epihgq5o)", "12s": "var(--_1epihgq5p)", "10s": "var(--_1epihgq5q)", "9s": "var(--_1epihgq5r)", "8s": "var(--_1epihgq5s)", "7s": "var(--_1epihgq5t)", "6s": "var(--_1epihgq5u)", "5s": "var(--_1epihgq5v)", "4s": "var(--_1epihgq5w)", "3s": "var(--_1epihgq5x)", "2s": "var(--_1epihgq5y)", "1,5s": "var(--_1epihgq5z)", "1s": "var(--_1epihgq60)", "0,75s": "var(--_1epihgq61)", "0,5s": "var(--_1epihgq62)" }, radius: { "6r": "var(--_1epihgq63)", "5r": "var(--_1epihgq64)", "4r": "var(--_1epihgq65)", "3r": "var(--_1epihgq66)", "2r": "var(--_1epihgq67)", "1r": "var(--_1epihgq68)", "0,75r": "var(--_1epihgq69)", "0,5r": "var(--_1epihgq6a)" }, swirlRadius: { small: "var(--_1epihgq6b)", medium: "var(--_1epihgq6c)", large: "var(--_1epihgq6d)", xlarge: "var(--_1epihgq6e)", xxlarge: "var(--_1epihgq6f)" }, shadows: { one: "var(--_1epihgq6g)", two: "var(--_1epihgq6h)", three: "var(--_1epihgq6i)", threeNegativeYAxis: "var(--_1epihgq6j)", four: "var(--_1epihgq6k)", five: "var(--_1epihgq6l)", six: "var(--_1epihgq6m)" }, gradients: { one: "var(--_1epihgq6n)" } };
const Uu = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "m8.3 12 8-7.65-1.24-1.3L5.7 12l9.36 8.95 1.24-1.3-8-7.65Z",
      fill: "currentColor",
      fillRule: "evenodd"
    }
  )
), Gu = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "m15.7 12-8 7.65 1.24 1.3L18.3 12 8.94 3.05 7.7 4.35l8 7.65Z",
      fill: "currentColor",
      fillRule: "evenodd"
    }
  )
);
var Ku = "zf6z1hd", Nn = { topLevel: "zf6z1h3 zf6z1h2", secondLevel: "zf6z1h4 zf6z1h2", thirdLevel: "zf6z1h5 zf6z1h2" }, Zu = "zf6z1h8", wi = { fullWidthDropdown: "zf6z1h0", relativeWidthDropdown: "zf6z1h1" }, Yu = "zf6z1h7", Xu = "zf6z1h6", Qu = { level1: "zf6z1ha zf6z1h9", level2: "zf6z1hb zf6z1h9", level3: "zf6z1hc zf6z1h9" };
var Ju = { inActive: "_11fw99d1 _11fw99d0", active: "_11fw99d2 _11fw99d0" };
let Ei = 0;
const hg = ({
  href: e,
  label: t,
  navItems: n,
  level: r = 1,
  onActiveIndexChange: i,
  isMainLevelActive: o,
  index: s
}) => {
  const [a, c] = B(!1), [l, u] = B(!1), f = we()[0] < Number(Ee.l.replace("px", "")), h = A(null), p = (y) => {
    i && i(y);
  }, m = n != null && n.length && n.length > 1 ? wi.fullWidthDropdown : wi.relativeWidthDropdown;
  let b = Nn.topLevel;
  r === 2 ? b = Nn.secondLevel : r === 3 && (b = Nn.thirdLevel);
  let w = r === 1 && !f ? !!o : a;
  return r > 1 && !f && o && (w = !0), /* @__PURE__ */ v.createElement("li", { className: `${r === 1 ? m : ""}`, key: s }, /* @__PURE__ */ v.createElement(
    "a",
    {
      href: e,
      className: `${b} ${w ? ts : ""}`,
      onClick: (y) => {
        !f && (n != null && n.length) && r === 1 && !w && (y.preventDefault(), l || p(s)), f && (n != null && n.length) && (y.preventDefault(), c(!0), i && i(s || 0));
      }
    },
    t,
    /* @__PURE__ */ v.createElement("span", { className: Xu }, /* @__PURE__ */ v.createElement(Gu, { className: Yu }))
  ), n && /* @__PURE__ */ v.createElement(
    "div",
    {
      className: Ju[w ? "active" : "inActive"],
      ref: h
    },
    /* @__PURE__ */ v.createElement(
      "button",
      {
        onClick: () => {
          c(!1);
        },
        className: Zu
      },
      /* @__PURE__ */ v.createElement(Uu, null),
      t
    ),
    /* @__PURE__ */ v.createElement(
      ed,
      {
        isActive: w,
        subNavContainerRef: h,
        onClose: () => {
          u(!0), clearTimeout(Ei), Ei = window.setTimeout(() => {
            u(!1);
          }, 200), c(!1), i && i(void 0);
        },
        level: r
      },
      /* @__PURE__ */ v.createElement(ws, { level: r + 1 }, n.map((y, g) => /* @__PURE__ */ v.createElement(v.Fragment, { key: g }, y)))
    )
  ));
}, ed = ({
  children: e,
  isActive: t,
  onClose: n,
  subNavContainerRef: r,
  level: i
}) => {
  const s = we()[0] < Number(Ee.l.replace("px", "")), a = A(null);
  return s || i > 1 ? /* @__PURE__ */ v.createElement(v.Fragment, null, e) : /* @__PURE__ */ v.createElement(
    At,
    {
      open: t,
      modal: !1,
      onOpenChange: (c) => {
        c || n();
      }
    },
    /* @__PURE__ */ v.createElement(
      Dt,
      {
        ref: a,
        onPointerDownOutside: (c) => {
          var d;
          if (c.preventDefault(), !t)
            return;
          const l = (d = r.current) == null ? void 0 : d.contains(
            c.target
          ), u = c.target === a.current;
          (!l || !u) && n();
        },
        className: Ku,
        forceMount: !0,
        onEscapeKeyDown: () => {
          n();
        }
      },
      e
    )
  );
}, ws = ({
  children: e,
  level: t,
  mobileAccountButton: n
}) => {
  const i = we()[0] < Number(Ee.l.replace("px", ""));
  return /* @__PURE__ */ v.createElement(v.Fragment, null, /* @__PURE__ */ v.createElement("ul", { className: Qu[`level${t}`] }, e), i && t === 1 && n && /* @__PURE__ */ v.createElement("div", { className: ju }, n));
};
var td = "yh30yx0";
const nd = ({
  children: e,
  isMenuOpen: t,
  onOpenChange: n
}) => we()[0] < Number(Ee.l.replace("px", "")) ? /* @__PURE__ */ React.createElement(At, { open: t, modal: !0, onOpenChange: n }, /* @__PURE__ */ React.createElement(Pr, null), /* @__PURE__ */ React.createElement(Dt, { className: Hu }, e)) : /* @__PURE__ */ React.createElement(
  "div",
  {
    className: L(
      Ne,
      ns,
      td
    )
  },
  e
), rd = ({
  isMenuOpen: e,
  onOpenChange: t,
  children: n,
  mobileAccountButton: r
}) => {
  const [i, o] = B(void 0), s = ce.map(n, (a, c) => Pe(a, {
    index: c,
    isMainLevelActive: i === c,
    onActiveIndexChange: (l) => {
      l !== i && o(l);
    }
  }));
  return /* @__PURE__ */ React.createElement(nd, { isMenuOpen: e, onOpenChange: t }, /* @__PURE__ */ React.createElement("nav", { className: Wu }, /* @__PURE__ */ React.createElement(ws, { mobileAccountButton: r, level: 1 }, s)));
}, en = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "M10.73 12 3.1 4.37 4.37 3.1 12 10.73l7.63-7.63 1.27 1.27L13.27 12l7.63 7.63-1.27 1.27L12 13.27 4.37 20.9 3.1 19.63 10.73 12Z",
      fill: "currentColor",
      fillRule: "evenodd"
    }
  )
);
var id = "_1topwo74", od = "_1topwo75";
const tn = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      fill: "currentColor",
      fillRule: "evenodd",
      d: "M14.21 15.59A6.995 6.995 0 0 1 3 10c0-3.87 3.13-7 7-7s7 3.13 7 7c0 1.64-.56 3.14-1.5 4.34l5.5 5.38-1.26 1.29-5.53-5.41ZM15.2 10c0 2.87-2.33 5.2-5.2 5.2S4.8 12.87 4.8 10 7.13 4.8 10 4.8s5.2 2.33 5.2 5.2Z"
    }
  )
);
var sd = "_1y2ff7g0", ad = "_1y2ff7g3", cd = "_1y2ff7g1", ld = "_1y2ff7g2", Si = "_1y2ff7g4", ud = "_1y2ff7g5";
var xi = { default: "gm9kwm2", invertedColors: "gm9kwm3" }, dd = "gm9kwm0", fd = "gm9kwm1";
const Es = ({
  label: e,
  icon: t,
  invertedColors: n,
  ...r
}) => {
  const i = n ? xi.invertedColors : xi.default;
  return /* @__PURE__ */ React.createElement(
    "button",
    {
      className: L(fd, i),
      ...r
    },
    t,
    e && /* @__PURE__ */ React.createElement("span", { className: dd }, e)
  );
};
var hd = "ki0jez9", md = { left: "ki0jezc", right: "ki0jezd" }, pd = { small: "ki0jez6", medium: "ki0jez7", large: "ki0jez8" }, vd = "ki0jeze", gd = { primary: "ki0jez2 ki0jez0", secondary: "ki0jez3 ki0jez0", tertiary: "ki0jez4 ki0jez0", transparent: "ki0jez5 ki0jez0" }, yd = { primary: "ki0jezb ki0jeza" }, bd = "ki0jez1";
const wd = ({
  componentNode: e = "button",
  type: t = "primary",
  size: n = "small",
  iconPosition: r = "left",
  children: i,
  counter: o,
  invertColors: s = !1,
  icon: a,
  ...c
}) => {
  const l = gd[t], u = pd[n], d = a ? md[r] : "", f = o ? yd.primary : "", p = L(
    l,
    u,
    d,
    s ? bd : ""
  );
  return /* @__PURE__ */ React.createElement(e, { className: p, ...c }, a && /* @__PURE__ */ React.createElement("span", { className: hd }, a), i && /* @__PURE__ */ React.createElement("span", { className: vd }, i), o && n === "large" && t === "primary" && /* @__PURE__ */ React.createElement("span", { className: f }, o));
};
var Rr = { one: "_1900asl0", two: "_1900asl1", three: "_1900asl2", threeNegativeYAxis: "_1900asl3", four: "_1900asl4", five: "_1900asl5", six: "_1900asl6" };
const Ed = ({
  placeholder: e,
  value: t,
  onChange: n,
  isParentOpen: r,
  searchButtonLabel: i,
  searchSuggestions: o,
  fieldIcon: s,
  showButton: a = !1,
  label: c,
  supportingText: l,
  id: u = "searchField"
}) => {
  const d = A(null), f = s ? Pe(s, {
    className: Si
  }) : /* @__PURE__ */ React.createElement(tn, { className: Si });
  return k(() => {
    r && d.current && d.current.focus();
  }, [r, d]), /* @__PURE__ */ React.createElement(
    "form",
    {
      onSubmit: (h) => {
        h.preventDefault();
      }
    },
    c && /* @__PURE__ */ React.createElement("label", { htmlFor: u, className: cd }, c),
    /* @__PURE__ */ React.createElement("div", { className: sd }, f, /* @__PURE__ */ React.createElement(
      "input",
      {
        type: "text",
        id: u,
        placeholder: e,
        value: t,
        onChange: (h) => n(h.target.value),
        className: ad,
        ref: d
      }
    ), t && /* @__PURE__ */ React.createElement(Es, { icon: /* @__PURE__ */ React.createElement(en, null), onClick: () => n("") }), a && /* @__PURE__ */ React.createElement(
      wd,
      {
        type: "primary",
        size: "medium",
        icon: /* @__PURE__ */ React.createElement(tn, null),
        iconPosition: "right"
      },
      i && /* @__PURE__ */ React.createElement(React.Fragment, null, i)
    ), o && t && /* @__PURE__ */ React.createElement(
      "div",
      {
        className: L(ud, Rr.two)
      },
      o
    )),
    l && /* @__PURE__ */ React.createElement("p", { className: ld }, l)
  );
};
var Sd = "asj0v2";
var Ci = "dk6f4c0", xd = "dk6f4cg", Cd = "dk6f4c1 dk6f4c0", Td = "dk6f4c2 dk6f4c0", Pd = "dk6f4c3 dk6f4c0", _d = "dk6f4c4 dk6f4c0", Rd = "dk6f4c5 dk6f4c0", Ad = "dk6f4c6 dk6f4c0", Dd = "dk6f4cd", Md = "dk6f4cf", kd = "dk6f4c8", $d = "dk6f4c9", jt = "dk6f4ca", Vd = "dk6f4cb", Ld = "dk6f4cc", Nd = "dk6f4c7", Od = "dk6f4ce";
function st({
  component: e = "p",
  variant: t,
  children: n,
  className: r = "",
  fontWeight: i = "light",
  spaceBelow: o
}) {
  const s = t || e, c = {
    h1: Cd,
    h2: Td,
    h3: Pd,
    h4: _d,
    h5: Rd,
    h6: Ad,
    p: jt,
    paragraph8: Nd,
    paragraph10: kd,
    paragraph12: $d,
    paragraph14: jt,
    paragraph16: Vd,
    paragraph18: Ld,
    span: jt,
    div: jt
  }[s] ?? Ci;
  let l = Dd;
  i === "regular" && (l = Od), i === "bold" && (l = xd), i === "medium" && (l = Md);
  let u = "";
  o && (u = Sd);
  const d = L(
    c,
    Ci,
    s,
    r,
    l,
    u
  );
  return e === "h1" ? /* @__PURE__ */ React.createElement("h1", { className: d }, n) : e === "h2" ? /* @__PURE__ */ React.createElement("h2", { className: d }, n) : e === "h3" ? /* @__PURE__ */ React.createElement("h3", { className: d }, n) : e === "h4" ? /* @__PURE__ */ React.createElement("h4", { className: d }, n) : e === "h5" ? /* @__PURE__ */ React.createElement("h5", { className: d }, n) : e === "h6" ? /* @__PURE__ */ React.createElement("h6", { className: d }, n) : e === "div" ? /* @__PURE__ */ React.createElement("div", { className: d }, n) : e === "span" ? /* @__PURE__ */ React.createElement("span", { className: d }, n) : /* @__PURE__ */ React.createElement("p", { className: d }, n);
}
var qd = "zp3qgn2", Bd = "zp3qgn0", Fd = "zp3qgn1";
const Id = ({ tags: e, label: t }) => /* @__PURE__ */ React.createElement("div", { className: Bd }, /* @__PURE__ */ React.createElement(st, { variant: "paragraph16", fontWeight: "medium" }, t), /* @__PURE__ */ React.createElement("ul", { className: Fd }, e.map((n, r) => /* @__PURE__ */ React.createElement("li", { key: r }, /* @__PURE__ */ React.createElement("button", { className: qd }, n)))));
var zd = "ksiy7w0";
const jd = ({ children: e, ...t }) => /* @__PURE__ */ React.createElement("button", { className: zd, ...t }, e);
var Hd = "b65uxn2", Wd = "b65uxn1", Ud = "b65uxn0";
const Gd = ({ categories: e }) => /* @__PURE__ */ React.createElement("div", { className: Ud }, e.map((t, n) => /* @__PURE__ */ React.createElement("div", { key: n }, /* @__PURE__ */ React.createElement(
  st,
  {
    variant: "paragraph12",
    fontWeight: "regular",
    className: Wd
  },
  t.name
), t.suggestions.map((r, i) => /* @__PURE__ */ React.createElement(jd, { onClick: r.onClick, key: i }, /* @__PURE__ */ React.createElement(tn, { className: Hd }), /* @__PURE__ */ React.createElement(
  st,
  {
    component: "span",
    variant: "paragraph16",
    fontWeight: "regular",
    dangerouslySetInnerHTML: { __html: r.name }
  },
  /* @__PURE__ */ React.createElement("span", { dangerouslySetInnerHTML: { __html: r.name } })
)))))), Kd = ({
  isOpen: e,
  onOpenChange: t,
  placeholder: n
}) => {
  const [r, i] = B(""), o = e ? ts : "", a = we()[0] < Number(Ee.l.replace("px", ""));
  return /* @__PURE__ */ React.createElement(At, { open: e, modal: a, onOpenChange: t }, /* @__PURE__ */ React.createElement(Pr, null), /* @__PURE__ */ React.createElement(Dt, { className: L(id) }, /* @__PURE__ */ React.createElement("div", { className: Ne }, /* @__PURE__ */ React.createElement(
    "div",
    {
      className: L(
        od,
        Rr.three,
        o
      )
    },
    /* @__PURE__ */ React.createElement(
      Ed,
      {
        onChange: (c) => i(c),
        placeholder: n ?? "",
        value: r,
        isParentOpen: e
      }
    ),
    r.length > 0 ? /* @__PURE__ */ React.createElement(
      Gd,
      {
        categories: [
          {
            name: "Products",
            suggestions: [
              {
                name: "Thermo<strong>mix TM6</strong>",
                onClick: () => {
                }
              },
              {
                name: "<strong>Cookbook “Fit with</strong> Thermo<strong>mix®”</strong>",
                onClick: () => {
                }
              }
            ]
          },
          {
            name: "Articles",
            suggestions: [
              {
                name: "<strong>Tips and tricks for</strong> Thermo<strong>mix®</strong>",
                onClick: () => {
                }
              },
              {
                name: "<strong>How Star chefs use</strong> Thermo<strong>mix®</strong>",
                onClick: () => {
                }
              }
            ]
          }
        ]
      }
    ) : /* @__PURE__ */ React.createElement(
      Id,
      {
        label: "Searched most often",
        tags: [
          "Thermomix TM6",
          "Kobold VK7",
          "Robot",
          "Hotline",
          "Accessories"
        ]
      }
    )
  ))));
}, mg = ({
  logo: e,
  advisor: t,
  cart: n,
  backgroundType: r = "transparent",
  stickyMode: i = "sticky",
  navigation: o,
  mobileAccountButton: s
}) => {
  const [a, c] = B(!1), [l, u] = B(!1), [d, f] = B(!0), [h, p] = B(!1), b = we()[0] < Number(Ee.l.replace("px", "")), [w, y] = B(!1);
  k(() => {
    let T = window.scrollY;
    const R = es(() => {
      const N = window.scrollY;
      N > T ? (c(!0), u(!1), f(!1)) : N === 0 ? (c(!1), u(!1), f(!0)) : (c(!1), u(!0), f(!1)), T = N;
    }, 0);
    return window.addEventListener("scroll", R), () => {
      window.removeEventListener("scroll", R);
    };
  }, []);
  const g = a ? hl : "", E = l ? ml : "", x = d ? fl : "";
  let C = Rn[r] || "";
  return i === "sticky" && (g || E) && (C = Rn.solidWhite), i === "semiSticky" && l && !d && (C = Rn.solidWhite), /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(
    "header",
    {
      className: L(
        pl[i],
        g,
        E,
        C,
        x
      )
    },
    /* @__PURE__ */ React.createElement(
      "div",
      {
        className: L(
          Ne,
          vl,
          ns
        )
      },
      /* @__PURE__ */ React.createElement("div", { className: ci }, b && /* @__PURE__ */ React.createElement(
        Qn,
        {
          label: "Menu",
          children: h ? /* @__PURE__ */ React.createElement(en, null) : /* @__PURE__ */ React.createElement(wl, null),
          disabled: h,
          onClick: () => {
            p(!h);
          }
        }
      ), t),
      /* @__PURE__ */ React.createElement("div", null, e),
      /* @__PURE__ */ React.createElement("div", { className: ci }, /* @__PURE__ */ React.createElement(
        Qn,
        {
          label: "Search",
          children: w ? /* @__PURE__ */ React.createElement(en, null) : /* @__PURE__ */ React.createElement(tn, null),
          onClick: () => {
            y(!w);
          }
        }
      ), n)
    ),
    /* @__PURE__ */ React.createElement(
      rd,
      {
        isMenuOpen: h,
        onOpenChange: (T) => p(T),
        mobileAccountButton: s
      },
      o
    ),
    /* @__PURE__ */ React.createElement(
      Kd,
      {
        isOpen: w,
        onOpenChange: (T) => {
          y(T);
        },
        placeholder: "Search"
      }
    )
  ), /* @__PURE__ */ React.createElement("div", { className: L(dl) }));
};
var Zd = { left: "_7kok976", center: "_7kok977", right: "_7kok978" }, Yd = { horizontal: "_7kok971 _7kok970", vertical: "_7kok972 _7kok970" }, Xd = { fill: "_7kok973", "50%": "_7kok974", hug: "_7kok975" };
const pg = ({
  children: e,
  layout: t = "horizontal",
  sizing: n = "hug",
  alignment: r = "left"
}) => {
  const i = Yd[t], o = n ? Xd[n] : "", s = Zd[r];
  return /* @__PURE__ */ React.createElement(
    "div",
    {
      className: L(
        i,
        o,
        s
      )
    },
    e
  );
};
var Qd = "_1epihgq0";
var Jd = "_5yj2ss0";
const ir = v.forwardRef(function({ children: e, className: t, ...n }, r) {
  return /* @__PURE__ */ v.createElement("div", { ref: r, className: L(Qd, t), ...n }, e);
}), ef = v.forwardRef(function({ children: e, className: t, ...n }, r) {
  return /* @__PURE__ */ v.createElement(
    "div",
    {
      ref: r,
      className: L(Jd, t),
      ...n
    },
    e
  );
}), Ar = de({
  transformPagePoint: (e) => e,
  isStatic: !1,
  reducedMotion: "never"
}), mn = de({}), pn = de(null), vn = typeof document < "u", gn = vn ? Er : k, Ss = de({ strict: !1 });
function tf(e, t, n, r) {
  const { visualElement: i } = H(mn), o = H(Ss), s = H(pn), a = H(Ar).reducedMotion, c = A();
  r = r || o.renderer, !c.current && r && (c.current = r(e, {
    visualState: t,
    parent: i,
    props: n,
    presenceContext: s,
    blockInitialAnimation: s ? s.initial === !1 : !1,
    reducedMotionConfig: a
  }));
  const l = c.current;
  Ko(() => {
    l && l.update(n, s);
  });
  const u = A(!!window.HandoffAppearAnimations);
  return gn(() => {
    l && (l.render(), u.current && l.animationState && l.animationState.animateChanges());
  }), k(() => {
    l && (l.updateFeatures(), !u.current && l.animationState && l.animationState.animateChanges(), window.HandoffAppearAnimations = void 0, u.current = !1);
  }), l;
}
function tt(e) {
  return typeof e == "object" && Object.prototype.hasOwnProperty.call(e, "current");
}
function nf(e, t, n) {
  return ue(
    (r) => {
      r && e.mount && e.mount(r), t && (r ? t.mount(r) : t.unmount()), n && (typeof n == "function" ? n(r) : tt(n) && (n.current = r));
    },
    /**
     * Only pass a new ref callback to React if we've received a visual element
     * factory. Otherwise we'll be mounting/remounting every time externalRef
     * or other dependencies change.
     */
    [t]
  );
}
function Tt(e) {
  return typeof e == "string" || Array.isArray(e);
}
function yn(e) {
  return typeof e == "object" && typeof e.start == "function";
}
const Dr = [
  "animate",
  "whileInView",
  "whileFocus",
  "whileHover",
  "whileTap",
  "whileDrag",
  "exit"
], Mr = ["initial", ...Dr];
function bn(e) {
  return yn(e.animate) || Mr.some((t) => Tt(e[t]));
}
function xs(e) {
  return !!(bn(e) || e.variants);
}
function rf(e, t) {
  if (bn(e)) {
    const { initial: n, animate: r } = e;
    return {
      initial: n === !1 || Tt(n) ? n : void 0,
      animate: Tt(r) ? r : void 0
    };
  }
  return e.inherit !== !1 ? t : {};
}
function of(e) {
  const { initial: t, animate: n } = rf(e, H(mn));
  return fe(() => ({ initial: t, animate: n }), [Ti(t), Ti(n)]);
}
function Ti(e) {
  return Array.isArray(e) ? e.join(" ") : e;
}
const Pi = {
  animation: [
    "animate",
    "variants",
    "whileHover",
    "whileTap",
    "exit",
    "whileInView",
    "whileFocus",
    "whileDrag"
  ],
  exit: ["exit"],
  drag: ["drag", "dragControls"],
  focus: ["whileFocus"],
  hover: ["whileHover", "onHoverStart", "onHoverEnd"],
  tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
  pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
  inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
  layout: ["layout", "layoutId"]
}, Pt = {};
for (const e in Pi)
  Pt[e] = {
    isEnabled: (t) => Pi[e].some((n) => !!t[n])
  };
function sf(e) {
  for (const t in e)
    Pt[t] = {
      ...Pt[t],
      ...e[t]
    };
}
const kr = de({}), Cs = de({}), af = Symbol.for("motionComponentSymbol");
function cf({ preloadedFeatures: e, createVisualElement: t, useRender: n, useVisualState: r, Component: i }) {
  e && sf(e);
  function o(a, c) {
    let l;
    const u = {
      ...H(Ar),
      ...a,
      layoutId: lf(a)
    }, { isStatic: d } = u, f = of(a), h = r(a, d);
    if (!d && vn) {
      f.visualElement = tf(i, h, u, t);
      const p = H(Cs), m = H(Ss).strict;
      f.visualElement && (l = f.visualElement.loadFeatures(
        // Note: Pass the full new combined props to correctly re-render dynamic feature components.
        u,
        m,
        e,
        p
      ));
    }
    return P.createElement(
      mn.Provider,
      { value: f },
      l && f.visualElement ? P.createElement(l, { visualElement: f.visualElement, ...u }) : null,
      n(i, a, nf(h, f.visualElement, c), h, d, f.visualElement)
    );
  }
  const s = K(o);
  return s[af] = i, s;
}
function lf({ layoutId: e }) {
  const t = H(kr).id;
  return t && e !== void 0 ? t + "-" + e : e;
}
function uf(e) {
  function t(r, i = {}) {
    return cf(e(r, i));
  }
  if (typeof Proxy > "u")
    return t;
  const n = /* @__PURE__ */ new Map();
  return new Proxy(t, {
    /**
     * Called when `motion` is referenced with a prop: `motion.div`, `motion.input` etc.
     * The prop name is passed through as `key` and we can use that to generate a `motion`
     * DOM component with that name.
     */
    get: (r, i) => (n.has(i) || n.set(i, t(i)), n.get(i))
  });
}
const df = [
  "animate",
  "circle",
  "defs",
  "desc",
  "ellipse",
  "g",
  "image",
  "line",
  "filter",
  "marker",
  "mask",
  "metadata",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "rect",
  "stop",
  "switch",
  "symbol",
  "svg",
  "text",
  "tspan",
  "use",
  "view"
];
function $r(e) {
  return (
    /**
     * If it's not a string, it's a custom React component. Currently we only support
     * HTML custom React components.
     */
    typeof e != "string" || /**
     * If it contains a dash, the element is a custom HTML webcomponent.
     */
    e.includes("-") ? !1 : (
      /**
       * If it's in our list of lowercase SVG tags, it's an SVG component
       */
      !!(df.indexOf(e) > -1 || /**
       * If it contains a capital letter, it's an SVG component
       */
      /[A-Z]/.test(e))
    )
  );
}
const nn = {};
function ff(e) {
  Object.assign(nn, e);
}
const Mt = [
  "transformPerspective",
  "x",
  "y",
  "z",
  "translateX",
  "translateY",
  "translateZ",
  "scale",
  "scaleX",
  "scaleY",
  "rotate",
  "rotateX",
  "rotateY",
  "rotateZ",
  "skew",
  "skewX",
  "skewY"
], Ue = new Set(Mt);
function Ts(e, { layout: t, layoutId: n }) {
  return Ue.has(e) || e.startsWith("origin") || (t || n !== void 0) && (!!nn[e] || e === "opacity");
}
const Z = (e) => !!(e && e.getVelocity), hf = {
  x: "translateX",
  y: "translateY",
  z: "translateZ",
  transformPerspective: "perspective"
}, mf = Mt.length;
function pf(e, { enableHardwareAcceleration: t = !0, allowTransformNone: n = !0 }, r, i) {
  let o = "";
  for (let s = 0; s < mf; s++) {
    const a = Mt[s];
    if (e[a] !== void 0) {
      const c = hf[a] || a;
      o += `${c}(${e[a]}) `;
    }
  }
  return t && !e.z && (o += "translateZ(0)"), o = o.trim(), i ? o = i(e, r ? "" : o) : n && r && (o = "none"), o;
}
const Ps = (e) => (t) => typeof t == "string" && t.startsWith(e), _s = Ps("--"), or = Ps("var(--"), vf = /var\s*\(\s*--[\w-]+(\s*,\s*(?:(?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)+)?\s*\)/g, gf = (e, t) => t && typeof e == "number" ? t.transform(e) : e, Ve = (e, t, n) => Math.min(Math.max(n, e), t), Ge = {
  test: (e) => typeof e == "number",
  parse: parseFloat,
  transform: (e) => e
}, yt = {
  ...Ge,
  transform: (e) => Ve(0, 1, e)
}, Ht = {
  ...Ge,
  default: 1
}, bt = (e) => Math.round(e * 1e5) / 1e5, wn = /(-)?([\d]*\.?[\d])+/g, Rs = /(#[0-9a-f]{3,8}|(rgb|hsl)a?\((-?[\d\.]+%?[,\s]+){2}(-?[\d\.]+%?)\s*[\,\/]?\s*[\d\.]*%?\))/gi, yf = /^(#[0-9a-f]{3,8}|(rgb|hsl)a?\((-?[\d\.]+%?[,\s]+){2}(-?[\d\.]+%?)\s*[\,\/]?\s*[\d\.]*%?\))$/i;
function kt(e) {
  return typeof e == "string";
}
const $t = (e) => ({
  test: (t) => kt(t) && t.endsWith(e) && t.split(" ").length === 1,
  parse: parseFloat,
  transform: (t) => `${t}${e}`
}), De = $t("deg"), ye = $t("%"), _ = $t("px"), bf = $t("vh"), wf = $t("vw"), _i = {
  ...ye,
  parse: (e) => ye.parse(e) / 100,
  transform: (e) => ye.transform(e * 100)
}, Ri = {
  ...Ge,
  transform: Math.round
}, As = {
  // Border props
  borderWidth: _,
  borderTopWidth: _,
  borderRightWidth: _,
  borderBottomWidth: _,
  borderLeftWidth: _,
  borderRadius: _,
  radius: _,
  borderTopLeftRadius: _,
  borderTopRightRadius: _,
  borderBottomRightRadius: _,
  borderBottomLeftRadius: _,
  // Positioning props
  width: _,
  maxWidth: _,
  height: _,
  maxHeight: _,
  size: _,
  top: _,
  right: _,
  bottom: _,
  left: _,
  // Spacing props
  padding: _,
  paddingTop: _,
  paddingRight: _,
  paddingBottom: _,
  paddingLeft: _,
  margin: _,
  marginTop: _,
  marginRight: _,
  marginBottom: _,
  marginLeft: _,
  // Transform props
  rotate: De,
  rotateX: De,
  rotateY: De,
  rotateZ: De,
  scale: Ht,
  scaleX: Ht,
  scaleY: Ht,
  scaleZ: Ht,
  skew: De,
  skewX: De,
  skewY: De,
  distance: _,
  translateX: _,
  translateY: _,
  translateZ: _,
  x: _,
  y: _,
  z: _,
  perspective: _,
  transformPerspective: _,
  opacity: yt,
  originX: _i,
  originY: _i,
  originZ: _,
  // Misc
  zIndex: Ri,
  // SVG
  fillOpacity: yt,
  strokeOpacity: yt,
  numOctaves: Ri
};
function Vr(e, t, n, r) {
  const { style: i, vars: o, transform: s, transformOrigin: a } = e;
  let c = !1, l = !1, u = !0;
  for (const d in t) {
    const f = t[d];
    if (_s(d)) {
      o[d] = f;
      continue;
    }
    const h = As[d], p = gf(f, h);
    if (Ue.has(d)) {
      if (c = !0, s[d] = p, !u)
        continue;
      f !== (h.default || 0) && (u = !1);
    } else
      d.startsWith("origin") ? (l = !0, a[d] = p) : i[d] = p;
  }
  if (t.transform || (c || r ? i.transform = pf(e.transform, n, u, r) : i.transform && (i.transform = "none")), l) {
    const { originX: d = "50%", originY: f = "50%", originZ: h = 0 } = a;
    i.transformOrigin = `${d} ${f} ${h}`;
  }
}
const Lr = () => ({
  style: {},
  transform: {},
  transformOrigin: {},
  vars: {}
});
function Ds(e, t, n) {
  for (const r in t)
    !Z(t[r]) && !Ts(r, n) && (e[r] = t[r]);
}
function Ef({ transformTemplate: e }, t, n) {
  return fe(() => {
    const r = Lr();
    return Vr(r, t, { enableHardwareAcceleration: !n }, e), Object.assign({}, r.vars, r.style);
  }, [t]);
}
function Sf(e, t, n) {
  const r = e.style || {}, i = {};
  return Ds(i, r, e), Object.assign(i, Ef(e, t, n)), e.transformValues ? e.transformValues(i) : i;
}
function xf(e, t, n) {
  const r = {}, i = Sf(e, t, n);
  return e.drag && e.dragListener !== !1 && (r.draggable = !1, i.userSelect = i.WebkitUserSelect = i.WebkitTouchCallout = "none", i.touchAction = e.drag === !0 ? "none" : `pan-${e.drag === "x" ? "y" : "x"}`), e.tabIndex === void 0 && (e.onTap || e.onTapStart || e.whileTap) && (r.tabIndex = 0), r.style = i, r;
}
const Cf = /* @__PURE__ */ new Set([
  "animate",
  "exit",
  "variants",
  "initial",
  "style",
  "values",
  "variants",
  "transition",
  "transformTemplate",
  "transformValues",
  "custom",
  "inherit",
  "onLayoutAnimationStart",
  "onLayoutAnimationComplete",
  "onLayoutMeasure",
  "onBeforeLayoutMeasure",
  "onAnimationStart",
  "onAnimationComplete",
  "onUpdate",
  "onDragStart",
  "onDrag",
  "onDragEnd",
  "onMeasureDragConstraints",
  "onDirectionLock",
  "onDragTransitionEnd",
  "_dragX",
  "_dragY",
  "onHoverStart",
  "onHoverEnd",
  "onViewportEnter",
  "onViewportLeave",
  "ignoreStrict",
  "viewport"
]);
function rn(e) {
  return e.startsWith("while") || e.startsWith("drag") && e !== "draggable" || e.startsWith("layout") || e.startsWith("onTap") || e.startsWith("onPan") || Cf.has(e);
}
let Ms = (e) => !rn(e);
function Tf(e) {
  e && (Ms = (t) => t.startsWith("on") ? !rn(t) : e(t));
}
try {
  Tf(require("@emotion/is-prop-valid").default);
} catch {
}
function Pf(e, t, n) {
  const r = {};
  for (const i in e)
    i === "values" && typeof e.values == "object" || (Ms(i) || n === !0 && rn(i) || !t && !rn(i) || // If trying to use native HTML drag events, forward drag listeners
    e.draggable && i.startsWith("onDrag")) && (r[i] = e[i]);
  return r;
}
function Ai(e, t, n) {
  return typeof e == "string" ? e : _.transform(t + n * e);
}
function _f(e, t, n) {
  const r = Ai(t, e.x, e.width), i = Ai(n, e.y, e.height);
  return `${r} ${i}`;
}
const Rf = {
  offset: "stroke-dashoffset",
  array: "stroke-dasharray"
}, Af = {
  offset: "strokeDashoffset",
  array: "strokeDasharray"
};
function Df(e, t, n = 1, r = 0, i = !0) {
  e.pathLength = 1;
  const o = i ? Rf : Af;
  e[o.offset] = _.transform(-r);
  const s = _.transform(t), a = _.transform(n);
  e[o.array] = `${s} ${a}`;
}
function Nr(e, {
  attrX: t,
  attrY: n,
  attrScale: r,
  originX: i,
  originY: o,
  pathLength: s,
  pathSpacing: a = 1,
  pathOffset: c = 0,
  // This is object creation, which we try to avoid per-frame.
  ...l
}, u, d, f) {
  if (Vr(e, l, u, f), d) {
    e.style.viewBox && (e.attrs.viewBox = e.style.viewBox);
    return;
  }
  e.attrs = e.style, e.style = {};
  const { attrs: h, style: p, dimensions: m } = e;
  h.transform && (m && (p.transform = h.transform), delete h.transform), m && (i !== void 0 || o !== void 0 || p.transform) && (p.transformOrigin = _f(m, i !== void 0 ? i : 0.5, o !== void 0 ? o : 0.5)), t !== void 0 && (h.x = t), n !== void 0 && (h.y = n), r !== void 0 && (h.scale = r), s !== void 0 && Df(h, s, a, c, !1);
}
const ks = () => ({
  ...Lr(),
  attrs: {}
}), Or = (e) => typeof e == "string" && e.toLowerCase() === "svg";
function Mf(e, t, n, r) {
  const i = fe(() => {
    const o = ks();
    return Nr(o, t, { enableHardwareAcceleration: !1 }, Or(r), e.transformTemplate), {
      ...o.attrs,
      style: { ...o.style }
    };
  }, [t]);
  if (e.style) {
    const o = {};
    Ds(o, e.style, e), i.style = { ...o, ...i.style };
  }
  return i;
}
function kf(e = !1) {
  return (n, r, i, { latestValues: o }, s) => {
    const c = ($r(n) ? Mf : xf)(r, o, s, n), u = {
      ...Pf(r, typeof n == "string", e),
      ...c,
      ref: i
    }, { children: d } = r, f = fe(() => Z(d) ? d.get() : d, [d]);
    return D(n, {
      ...u,
      children: f
    });
  };
}
const qr = (e) => e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
function $s(e, { style: t, vars: n }, r, i) {
  Object.assign(e.style, t, i && i.getProjectionStyles(r));
  for (const o in n)
    e.style.setProperty(o, n[o]);
}
const Vs = /* @__PURE__ */ new Set([
  "baseFrequency",
  "diffuseConstant",
  "kernelMatrix",
  "kernelUnitLength",
  "keySplines",
  "keyTimes",
  "limitingConeAngle",
  "markerHeight",
  "markerWidth",
  "numOctaves",
  "targetX",
  "targetY",
  "surfaceScale",
  "specularConstant",
  "specularExponent",
  "stdDeviation",
  "tableValues",
  "viewBox",
  "gradientTransform",
  "pathLength",
  "startOffset",
  "textLength",
  "lengthAdjust"
]);
function Ls(e, t, n, r) {
  $s(e, t, void 0, r);
  for (const i in t.attrs)
    e.setAttribute(Vs.has(i) ? i : qr(i), t.attrs[i]);
}
function Br(e, t) {
  const { style: n } = e, r = {};
  for (const i in n)
    (Z(n[i]) || t.style && Z(t.style[i]) || Ts(i, e)) && (r[i] = n[i]);
  return r;
}
function Ns(e, t) {
  const n = Br(e, t);
  for (const r in e)
    if (Z(e[r]) || Z(t[r])) {
      const i = Mt.indexOf(r) !== -1 ? "attr" + r.charAt(0).toUpperCase() + r.substring(1) : r;
      n[i] = e[r];
    }
  return n;
}
function Fr(e, t, n, r = {}, i = {}) {
  return typeof t == "function" && (t = t(n !== void 0 ? n : e.custom, r, i)), typeof t == "string" && (t = e.variants && e.variants[t]), typeof t == "function" && (t = t(n !== void 0 ? n : e.custom, r, i)), t;
}
function En(e) {
  const t = A(null);
  return t.current === null && (t.current = e()), t.current;
}
const on = (e) => Array.isArray(e), $f = (e) => !!(e && typeof e == "object" && e.mix && e.toValue), Vf = (e) => on(e) ? e[e.length - 1] || 0 : e;
function Qt(e) {
  const t = Z(e) ? e.get() : e;
  return $f(t) ? t.toValue() : t;
}
function Lf({ scrapeMotionValuesFromProps: e, createRenderState: t, onMount: n }, r, i, o) {
  const s = {
    latestValues: Nf(r, i, o, e),
    renderState: t()
  };
  return n && (s.mount = (a) => n(r, a, s)), s;
}
const Os = (e) => (t, n) => {
  const r = H(mn), i = H(pn), o = () => Lf(e, t, r, i);
  return n ? o() : En(o);
};
function Nf(e, t, n, r) {
  const i = {}, o = r(e, {});
  for (const f in o)
    i[f] = Qt(o[f]);
  let { initial: s, animate: a } = e;
  const c = bn(e), l = xs(e);
  t && l && !c && e.inherit !== !1 && (s === void 0 && (s = t.initial), a === void 0 && (a = t.animate));
  let u = n ? n.initial === !1 : !1;
  u = u || s === !1;
  const d = u ? a : s;
  return d && typeof d != "boolean" && !yn(d) && (Array.isArray(d) ? d : [d]).forEach((h) => {
    const p = Fr(e, h);
    if (!p)
      return;
    const { transitionEnd: m, transition: b, ...w } = p;
    for (const y in w) {
      let g = w[y];
      if (Array.isArray(g)) {
        const E = u ? g.length - 1 : 0;
        g = g[E];
      }
      g !== null && (i[y] = g);
    }
    for (const y in m)
      i[y] = m[y];
  }), i;
}
const I = (e) => e;
class Di {
  constructor() {
    this.order = [], this.scheduled = /* @__PURE__ */ new Set();
  }
  add(t) {
    if (!this.scheduled.has(t))
      return this.scheduled.add(t), this.order.push(t), !0;
  }
  remove(t) {
    const n = this.order.indexOf(t);
    n !== -1 && (this.order.splice(n, 1), this.scheduled.delete(t));
  }
  clear() {
    this.order.length = 0, this.scheduled.clear();
  }
}
function Of(e) {
  let t = new Di(), n = new Di(), r = 0, i = !1, o = !1;
  const s = /* @__PURE__ */ new WeakSet(), a = {
    /**
     * Schedule a process to run on the next frame.
     */
    schedule: (c, l = !1, u = !1) => {
      const d = u && i, f = d ? t : n;
      return l && s.add(c), f.add(c) && d && i && (r = t.order.length), c;
    },
    /**
     * Cancel the provided callback from running on the next frame.
     */
    cancel: (c) => {
      n.remove(c), s.delete(c);
    },
    /**
     * Execute all schedule callbacks.
     */
    process: (c) => {
      if (i) {
        o = !0;
        return;
      }
      if (i = !0, [t, n] = [n, t], n.clear(), r = t.order.length, r)
        for (let l = 0; l < r; l++) {
          const u = t.order[l];
          u(c), s.has(u) && (a.schedule(u), e());
        }
      i = !1, o && (o = !1, a.process(c));
    }
  };
  return a;
}
const Wt = [
  "prepare",
  "read",
  "update",
  "preRender",
  "render",
  "postRender"
], qf = 40;
function Bf(e, t) {
  let n = !1, r = !0;
  const i = {
    delta: 0,
    timestamp: 0,
    isProcessing: !1
  }, o = Wt.reduce((d, f) => (d[f] = Of(() => n = !0), d), {}), s = (d) => o[d].process(i), a = () => {
    const d = performance.now();
    n = !1, i.delta = r ? 1e3 / 60 : Math.max(Math.min(d - i.timestamp, qf), 1), i.timestamp = d, i.isProcessing = !0, Wt.forEach(s), i.isProcessing = !1, n && t && (r = !1, e(a));
  }, c = () => {
    n = !0, r = !0, i.isProcessing || e(a);
  };
  return { schedule: Wt.reduce((d, f) => {
    const h = o[f];
    return d[f] = (p, m = !1, b = !1) => (n || c(), h.schedule(p, m, b)), d;
  }, {}), cancel: (d) => Wt.forEach((f) => o[f].cancel(d)), state: i, steps: o };
}
const { schedule: V, cancel: he, state: G, steps: On } = Bf(typeof requestAnimationFrame < "u" ? requestAnimationFrame : I, !0), Ff = {
  useVisualState: Os({
    scrapeMotionValuesFromProps: Ns,
    createRenderState: ks,
    onMount: (e, t, { renderState: n, latestValues: r }) => {
      V.read(() => {
        try {
          n.dimensions = typeof t.getBBox == "function" ? t.getBBox() : t.getBoundingClientRect();
        } catch {
          n.dimensions = {
            x: 0,
            y: 0,
            width: 0,
            height: 0
          };
        }
      }), V.render(() => {
        Nr(n, r, { enableHardwareAcceleration: !1 }, Or(t.tagName), e.transformTemplate), Ls(t, n);
      });
    }
  })
}, If = {
  useVisualState: Os({
    scrapeMotionValuesFromProps: Br,
    createRenderState: Lr
  })
};
function zf(e, { forwardMotionProps: t = !1 }, n, r) {
  return {
    ...$r(e) ? Ff : If,
    preloadedFeatures: n,
    useRender: kf(t),
    createVisualElement: r,
    Component: e
  };
}
function Se(e, t, n, r = { passive: !0 }) {
  return e.addEventListener(t, n, r), () => e.removeEventListener(t, n);
}
const qs = (e) => e.pointerType === "mouse" ? typeof e.button != "number" || e.button <= 0 : e.isPrimary !== !1;
function Sn(e, t = "page") {
  return {
    point: {
      x: e[t + "X"],
      y: e[t + "Y"]
    }
  };
}
const jf = (e) => (t) => qs(t) && e(t, Sn(t));
function Ce(e, t, n, r) {
  return Se(e, t, jf(n), r);
}
const Hf = (e, t) => (n) => t(e(n)), ke = (...e) => e.reduce(Hf);
function Bs(e) {
  let t = null;
  return () => {
    const n = () => {
      t = null;
    };
    return t === null ? (t = e, n) : !1;
  };
}
const Mi = Bs("dragHorizontal"), ki = Bs("dragVertical");
function Fs(e) {
  let t = !1;
  if (e === "y")
    t = ki();
  else if (e === "x")
    t = Mi();
  else {
    const n = Mi(), r = ki();
    n && r ? t = () => {
      n(), r();
    } : (n && n(), r && r());
  }
  return t;
}
function Is() {
  const e = Fs(!0);
  return e ? (e(), !1) : !0;
}
class Oe {
  constructor(t) {
    this.isMounted = !1, this.node = t;
  }
  update() {
  }
}
function $i(e, t) {
  const n = "pointer" + (t ? "enter" : "leave"), r = "onHover" + (t ? "Start" : "End"), i = (o, s) => {
    if (o.type === "touch" || Is())
      return;
    const a = e.getProps();
    e.animationState && a.whileHover && e.animationState.setActive("whileHover", t), a[r] && V.update(() => a[r](o, s));
  };
  return Ce(e.current, n, i, {
    passive: !e.getProps()[r]
  });
}
class Wf extends Oe {
  mount() {
    this.unmount = ke($i(this.node, !0), $i(this.node, !1));
  }
  unmount() {
  }
}
class Uf extends Oe {
  constructor() {
    super(...arguments), this.isActive = !1;
  }
  onFocus() {
    let t = !1;
    try {
      t = this.node.current.matches(":focus-visible");
    } catch {
      t = !0;
    }
    !t || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0);
  }
  onBlur() {
    !this.isActive || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1);
  }
  mount() {
    this.unmount = ke(Se(this.node.current, "focus", () => this.onFocus()), Se(this.node.current, "blur", () => this.onBlur()));
  }
  unmount() {
  }
}
const zs = (e, t) => t ? e === t ? !0 : zs(e, t.parentElement) : !1;
function qn(e, t) {
  if (!t)
    return;
  const n = new PointerEvent("pointer" + e);
  t(n, Sn(n));
}
class Gf extends Oe {
  constructor() {
    super(...arguments), this.removeStartListeners = I, this.removeEndListeners = I, this.removeAccessibleListeners = I, this.startPointerPress = (t, n) => {
      if (this.removeEndListeners(), this.isPressing)
        return;
      const r = this.node.getProps(), o = Ce(window, "pointerup", (a, c) => {
        if (!this.checkPressEnd())
          return;
        const { onTap: l, onTapCancel: u } = this.node.getProps();
        V.update(() => {
          zs(this.node.current, a.target) ? l && l(a, c) : u && u(a, c);
        });
      }, { passive: !(r.onTap || r.onPointerUp) }), s = Ce(window, "pointercancel", (a, c) => this.cancelPress(a, c), { passive: !(r.onTapCancel || r.onPointerCancel) });
      this.removeEndListeners = ke(o, s), this.startPress(t, n);
    }, this.startAccessiblePress = () => {
      const t = (o) => {
        if (o.key !== "Enter" || this.isPressing)
          return;
        const s = (a) => {
          a.key !== "Enter" || !this.checkPressEnd() || qn("up", (c, l) => {
            const { onTap: u } = this.node.getProps();
            u && V.update(() => u(c, l));
          });
        };
        this.removeEndListeners(), this.removeEndListeners = Se(this.node.current, "keyup", s), qn("down", (a, c) => {
          this.startPress(a, c);
        });
      }, n = Se(this.node.current, "keydown", t), r = () => {
        this.isPressing && qn("cancel", (o, s) => this.cancelPress(o, s));
      }, i = Se(this.node.current, "blur", r);
      this.removeAccessibleListeners = ke(n, i);
    };
  }
  startPress(t, n) {
    this.isPressing = !0;
    const { onTapStart: r, whileTap: i } = this.node.getProps();
    i && this.node.animationState && this.node.animationState.setActive("whileTap", !0), r && V.update(() => r(t, n));
  }
  checkPressEnd() {
    return this.removeEndListeners(), this.isPressing = !1, this.node.getProps().whileTap && this.node.animationState && this.node.animationState.setActive("whileTap", !1), !Is();
  }
  cancelPress(t, n) {
    if (!this.checkPressEnd())
      return;
    const { onTapCancel: r } = this.node.getProps();
    r && V.update(() => r(t, n));
  }
  mount() {
    const t = this.node.getProps(), n = Ce(this.node.current, "pointerdown", this.startPointerPress, { passive: !(t.onTapStart || t.onPointerStart) }), r = Se(this.node.current, "focus", this.startAccessiblePress);
    this.removeStartListeners = ke(n, r);
  }
  unmount() {
    this.removeStartListeners(), this.removeEndListeners(), this.removeAccessibleListeners();
  }
}
const sr = /* @__PURE__ */ new WeakMap(), Bn = /* @__PURE__ */ new WeakMap(), Kf = (e) => {
  const t = sr.get(e.target);
  t && t(e);
}, Zf = (e) => {
  e.forEach(Kf);
};
function Yf({ root: e, ...t }) {
  const n = e || document;
  Bn.has(n) || Bn.set(n, {});
  const r = Bn.get(n), i = JSON.stringify(t);
  return r[i] || (r[i] = new IntersectionObserver(Zf, { root: e, ...t })), r[i];
}
function Xf(e, t, n) {
  const r = Yf(t);
  return sr.set(e, n), r.observe(e), () => {
    sr.delete(e), r.unobserve(e);
  };
}
const Qf = {
  some: 0,
  all: 1
};
class Jf extends Oe {
  constructor() {
    super(...arguments), this.hasEnteredView = !1, this.isInView = !1;
  }
  startObserver() {
    this.unmount();
    const { viewport: t = {} } = this.node.getProps(), { root: n, margin: r, amount: i = "some", once: o } = t, s = {
      root: n ? n.current : void 0,
      rootMargin: r,
      threshold: typeof i == "number" ? i : Qf[i]
    }, a = (c) => {
      const { isIntersecting: l } = c;
      if (this.isInView === l || (this.isInView = l, o && !l && this.hasEnteredView))
        return;
      l && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", l);
      const { onViewportEnter: u, onViewportLeave: d } = this.node.getProps(), f = l ? u : d;
      f && f(c);
    };
    return Xf(this.node.current, s, a);
  }
  mount() {
    this.startObserver();
  }
  update() {
    if (typeof IntersectionObserver > "u")
      return;
    const { props: t, prevProps: n } = this.node;
    ["amount", "margin", "root"].some(eh(t, n)) && this.startObserver();
  }
  unmount() {
  }
}
function eh({ viewport: e = {} }, { viewport: t = {} } = {}) {
  return (n) => e[n] !== t[n];
}
const th = {
  inView: {
    Feature: Jf
  },
  tap: {
    Feature: Gf
  },
  focus: {
    Feature: Uf
  },
  hover: {
    Feature: Wf
  }
};
function js(e, t) {
  if (!Array.isArray(t))
    return !1;
  const n = t.length;
  if (n !== e.length)
    return !1;
  for (let r = 0; r < n; r++)
    if (t[r] !== e[r])
      return !1;
  return !0;
}
function nh(e) {
  const t = {};
  return e.values.forEach((n, r) => t[r] = n.get()), t;
}
function rh(e) {
  const t = {};
  return e.values.forEach((n, r) => t[r] = n.getVelocity()), t;
}
function xn(e, t, n) {
  const r = e.getProps();
  return Fr(r, t, n !== void 0 ? n : r.custom, nh(e), rh(e));
}
const ih = "framerAppearId", oh = "data-" + qr(ih);
let Vt = I, re = I;
process.env.NODE_ENV !== "production" && (Vt = (e, t) => {
  !e && typeof console < "u" && console.warn(t);
}, re = (e, t) => {
  if (!e)
    throw new Error(t);
});
const Te = (e) => e * 1e3, be = (e) => e / 1e3, sh = {
  current: !1
}, Hs = (e) => Array.isArray(e) && typeof e[0] == "number";
function Ws(e) {
  return !!(!e || typeof e == "string" && Us[e] || Hs(e) || Array.isArray(e) && e.every(Ws));
}
const gt = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`, Us = {
  linear: "linear",
  ease: "ease",
  easeIn: "ease-in",
  easeOut: "ease-out",
  easeInOut: "ease-in-out",
  circIn: gt([0, 0.65, 0.55, 1]),
  circOut: gt([0.55, 0, 1, 0.45]),
  backIn: gt([0.31, 0.01, 0.66, -0.59]),
  backOut: gt([0.33, 1.53, 0.69, 0.99])
};
function Gs(e) {
  if (e)
    return Hs(e) ? gt(e) : Array.isArray(e) ? e.map(Gs) : Us[e];
}
function ah(e, t, n, { delay: r = 0, duration: i, repeat: o = 0, repeatType: s = "loop", ease: a, times: c } = {}) {
  const l = { [t]: n };
  c && (l.offset = c);
  const u = Gs(a);
  return Array.isArray(u) && (l.easing = u), e.animate(l, {
    delay: r,
    duration: i,
    easing: Array.isArray(u) ? "linear" : u,
    fill: "both",
    iterations: o + 1,
    direction: s === "reverse" ? "alternate" : "normal"
  });
}
function ch(e, { repeat: t, repeatType: n = "loop" }) {
  const r = t && n !== "loop" && t % 2 === 1 ? 0 : e.length - 1;
  return e[r];
}
const Ks = (e, t, n) => (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e, lh = 1e-7, uh = 12;
function dh(e, t, n, r, i) {
  let o, s, a = 0;
  do
    s = t + (n - t) / 2, o = Ks(s, r, i) - e, o > 0 ? n = s : t = s;
  while (Math.abs(o) > lh && ++a < uh);
  return s;
}
function Lt(e, t, n, r) {
  if (e === t && n === r)
    return I;
  const i = (o) => dh(o, 0, 1, e, n);
  return (o) => o === 0 || o === 1 ? o : Ks(i(o), t, r);
}
const fh = Lt(0.42, 0, 1, 1), hh = Lt(0, 0, 0.58, 1), Zs = Lt(0.42, 0, 0.58, 1), Ys = (e) => Array.isArray(e) && typeof e[0] != "number", Xs = (e) => (t) => t <= 0.5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2, Qs = (e) => (t) => 1 - e(1 - t), Js = (e) => 1 - Math.sin(Math.acos(e)), Ir = Qs(Js), mh = Xs(Ir), ea = Lt(0.33, 1.53, 0.69, 0.99), zr = Qs(ea), ph = Xs(zr), vh = (e) => (e *= 2) < 1 ? 0.5 * zr(e) : 0.5 * (2 - Math.pow(2, -10 * (e - 1))), Vi = {
  linear: I,
  easeIn: fh,
  easeInOut: Zs,
  easeOut: hh,
  circIn: Js,
  circInOut: mh,
  circOut: Ir,
  backIn: zr,
  backInOut: ph,
  backOut: ea,
  anticipate: vh
}, Li = (e) => {
  if (Array.isArray(e)) {
    re(e.length === 4, "Cubic bezier arrays must contain four numerical values.");
    const [t, n, r, i] = e;
    return Lt(t, n, r, i);
  } else if (typeof e == "string")
    return re(Vi[e] !== void 0, `Invalid easing type '${e}'`), Vi[e];
  return e;
}, jr = (e, t) => (n) => !!(kt(n) && yf.test(n) && n.startsWith(e) || t && Object.prototype.hasOwnProperty.call(n, t)), ta = (e, t, n) => (r) => {
  if (!kt(r))
    return r;
  const [i, o, s, a] = r.match(wn);
  return {
    [e]: parseFloat(i),
    [t]: parseFloat(o),
    [n]: parseFloat(s),
    alpha: a !== void 0 ? parseFloat(a) : 1
  };
}, gh = (e) => Ve(0, 255, e), Fn = {
  ...Ge,
  transform: (e) => Math.round(gh(e))
}, ze = {
  test: jr("rgb", "red"),
  parse: ta("red", "green", "blue"),
  transform: ({ red: e, green: t, blue: n, alpha: r = 1 }) => "rgba(" + Fn.transform(e) + ", " + Fn.transform(t) + ", " + Fn.transform(n) + ", " + bt(yt.transform(r)) + ")"
};
function yh(e) {
  let t = "", n = "", r = "", i = "";
  return e.length > 5 ? (t = e.substring(1, 3), n = e.substring(3, 5), r = e.substring(5, 7), i = e.substring(7, 9)) : (t = e.substring(1, 2), n = e.substring(2, 3), r = e.substring(3, 4), i = e.substring(4, 5), t += t, n += n, r += r, i += i), {
    red: parseInt(t, 16),
    green: parseInt(n, 16),
    blue: parseInt(r, 16),
    alpha: i ? parseInt(i, 16) / 255 : 1
  };
}
const ar = {
  test: jr("#"),
  parse: yh,
  transform: ze.transform
}, nt = {
  test: jr("hsl", "hue"),
  parse: ta("hue", "saturation", "lightness"),
  transform: ({ hue: e, saturation: t, lightness: n, alpha: r = 1 }) => "hsla(" + Math.round(e) + ", " + ye.transform(bt(t)) + ", " + ye.transform(bt(n)) + ", " + bt(yt.transform(r)) + ")"
}, Q = {
  test: (e) => ze.test(e) || ar.test(e) || nt.test(e),
  parse: (e) => ze.test(e) ? ze.parse(e) : nt.test(e) ? nt.parse(e) : ar.parse(e),
  transform: (e) => kt(e) ? e : e.hasOwnProperty("red") ? ze.transform(e) : nt.transform(e)
}, F = (e, t, n) => -n * e + n * t + e;
function In(e, t, n) {
  return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + (t - e) * 6 * n : n < 1 / 2 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e;
}
function bh({ hue: e, saturation: t, lightness: n, alpha: r }) {
  e /= 360, t /= 100, n /= 100;
  let i = 0, o = 0, s = 0;
  if (!t)
    i = o = s = n;
  else {
    const a = n < 0.5 ? n * (1 + t) : n + t - n * t, c = 2 * n - a;
    i = In(c, a, e + 1 / 3), o = In(c, a, e), s = In(c, a, e - 1 / 3);
  }
  return {
    red: Math.round(i * 255),
    green: Math.round(o * 255),
    blue: Math.round(s * 255),
    alpha: r
  };
}
const zn = (e, t, n) => {
  const r = e * e;
  return Math.sqrt(Math.max(0, n * (t * t - r) + r));
}, wh = [ar, ze, nt], Eh = (e) => wh.find((t) => t.test(e));
function Ni(e) {
  const t = Eh(e);
  re(!!t, `'${e}' is not an animatable color. Use the equivalent color code instead.`);
  let n = t.parse(e);
  return t === nt && (n = bh(n)), n;
}
const na = (e, t) => {
  const n = Ni(e), r = Ni(t), i = { ...n };
  return (o) => (i.red = zn(n.red, r.red, o), i.green = zn(n.green, r.green, o), i.blue = zn(n.blue, r.blue, o), i.alpha = F(n.alpha, r.alpha, o), ze.transform(i));
};
function Sh(e) {
  var t, n;
  return isNaN(e) && kt(e) && (((t = e.match(wn)) === null || t === void 0 ? void 0 : t.length) || 0) + (((n = e.match(Rs)) === null || n === void 0 ? void 0 : n.length) || 0) > 0;
}
const ra = {
  regex: vf,
  countKey: "Vars",
  token: "${v}",
  parse: I
}, ia = {
  regex: Rs,
  countKey: "Colors",
  token: "${c}",
  parse: Q.parse
}, oa = {
  regex: wn,
  countKey: "Numbers",
  token: "${n}",
  parse: Ge.parse
};
function jn(e, { regex: t, countKey: n, token: r, parse: i }) {
  const o = e.tokenised.match(t);
  o && (e["num" + n] = o.length, e.tokenised = e.tokenised.replace(t, r), e.values.push(...o.map(i)));
}
function sn(e) {
  const t = e.toString(), n = {
    value: t,
    tokenised: t,
    values: [],
    numVars: 0,
    numColors: 0,
    numNumbers: 0
  };
  return n.value.includes("var(--") && jn(n, ra), jn(n, ia), jn(n, oa), n;
}
function sa(e) {
  return sn(e).values;
}
function aa(e) {
  const { values: t, numColors: n, numVars: r, tokenised: i } = sn(e), o = t.length;
  return (s) => {
    let a = i;
    for (let c = 0; c < o; c++)
      c < r ? a = a.replace(ra.token, s[c]) : c < r + n ? a = a.replace(ia.token, Q.transform(s[c])) : a = a.replace(oa.token, bt(s[c]));
    return a;
  };
}
const xh = (e) => typeof e == "number" ? 0 : e;
function Ch(e) {
  const t = sa(e);
  return aa(e)(t.map(xh));
}
const Le = {
  test: Sh,
  parse: sa,
  createTransformer: aa,
  getAnimatableNone: Ch
}, ca = (e, t) => (n) => `${n > 0 ? t : e}`;
function la(e, t) {
  return typeof e == "number" ? (n) => F(e, t, n) : Q.test(e) ? na(e, t) : e.startsWith("var(") ? ca(e, t) : da(e, t);
}
const ua = (e, t) => {
  const n = [...e], r = n.length, i = e.map((o, s) => la(o, t[s]));
  return (o) => {
    for (let s = 0; s < r; s++)
      n[s] = i[s](o);
    return n;
  };
}, Th = (e, t) => {
  const n = { ...e, ...t }, r = {};
  for (const i in n)
    e[i] !== void 0 && t[i] !== void 0 && (r[i] = la(e[i], t[i]));
  return (i) => {
    for (const o in r)
      n[o] = r[o](i);
    return n;
  };
}, da = (e, t) => {
  const n = Le.createTransformer(t), r = sn(e), i = sn(t);
  return r.numVars === i.numVars && r.numColors === i.numColors && r.numNumbers >= i.numNumbers ? ke(ua(r.values, i.values), n) : (Vt(!0, `Complex values '${e}' and '${t}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), ca(e, t));
}, at = (e, t, n) => {
  const r = t - e;
  return r === 0 ? 1 : (n - e) / r;
}, Oi = (e, t) => (n) => F(e, t, n);
function Ph(e) {
  return typeof e == "number" ? Oi : typeof e == "string" ? Q.test(e) ? na : da : Array.isArray(e) ? ua : typeof e == "object" ? Th : Oi;
}
function _h(e, t, n) {
  const r = [], i = n || Ph(e[0]), o = e.length - 1;
  for (let s = 0; s < o; s++) {
    let a = i(e[s], e[s + 1]);
    if (t) {
      const c = Array.isArray(t) ? t[s] || I : t;
      a = ke(c, a);
    }
    r.push(a);
  }
  return r;
}
function Hr(e, t, { clamp: n = !0, ease: r, mixer: i } = {}) {
  const o = e.length;
  if (re(o === t.length, "Both input and output ranges must be the same length"), o === 1)
    return () => t[0];
  e[0] > e[o - 1] && (e = [...e].reverse(), t = [...t].reverse());
  const s = _h(t, r, i), a = s.length, c = (l) => {
    let u = 0;
    if (a > 1)
      for (; u < e.length - 2 && !(l < e[u + 1]); u++)
        ;
    const d = at(e[u], e[u + 1], l);
    return s[u](d);
  };
  return n ? (l) => c(Ve(e[0], e[o - 1], l)) : c;
}
function fa(e, t) {
  const n = e[e.length - 1];
  for (let r = 1; r <= t; r++) {
    const i = at(0, t, r);
    e.push(F(n, 1, i));
  }
}
function ha(e) {
  const t = [0];
  return fa(t, e.length - 1), t;
}
function Rh(e, t) {
  return e.map((n) => n * t);
}
function Ah(e, t) {
  return e.map(() => t || Zs).splice(0, e.length - 1);
}
function an({ duration: e = 300, keyframes: t, times: n, ease: r = "easeInOut" }) {
  const i = Ys(r) ? r.map(Li) : Li(r), o = {
    done: !1,
    value: t[0]
  }, s = Rh(
    // Only use the provided offsets if they're the correct length
    // TODO Maybe we should warn here if there's a length mismatch
    n && n.length === t.length ? n : ha(t),
    e
  ), a = Hr(s, t, {
    ease: Array.isArray(i) ? i : Ah(t, i)
  });
  return {
    calculatedDuration: e,
    next: (c) => (o.value = a(c), o.done = c >= e, o)
  };
}
function ma(e, t) {
  return t ? e * (1e3 / t) : 0;
}
const Dh = 5;
function pa(e, t, n) {
  const r = Math.max(t - Dh, 0);
  return ma(n - e(r), t - r);
}
const Hn = 1e-3, Mh = 0.01, qi = 10, kh = 0.05, $h = 1;
function Vh({ duration: e = 800, bounce: t = 0.25, velocity: n = 0, mass: r = 1 }) {
  let i, o;
  Vt(e <= Te(qi), "Spring duration must be 10 seconds or less");
  let s = 1 - t;
  s = Ve(kh, $h, s), e = Ve(Mh, qi, be(e)), s < 1 ? (i = (l) => {
    const u = l * s, d = u * e, f = u - n, h = cr(l, s), p = Math.exp(-d);
    return Hn - f / h * p;
  }, o = (l) => {
    const d = l * s * e, f = d * n + n, h = Math.pow(s, 2) * Math.pow(l, 2) * e, p = Math.exp(-d), m = cr(Math.pow(l, 2), s);
    return (-i(l) + Hn > 0 ? -1 : 1) * ((f - h) * p) / m;
  }) : (i = (l) => {
    const u = Math.exp(-l * e), d = (l - n) * e + 1;
    return -Hn + u * d;
  }, o = (l) => {
    const u = Math.exp(-l * e), d = (n - l) * (e * e);
    return u * d;
  });
  const a = 5 / e, c = Nh(i, o, a);
  if (e = Te(e), isNaN(c))
    return {
      stiffness: 100,
      damping: 10,
      duration: e
    };
  {
    const l = Math.pow(c, 2) * r;
    return {
      stiffness: l,
      damping: s * 2 * Math.sqrt(r * l),
      duration: e
    };
  }
}
const Lh = 12;
function Nh(e, t, n) {
  let r = n;
  for (let i = 1; i < Lh; i++)
    r = r - e(r) / t(r);
  return r;
}
function cr(e, t) {
  return e * Math.sqrt(1 - t * t);
}
const Oh = ["duration", "bounce"], qh = ["stiffness", "damping", "mass"];
function Bi(e, t) {
  return t.some((n) => e[n] !== void 0);
}
function Bh(e) {
  let t = {
    velocity: 0,
    stiffness: 100,
    damping: 10,
    mass: 1,
    isResolvedFromDuration: !1,
    ...e
  };
  if (!Bi(e, qh) && Bi(e, Oh)) {
    const n = Vh(e);
    t = {
      ...t,
      ...n,
      velocity: 0,
      mass: 1
    }, t.isResolvedFromDuration = !0;
  }
  return t;
}
function Wr({ keyframes: e, restDelta: t, restSpeed: n, ...r }) {
  const i = e[0], o = e[e.length - 1], s = { done: !1, value: i }, { stiffness: a, damping: c, mass: l, velocity: u, duration: d, isResolvedFromDuration: f } = Bh(r), h = u ? -be(u) : 0, p = c / (2 * Math.sqrt(a * l)), m = o - i, b = be(Math.sqrt(a / l)), w = Math.abs(m) < 5;
  n || (n = w ? 0.01 : 2), t || (t = w ? 5e-3 : 0.5);
  let y;
  if (p < 1) {
    const g = cr(b, p);
    y = (E) => {
      const x = Math.exp(-p * b * E);
      return o - x * ((h + p * b * m) / g * Math.sin(g * E) + m * Math.cos(g * E));
    };
  } else if (p === 1)
    y = (g) => o - Math.exp(-b * g) * (m + (h + b * m) * g);
  else {
    const g = b * Math.sqrt(p * p - 1);
    y = (E) => {
      const x = Math.exp(-p * b * E), C = Math.min(g * E, 300);
      return o - x * ((h + p * b * m) * Math.sinh(C) + g * m * Math.cosh(C)) / g;
    };
  }
  return {
    calculatedDuration: f && d || null,
    next: (g) => {
      const E = y(g);
      if (f)
        s.done = g >= d;
      else {
        let x = h;
        g !== 0 && (p < 1 ? x = pa(y, g, E) : x = 0);
        const C = Math.abs(x) <= n, T = Math.abs(o - E) <= t;
        s.done = C && T;
      }
      return s.value = s.done ? o : E, s;
    }
  };
}
function Fi({ keyframes: e, velocity: t = 0, power: n = 0.8, timeConstant: r = 325, bounceDamping: i = 10, bounceStiffness: o = 500, modifyTarget: s, min: a, max: c, restDelta: l = 0.5, restSpeed: u }) {
  const d = e[0], f = {
    done: !1,
    value: d
  }, h = (S) => a !== void 0 && S < a || c !== void 0 && S > c, p = (S) => a === void 0 ? c : c === void 0 || Math.abs(a - S) < Math.abs(c - S) ? a : c;
  let m = n * t;
  const b = d + m, w = s === void 0 ? b : s(b);
  w !== b && (m = w - d);
  const y = (S) => -m * Math.exp(-S / r), g = (S) => w + y(S), E = (S) => {
    const R = y(S), N = g(S);
    f.done = Math.abs(R) <= l, f.value = f.done ? w : N;
  };
  let x, C;
  const T = (S) => {
    h(f.value) && (x = S, C = Wr({
      keyframes: [f.value, p(f.value)],
      velocity: pa(g, S, f.value),
      damping: i,
      stiffness: o,
      restDelta: l,
      restSpeed: u
    }));
  };
  return T(0), {
    calculatedDuration: null,
    next: (S) => {
      let R = !1;
      return !C && x === void 0 && (R = !0, E(S), T(S)), x !== void 0 && S > x ? C.next(S - x) : (!R && E(S), f);
    }
  };
}
const Fh = (e) => {
  const t = ({ timestamp: n }) => e(n);
  return {
    start: () => V.update(t, !0),
    stop: () => he(t),
    /**
     * If we're processing this frame we can use the
     * framelocked timestamp to keep things in sync.
     */
    now: () => G.isProcessing ? G.timestamp : performance.now()
  };
}, lr = 2e4;
function ur(e) {
  let t = 0;
  const n = 50;
  let r = e.next(t);
  for (; !r.done && t < lr; )
    t += n, r = e.next(t);
  return t >= lr ? 1 / 0 : t;
}
const Ih = {
  decay: Fi,
  inertia: Fi,
  tween: an,
  keyframes: an,
  spring: Wr
};
function cn({ autoplay: e = !0, delay: t = 0, driver: n = Fh, keyframes: r, type: i = "keyframes", repeat: o = 0, repeatDelay: s = 0, repeatType: a = "loop", onPlay: c, onStop: l, onComplete: u, onUpdate: d, ...f }) {
  let h = 1, p = !1, m, b;
  const w = () => {
    b = new Promise(($) => {
      m = $;
    });
  };
  w();
  let y;
  const g = Ih[i] || an;
  let E;
  g !== an && typeof r[0] != "number" && (E = Hr([0, 100], r, {
    clamp: !1
  }), r = [0, 100]);
  const x = g({ ...f, keyframes: r });
  let C;
  a === "mirror" && (C = g({
    ...f,
    keyframes: [...r].reverse(),
    velocity: -(f.velocity || 0)
  }));
  let T = "idle", S = null, R = null, N = null;
  x.calculatedDuration === null && o && (x.calculatedDuration = ur(x));
  const { calculatedDuration: W } = x;
  let Y = 1 / 0, U = 1 / 0;
  W !== null && (Y = W + s, U = Y * (o + 1) - s);
  let M = 0;
  const O = ($) => {
    if (R === null)
      return;
    h > 0 && (R = Math.min(R, $)), h < 0 && (R = Math.min($ - U / h, R)), S !== null ? M = S : M = Math.round($ - R) * h;
    const me = M - t * (h >= 0 ? 1 : -1), Ze = h >= 0 ? me < 0 : me > U;
    M = Math.max(me, 0), T === "finished" && S === null && (M = U);
    let Nt = M, dt = x;
    if (o) {
      const se = M / Y;
      let te = Math.floor(se), ne = se % 1;
      !ne && se >= 1 && (ne = 1), ne === 1 && te--, te = Math.min(te, o + 1);
      const pe = !!(te % 2);
      pe && (a === "reverse" ? (ne = 1 - ne, s && (ne -= s / Y)) : a === "mirror" && (dt = C));
      let Ye = Ve(0, 1, ne);
      M > U && (Ye = a === "reverse" && pe ? 1 : 0), Nt = Ye * Y;
    }
    const q = Ze ? { done: !1, value: r[0] } : dt.next(Nt);
    E && (q.value = E(q.value));
    let { done: oe } = q;
    !Ze && W !== null && (oe = h >= 0 ? M >= U : M <= 0);
    const Re = S === null && (T === "finished" || T === "running" && oe);
    return d && d(q.value), Re && Ke(), q;
  }, X = () => {
    y && y.stop(), y = void 0;
  }, z = () => {
    T = "idle", X(), m(), w(), R = N = null;
  }, Ke = () => {
    T = "finished", u && u(), X(), m();
  }, qe = () => {
    if (p)
      return;
    y || (y = n(O));
    const $ = y.now();
    c && c(), S !== null ? R = $ - S : (!R || T === "finished") && (R = $), T === "finished" && w(), N = R, S = null, T = "running", y.start();
  };
  e && qe();
  const _e = {
    then($, me) {
      return b.then($, me);
    },
    get time() {
      return be(M);
    },
    set time($) {
      $ = Te($), M = $, S !== null || !y || h === 0 ? S = $ : R = y.now() - $ / h;
    },
    get duration() {
      const $ = x.calculatedDuration === null ? ur(x) : x.calculatedDuration;
      return be($);
    },
    get speed() {
      return h;
    },
    set speed($) {
      $ === h || !y || (h = $, _e.time = be(M));
    },
    get state() {
      return T;
    },
    play: qe,
    pause: () => {
      T = "paused", S = M;
    },
    stop: () => {
      p = !0, T !== "idle" && (T = "idle", l && l(), z());
    },
    cancel: () => {
      N !== null && O(N), z();
    },
    complete: () => {
      T = "finished";
    },
    sample: ($) => (R = 0, O($))
  };
  return _e;
}
function va(e) {
  let t;
  return () => (t === void 0 && (t = e()), t);
}
const zh = va(() => Object.hasOwnProperty.call(Element.prototype, "animate")), jh = /* @__PURE__ */ new Set([
  "opacity",
  "clipPath",
  "filter",
  "transform",
  "backgroundColor"
]), Ut = 10, Hh = 2e4, Wh = (e, t) => t.type === "spring" || e === "backgroundColor" || !Ws(t.ease);
function Uh(e, t, { onUpdate: n, onComplete: r, ...i }) {
  if (!(zh() && jh.has(t) && !i.repeatDelay && i.repeatType !== "mirror" && i.damping !== 0 && i.type !== "inertia"))
    return !1;
  let s = !1, a, c;
  const l = () => {
    c = new Promise((y) => {
      a = y;
    });
  };
  l();
  let { keyframes: u, duration: d = 300, ease: f, times: h } = i;
  if (Wh(t, i)) {
    const y = cn({
      ...i,
      repeat: 0,
      delay: 0
    });
    let g = { done: !1, value: u[0] };
    const E = [];
    let x = 0;
    for (; !g.done && x < Hh; )
      g = y.sample(x), E.push(g.value), x += Ut;
    h = void 0, u = E, d = x - Ut, f = "linear";
  }
  const p = ah(e.owner.current, t, u, {
    ...i,
    duration: d,
    /**
     * This function is currently not called if ease is provided
     * as a function so the cast is safe.
     *
     * However it would be possible for a future refinement to port
     * in easing pregeneration from Motion One for browsers that
     * support the upcoming `linear()` easing function.
     */
    ease: f,
    times: h
  });
  i.syncStart && (p.startTime = G.isProcessing ? G.timestamp : document.timeline ? document.timeline.currentTime : performance.now());
  const m = () => p.cancel(), b = () => {
    V.update(m), a(), l();
  };
  return p.onfinish = () => {
    e.set(ch(u, i)), r && r(), b();
  }, {
    then(y, g) {
      return c.then(y, g);
    },
    attachTimeline(y) {
      return p.timeline = y, p.onfinish = null, I;
    },
    get time() {
      return be(p.currentTime || 0);
    },
    set time(y) {
      p.currentTime = Te(y);
    },
    get speed() {
      return p.playbackRate;
    },
    set speed(y) {
      p.playbackRate = y;
    },
    get duration() {
      return be(d);
    },
    play: () => {
      s || (p.play(), he(m));
    },
    pause: () => p.pause(),
    stop: () => {
      if (s = !0, p.playState === "idle")
        return;
      const { currentTime: y } = p;
      if (y) {
        const g = cn({
          ...i,
          autoplay: !1
        });
        e.setWithVelocity(g.sample(y - Ut).value, g.sample(y).value, Ut);
      }
      b();
    },
    complete: () => p.finish(),
    cancel: b
  };
}
function Gh({ keyframes: e, delay: t, onUpdate: n, onComplete: r }) {
  const i = () => (n && n(e[e.length - 1]), r && r(), {
    time: 0,
    speed: 1,
    duration: 0,
    play: I,
    pause: I,
    stop: I,
    then: (o) => (o(), Promise.resolve()),
    cancel: I,
    complete: I
  });
  return t ? cn({
    keyframes: [0, 1],
    duration: 0,
    delay: t,
    onComplete: i
  }) : i();
}
const Kh = {
  type: "spring",
  stiffness: 500,
  damping: 25,
  restSpeed: 10
}, Zh = (e) => ({
  type: "spring",
  stiffness: 550,
  damping: e === 0 ? 2 * Math.sqrt(550) : 30,
  restSpeed: 10
}), Yh = {
  type: "keyframes",
  duration: 0.8
}, Xh = {
  type: "keyframes",
  ease: [0.25, 0.1, 0.35, 1],
  duration: 0.3
}, Qh = (e, { keyframes: t }) => t.length > 2 ? Yh : Ue.has(e) ? e.startsWith("scale") ? Zh(t[1]) : Kh : Xh, dr = (e, t) => e === "zIndex" ? !1 : !!(typeof t == "number" || Array.isArray(t) || typeof t == "string" && // It's animatable if we have a string
(Le.test(t) || t === "0") && // And it contains numbers and/or colors
!t.startsWith("url(")), Jh = /* @__PURE__ */ new Set(["brightness", "contrast", "saturate", "opacity"]);
function em(e) {
  const [t, n] = e.slice(0, -1).split("(");
  if (t === "drop-shadow")
    return e;
  const [r] = n.match(wn) || [];
  if (!r)
    return e;
  const i = n.replace(r, "");
  let o = Jh.has(t) ? 1 : 0;
  return r !== n && (o *= 100), t + "(" + o + i + ")";
}
const tm = /([a-z-]*)\(.*?\)/g, fr = {
  ...Le,
  getAnimatableNone: (e) => {
    const t = e.match(tm);
    return t ? t.map(em).join(" ") : e;
  }
}, nm = {
  ...As,
  // Color props
  color: Q,
  backgroundColor: Q,
  outlineColor: Q,
  fill: Q,
  stroke: Q,
  // Border props
  borderColor: Q,
  borderTopColor: Q,
  borderRightColor: Q,
  borderBottomColor: Q,
  borderLeftColor: Q,
  filter: fr,
  WebkitFilter: fr
}, Ur = (e) => nm[e];
function ga(e, t) {
  let n = Ur(e);
  return n !== fr && (n = Le), n.getAnimatableNone ? n.getAnimatableNone(t) : void 0;
}
const ya = (e) => /^0[^.\s]+$/.test(e);
function rm(e) {
  if (typeof e == "number")
    return e === 0;
  if (e !== null)
    return e === "none" || e === "0" || ya(e);
}
function im(e, t, n, r) {
  const i = dr(t, n);
  let o;
  Array.isArray(n) ? o = [...n] : o = [null, n];
  const s = r.from !== void 0 ? r.from : e.get();
  let a;
  const c = [];
  for (let l = 0; l < o.length; l++)
    o[l] === null && (o[l] = l === 0 ? s : o[l - 1]), rm(o[l]) && c.push(l), typeof o[l] == "string" && o[l] !== "none" && o[l] !== "0" && (a = o[l]);
  if (i && c.length && a)
    for (let l = 0; l < c.length; l++) {
      const u = c[l];
      o[u] = ga(t, a);
    }
  return o;
}
function om({ when: e, delay: t, delayChildren: n, staggerChildren: r, staggerDirection: i, repeat: o, repeatType: s, repeatDelay: a, from: c, elapsed: l, ...u }) {
  return !!Object.keys(u).length;
}
function ba(e, t) {
  return e[t] || e.default || e;
}
const Gr = (e, t, n, r = {}) => (i) => {
  const o = ba(r, e) || {}, s = o.delay || r.delay || 0;
  let { elapsed: a = 0 } = r;
  a = a - Te(s);
  const c = im(t, e, n, o), l = c[0], u = c[c.length - 1], d = dr(e, l), f = dr(e, u);
  Vt(d === f, `You are trying to animate ${e} from "${l}" to "${u}". ${l} is not an animatable value - to enable this animation set ${l} to a value animatable to ${u} via the \`style\` property.`);
  let h = {
    keyframes: c,
    velocity: t.getVelocity(),
    ease: "easeOut",
    ...o,
    delay: -a,
    onUpdate: (p) => {
      t.set(p), o.onUpdate && o.onUpdate(p);
    },
    onComplete: () => {
      i(), o.onComplete && o.onComplete();
    }
  };
  if (om(o) || (h = {
    ...h,
    ...Qh(e, h)
  }), h.duration && (h.duration = Te(h.duration)), h.repeatDelay && (h.repeatDelay = Te(h.repeatDelay)), !d || !f || sh.current || o.type === !1)
    return Gh(h);
  if (t.owner && t.owner.current instanceof HTMLElement && !t.owner.getProps().onUpdate) {
    const p = Uh(t, e, h);
    if (p)
      return p;
  }
  return cn(h);
};
function ln(e) {
  return !!(Z(e) && e.add);
}
const wa = (e) => /^\-?\d*\.?\d+$/.test(e);
function Kr(e, t) {
  e.indexOf(t) === -1 && e.push(t);
}
function Cn(e, t) {
  const n = e.indexOf(t);
  n > -1 && e.splice(n, 1);
}
class Zr {
  constructor() {
    this.subscriptions = [];
  }
  add(t) {
    return Kr(this.subscriptions, t), () => Cn(this.subscriptions, t);
  }
  notify(t, n, r) {
    const i = this.subscriptions.length;
    if (i)
      if (i === 1)
        this.subscriptions[0](t, n, r);
      else
        for (let o = 0; o < i; o++) {
          const s = this.subscriptions[o];
          s && s(t, n, r);
        }
  }
  getSize() {
    return this.subscriptions.length;
  }
  clear() {
    this.subscriptions.length = 0;
  }
}
const Ii = /* @__PURE__ */ new Set();
function Tn(e, t, n) {
  e || Ii.has(t) || (console.warn(t), n && console.warn(n), Ii.add(t));
}
const sm = (e) => !isNaN(parseFloat(e)), wt = {
  current: void 0
};
class am {
  /**
   * @param init - The initiating value
   * @param config - Optional configuration options
   *
   * -  `transformer`: A function to transform incoming values with.
   *
   * @internal
   */
  constructor(t, n = {}) {
    this.version = "10.16.4", this.timeDelta = 0, this.lastUpdated = 0, this.canTrackVelocity = !1, this.events = {}, this.updateAndNotify = (r, i = !0) => {
      this.prev = this.current, this.current = r;
      const { delta: o, timestamp: s } = G;
      this.lastUpdated !== s && (this.timeDelta = o, this.lastUpdated = s, V.postRender(this.scheduleVelocityCheck)), this.prev !== this.current && this.events.change && this.events.change.notify(this.current), this.events.velocityChange && this.events.velocityChange.notify(this.getVelocity()), i && this.events.renderRequest && this.events.renderRequest.notify(this.current);
    }, this.scheduleVelocityCheck = () => V.postRender(this.velocityCheck), this.velocityCheck = ({ timestamp: r }) => {
      r !== this.lastUpdated && (this.prev = this.current, this.events.velocityChange && this.events.velocityChange.notify(this.getVelocity()));
    }, this.hasAnimated = !1, this.prev = this.current = t, this.canTrackVelocity = sm(this.current), this.owner = n.owner;
  }
  /**
   * Adds a function that will be notified when the `MotionValue` is updated.
   *
   * It returns a function that, when called, will cancel the subscription.
   *
   * When calling `onChange` inside a React component, it should be wrapped with the
   * `useEffect` hook. As it returns an unsubscribe function, this should be returned
   * from the `useEffect` function to ensure you don't add duplicate subscribers..
   *
   * ```jsx
   * export const MyComponent = () => {
   *   const x = useMotionValue(0)
   *   const y = useMotionValue(0)
   *   const opacity = useMotionValue(1)
   *
   *   useEffect(() => {
   *     function updateOpacity() {
   *       const maxXY = Math.max(x.get(), y.get())
   *       const newOpacity = transform(maxXY, [0, 100], [1, 0])
   *       opacity.set(newOpacity)
   *     }
   *
   *     const unsubscribeX = x.on("change", updateOpacity)
   *     const unsubscribeY = y.on("change", updateOpacity)
   *
   *     return () => {
   *       unsubscribeX()
   *       unsubscribeY()
   *     }
   *   }, [])
   *
   *   return <motion.div style={{ x }} />
   * }
   * ```
   *
   * @param subscriber - A function that receives the latest value.
   * @returns A function that, when called, will cancel this subscription.
   *
   * @deprecated
   */
  onChange(t) {
    return process.env.NODE_ENV !== "production" && Tn(!1, 'value.onChange(callback) is deprecated. Switch to value.on("change", callback).'), this.on("change", t);
  }
  on(t, n) {
    this.events[t] || (this.events[t] = new Zr());
    const r = this.events[t].add(n);
    return t === "change" ? () => {
      r(), V.read(() => {
        this.events.change.getSize() || this.stop();
      });
    } : r;
  }
  clearListeners() {
    for (const t in this.events)
      this.events[t].clear();
  }
  /**
   * Attaches a passive effect to the `MotionValue`.
   *
   * @internal
   */
  attach(t, n) {
    this.passiveEffect = t, this.stopPassiveEffect = n;
  }
  /**
   * Sets the state of the `MotionValue`.
   *
   * @remarks
   *
   * ```jsx
   * const x = useMotionValue(0)
   * x.set(10)
   * ```
   *
   * @param latest - Latest value to set.
   * @param render - Whether to notify render subscribers. Defaults to `true`
   *
   * @public
   */
  set(t, n = !0) {
    !n || !this.passiveEffect ? this.updateAndNotify(t, n) : this.passiveEffect(t, this.updateAndNotify);
  }
  setWithVelocity(t, n, r) {
    this.set(n), this.prev = t, this.timeDelta = r;
  }
  /**
   * Set the state of the `MotionValue`, stopping any active animations,
   * effects, and resets velocity to `0`.
   */
  jump(t) {
    this.updateAndNotify(t), this.prev = t, this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
  }
  /**
   * Returns the latest state of `MotionValue`
   *
   * @returns - The latest state of `MotionValue`
   *
   * @public
   */
  get() {
    return wt.current && wt.current.push(this), this.current;
  }
  /**
   * @public
   */
  getPrevious() {
    return this.prev;
  }
  /**
   * Returns the latest velocity of `MotionValue`
   *
   * @returns - The latest velocity of `MotionValue`. Returns `0` if the state is non-numerical.
   *
   * @public
   */
  getVelocity() {
    return this.canTrackVelocity ? (
      // These casts could be avoided if parseFloat would be typed better
      ma(parseFloat(this.current) - parseFloat(this.prev), this.timeDelta)
    ) : 0;
  }
  /**
   * Registers a new animation to control this `MotionValue`. Only one
   * animation can drive a `MotionValue` at one time.
   *
   * ```jsx
   * value.start()
   * ```
   *
   * @param animation - A function that starts the provided animation
   *
   * @internal
   */
  start(t) {
    return this.stop(), new Promise((n) => {
      this.hasAnimated = !0, this.animation = t(n), this.events.animationStart && this.events.animationStart.notify();
    }).then(() => {
      this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation();
    });
  }
  /**
   * Stop the currently active animation.
   *
   * @public
   */
  stop() {
    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation();
  }
  /**
   * Returns `true` if this value is currently animating.
   *
   * @public
   */
  isAnimating() {
    return !!this.animation;
  }
  clearAnimation() {
    delete this.animation;
  }
  /**
   * Destroy and clean up subscribers to this `MotionValue`.
   *
   * The `MotionValue` hooks like `useMotionValue` and `useTransform` automatically
   * handle the lifecycle of the returned `MotionValue`, so this method is only necessary if you've manually
   * created a `MotionValue` via the `motionValue` function.
   *
   * @public
   */
  destroy() {
    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
  }
}
function We(e, t) {
  return new am(e, t);
}
const Ea = (e) => (t) => t.test(e), cm = {
  test: (e) => e === "auto",
  parse: (e) => e
}, Sa = [Ge, _, ye, De, wf, bf, cm], ht = (e) => Sa.find(Ea(e)), lm = [...Sa, Q, Le], um = (e) => lm.find(Ea(e));
function dm(e, t, n) {
  e.hasValue(t) ? e.getValue(t).set(n) : e.addValue(t, We(n));
}
function fm(e, t) {
  const n = xn(e, t);
  let { transitionEnd: r = {}, transition: i = {}, ...o } = n ? e.makeTargetAnimatable(n, !1) : {};
  o = { ...o, ...r };
  for (const s in o) {
    const a = Vf(o[s]);
    dm(e, s, a);
  }
}
function hm(e, t, n) {
  var r, i;
  const o = Object.keys(t).filter((a) => !e.hasValue(a)), s = o.length;
  if (s)
    for (let a = 0; a < s; a++) {
      const c = o[a], l = t[c];
      let u = null;
      Array.isArray(l) && (u = l[0]), u === null && (u = (i = (r = n[c]) !== null && r !== void 0 ? r : e.readValue(c)) !== null && i !== void 0 ? i : t[c]), u != null && (typeof u == "string" && (wa(u) || ya(u)) ? u = parseFloat(u) : !um(u) && Le.test(l) && (u = ga(c, l)), e.addValue(c, We(u, { owner: e })), n[c] === void 0 && (n[c] = u), u !== null && e.setBaseTarget(c, u));
    }
}
function mm(e, t) {
  return t ? (t[e] || t.default || t).from : void 0;
}
function pm(e, t, n) {
  const r = {};
  for (const i in e) {
    const o = mm(i, t);
    if (o !== void 0)
      r[i] = o;
    else {
      const s = n.getValue(i);
      s && (r[i] = s.get());
    }
  }
  return r;
}
function vm({ protectedKeys: e, needsAnimating: t }, n) {
  const r = e.hasOwnProperty(n) && t[n] !== !0;
  return t[n] = !1, r;
}
function Yr(e, t, { delay: n = 0, transitionOverride: r, type: i } = {}) {
  let { transition: o = e.getDefaultTransition(), transitionEnd: s, ...a } = e.makeTargetAnimatable(t);
  const c = e.getValue("willChange");
  r && (o = r);
  const l = [], u = i && e.animationState && e.animationState.getState()[i];
  for (const d in a) {
    const f = e.getValue(d), h = a[d];
    if (!f || h === void 0 || u && vm(u, d))
      continue;
    const p = {
      delay: n,
      elapsed: 0,
      ...o
    };
    if (window.HandoffAppearAnimations && !f.hasAnimated) {
      const b = e.getProps()[oh];
      b && (p.elapsed = window.HandoffAppearAnimations(b, d, f, V), p.syncStart = !0);
    }
    f.start(Gr(d, f, h, e.shouldReduceMotion && Ue.has(d) ? { type: !1 } : p));
    const m = f.animation;
    ln(c) && (c.add(d), m.then(() => c.remove(d))), l.push(m);
  }
  return s && Promise.all(l).then(() => {
    s && fm(e, s);
  }), l;
}
function hr(e, t, n = {}) {
  const r = xn(e, t, n.custom);
  let { transition: i = e.getDefaultTransition() || {} } = r || {};
  n.transitionOverride && (i = n.transitionOverride);
  const o = r ? () => Promise.all(Yr(e, r, n)) : () => Promise.resolve(), s = e.variantChildren && e.variantChildren.size ? (c = 0) => {
    const { delayChildren: l = 0, staggerChildren: u, staggerDirection: d } = i;
    return gm(e, t, l + c, u, d, n);
  } : () => Promise.resolve(), { when: a } = i;
  if (a) {
    const [c, l] = a === "beforeChildren" ? [o, s] : [s, o];
    return c().then(() => l());
  } else
    return Promise.all([o(), s(n.delay)]);
}
function gm(e, t, n = 0, r = 0, i = 1, o) {
  const s = [], a = (e.variantChildren.size - 1) * r, c = i === 1 ? (l = 0) => l * r : (l = 0) => a - l * r;
  return Array.from(e.variantChildren).sort(ym).forEach((l, u) => {
    l.notify("AnimationStart", t), s.push(hr(l, t, {
      ...o,
      delay: n + c(u)
    }).then(() => l.notify("AnimationComplete", t)));
  }), Promise.all(s);
}
function ym(e, t) {
  return e.sortNodePosition(t);
}
function bm(e, t, n = {}) {
  e.notify("AnimationStart", t);
  let r;
  if (Array.isArray(t)) {
    const i = t.map((o) => hr(e, o, n));
    r = Promise.all(i);
  } else if (typeof t == "string")
    r = hr(e, t, n);
  else {
    const i = typeof t == "function" ? xn(e, t, n.custom) : t;
    r = Promise.all(Yr(e, i, n));
  }
  return r.then(() => e.notify("AnimationComplete", t));
}
const wm = [...Dr].reverse(), Em = Dr.length;
function Sm(e) {
  return (t) => Promise.all(t.map(({ animation: n, options: r }) => bm(e, n, r)));
}
function xm(e) {
  let t = Sm(e);
  const n = Tm();
  let r = !0;
  const i = (c, l) => {
    const u = xn(e, l);
    if (u) {
      const { transition: d, transitionEnd: f, ...h } = u;
      c = { ...c, ...h, ...f };
    }
    return c;
  };
  function o(c) {
    t = c(e);
  }
  function s(c, l) {
    const u = e.getProps(), d = e.getVariantContext(!0) || {}, f = [], h = /* @__PURE__ */ new Set();
    let p = {}, m = 1 / 0;
    for (let w = 0; w < Em; w++) {
      const y = wm[w], g = n[y], E = u[y] !== void 0 ? u[y] : d[y], x = Tt(E), C = y === l ? g.isActive : null;
      C === !1 && (m = w);
      let T = E === d[y] && E !== u[y] && x;
      if (T && r && e.manuallyAnimateOnMount && (T = !1), g.protectedKeys = { ...p }, // If it isn't active and hasn't *just* been set as inactive
      !g.isActive && C === null || // If we didn't and don't have any defined prop for this animation type
      !E && !g.prevProp || // Or if the prop doesn't define an animation
      yn(E) || typeof E == "boolean")
        continue;
      const S = Cm(g.prevProp, E);
      let R = S || // If we're making this variant active, we want to always make it active
      y === l && g.isActive && !T && x || // If we removed a higher-priority variant (i is in reverse order)
      w > m && x;
      const N = Array.isArray(E) ? E : [E];
      let W = N.reduce(i, {});
      C === !1 && (W = {});
      const { prevResolvedValues: Y = {} } = g, U = {
        ...Y,
        ...W
      }, M = (O) => {
        R = !0, h.delete(O), g.needsAnimating[O] = !0;
      };
      for (const O in U) {
        const X = W[O], z = Y[O];
        p.hasOwnProperty(O) || (X !== z ? on(X) && on(z) ? !js(X, z) || S ? M(O) : g.protectedKeys[O] = !0 : X !== void 0 ? M(O) : h.add(O) : X !== void 0 && h.has(O) ? M(O) : g.protectedKeys[O] = !0);
      }
      g.prevProp = E, g.prevResolvedValues = W, g.isActive && (p = { ...p, ...W }), r && e.blockInitialAnimation && (R = !1), R && !T && f.push(...N.map((O) => ({
        animation: O,
        options: { type: y, ...c }
      })));
    }
    if (h.size) {
      const w = {};
      h.forEach((y) => {
        const g = e.getBaseTarget(y);
        g !== void 0 && (w[y] = g);
      }), f.push({ animation: w });
    }
    let b = !!f.length;
    return r && u.initial === !1 && !e.manuallyAnimateOnMount && (b = !1), r = !1, b ? t(f) : Promise.resolve();
  }
  function a(c, l, u) {
    var d;
    if (n[c].isActive === l)
      return Promise.resolve();
    (d = e.variantChildren) === null || d === void 0 || d.forEach((h) => {
      var p;
      return (p = h.animationState) === null || p === void 0 ? void 0 : p.setActive(c, l);
    }), n[c].isActive = l;
    const f = s(u, c);
    for (const h in n)
      n[h].protectedKeys = {};
    return f;
  }
  return {
    animateChanges: s,
    setActive: a,
    setAnimateFunction: o,
    getState: () => n
  };
}
function Cm(e, t) {
  return typeof t == "string" ? t !== e : Array.isArray(t) ? !js(t, e) : !1;
}
function Be(e = !1) {
  return {
    isActive: e,
    protectedKeys: {},
    needsAnimating: {},
    prevResolvedValues: {}
  };
}
function Tm() {
  return {
    animate: Be(!0),
    whileInView: Be(),
    whileHover: Be(),
    whileTap: Be(),
    whileDrag: Be(),
    whileFocus: Be(),
    exit: Be()
  };
}
class Pm extends Oe {
  /**
   * We dynamically generate the AnimationState manager as it contains a reference
   * to the underlying animation library. We only want to load that if we load this,
   * so people can optionally code split it out using the `m` component.
   */
  constructor(t) {
    super(t), t.animationState || (t.animationState = xm(t));
  }
  updateAnimationControlsSubscription() {
    const { animate: t } = this.node.getProps();
    this.unmount(), yn(t) && (this.unmount = t.subscribe(this.node));
  }
  /**
   * Subscribe any provided AnimationControls to the component's VisualElement
   */
  mount() {
    this.updateAnimationControlsSubscription();
  }
  update() {
    const { animate: t } = this.node.getProps(), { animate: n } = this.node.prevProps || {};
    t !== n && this.updateAnimationControlsSubscription();
  }
  unmount() {
  }
}
let _m = 0;
class Rm extends Oe {
  constructor() {
    super(...arguments), this.id = _m++;
  }
  update() {
    if (!this.node.presenceContext)
      return;
    const { isPresent: t, onExitComplete: n, custom: r } = this.node.presenceContext, { isPresent: i } = this.node.prevPresenceContext || {};
    if (!this.node.animationState || t === i)
      return;
    const o = this.node.animationState.setActive("exit", !t, { custom: r ?? this.node.getProps().custom });
    n && !t && o.then(() => n(this.id));
  }
  mount() {
    const { register: t } = this.node.presenceContext || {};
    t && (this.unmount = t(this.id));
  }
  unmount() {
  }
}
const Am = {
  animation: {
    Feature: Pm
  },
  exit: {
    Feature: Rm
  }
}, zi = (e, t) => Math.abs(e - t);
function Dm(e, t) {
  const n = zi(e.x, t.x), r = zi(e.y, t.y);
  return Math.sqrt(n ** 2 + r ** 2);
}
class xa {
  constructor(t, n, { transformPagePoint: r } = {}) {
    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.updatePoint = () => {
      if (!(this.lastMoveEvent && this.lastMoveEventInfo))
        return;
      const l = Un(this.lastMoveEventInfo, this.history), u = this.startEvent !== null, d = Dm(l.offset, { x: 0, y: 0 }) >= 3;
      if (!u && !d)
        return;
      const { point: f } = l, { timestamp: h } = G;
      this.history.push({ ...f, timestamp: h });
      const { onStart: p, onMove: m } = this.handlers;
      u || (p && p(this.lastMoveEvent, l), this.startEvent = this.lastMoveEvent), m && m(this.lastMoveEvent, l);
    }, this.handlePointerMove = (l, u) => {
      this.lastMoveEvent = l, this.lastMoveEventInfo = Wn(u, this.transformPagePoint), V.update(this.updatePoint, !0);
    }, this.handlePointerUp = (l, u) => {
      if (this.end(), !(this.lastMoveEvent && this.lastMoveEventInfo))
        return;
      const { onEnd: d, onSessionEnd: f } = this.handlers, h = Un(l.type === "pointercancel" ? this.lastMoveEventInfo : Wn(u, this.transformPagePoint), this.history);
      this.startEvent && d && d(l, h), f && f(l, h);
    }, !qs(t))
      return;
    this.handlers = n, this.transformPagePoint = r;
    const i = Sn(t), o = Wn(i, this.transformPagePoint), { point: s } = o, { timestamp: a } = G;
    this.history = [{ ...s, timestamp: a }];
    const { onSessionStart: c } = n;
    c && c(t, Un(o, this.history)), this.removeListeners = ke(Ce(window, "pointermove", this.handlePointerMove), Ce(window, "pointerup", this.handlePointerUp), Ce(window, "pointercancel", this.handlePointerUp));
  }
  updateHandlers(t) {
    this.handlers = t;
  }
  end() {
    this.removeListeners && this.removeListeners(), he(this.updatePoint);
  }
}
function Wn(e, t) {
  return t ? { point: t(e.point) } : e;
}
function ji(e, t) {
  return { x: e.x - t.x, y: e.y - t.y };
}
function Un({ point: e }, t) {
  return {
    point: e,
    delta: ji(e, Ca(t)),
    offset: ji(e, Mm(t)),
    velocity: km(t, 0.1)
  };
}
function Mm(e) {
  return e[0];
}
function Ca(e) {
  return e[e.length - 1];
}
function km(e, t) {
  if (e.length < 2)
    return { x: 0, y: 0 };
  let n = e.length - 1, r = null;
  const i = Ca(e);
  for (; n >= 0 && (r = e[n], !(i.timestamp - r.timestamp > Te(t))); )
    n--;
  if (!r)
    return { x: 0, y: 0 };
  const o = be(i.timestamp - r.timestamp);
  if (o === 0)
    return { x: 0, y: 0 };
  const s = {
    x: (i.x - r.x) / o,
    y: (i.y - r.y) / o
  };
  return s.x === 1 / 0 && (s.x = 0), s.y === 1 / 0 && (s.y = 0), s;
}
function ie(e) {
  return e.max - e.min;
}
function mr(e, t = 0, n = 0.01) {
  return Math.abs(e - t) <= n;
}
function Hi(e, t, n, r = 0.5) {
  e.origin = r, e.originPoint = F(t.min, t.max, e.origin), e.scale = ie(n) / ie(t), (mr(e.scale, 1, 1e-4) || isNaN(e.scale)) && (e.scale = 1), e.translate = F(n.min, n.max, e.origin) - e.originPoint, (mr(e.translate) || isNaN(e.translate)) && (e.translate = 0);
}
function Et(e, t, n, r) {
  Hi(e.x, t.x, n.x, r ? r.originX : void 0), Hi(e.y, t.y, n.y, r ? r.originY : void 0);
}
function Wi(e, t, n) {
  e.min = n.min + t.min, e.max = e.min + ie(t);
}
function $m(e, t, n) {
  Wi(e.x, t.x, n.x), Wi(e.y, t.y, n.y);
}
function Ui(e, t, n) {
  e.min = t.min - n.min, e.max = e.min + ie(t);
}
function St(e, t, n) {
  Ui(e.x, t.x, n.x), Ui(e.y, t.y, n.y);
}
function Vm(e, { min: t, max: n }, r) {
  return t !== void 0 && e < t ? e = r ? F(t, e, r.min) : Math.max(e, t) : n !== void 0 && e > n && (e = r ? F(n, e, r.max) : Math.min(e, n)), e;
}
function Gi(e, t, n) {
  return {
    min: t !== void 0 ? e.min + t : void 0,
    max: n !== void 0 ? e.max + n - (e.max - e.min) : void 0
  };
}
function Lm(e, { top: t, left: n, bottom: r, right: i }) {
  return {
    x: Gi(e.x, n, i),
    y: Gi(e.y, t, r)
  };
}
function Ki(e, t) {
  let n = t.min - e.min, r = t.max - e.max;
  return t.max - t.min < e.max - e.min && ([n, r] = [r, n]), { min: n, max: r };
}
function Nm(e, t) {
  return {
    x: Ki(e.x, t.x),
    y: Ki(e.y, t.y)
  };
}
function Om(e, t) {
  let n = 0.5;
  const r = ie(e), i = ie(t);
  return i > r ? n = at(t.min, t.max - r, e.min) : r > i && (n = at(e.min, e.max - i, t.min)), Ve(0, 1, n);
}
function qm(e, t) {
  const n = {};
  return t.min !== void 0 && (n.min = t.min - e.min), t.max !== void 0 && (n.max = t.max - e.min), n;
}
const pr = 0.35;
function Bm(e = pr) {
  return e === !1 ? e = 0 : e === !0 && (e = pr), {
    x: Zi(e, "left", "right"),
    y: Zi(e, "top", "bottom")
  };
}
function Zi(e, t, n) {
  return {
    min: Yi(e, t),
    max: Yi(e, n)
  };
}
function Yi(e, t) {
  return typeof e == "number" ? e : e[t] || 0;
}
const Xi = () => ({
  translate: 0,
  scale: 1,
  origin: 0,
  originPoint: 0
}), rt = () => ({
  x: Xi(),
  y: Xi()
}), Qi = () => ({ min: 0, max: 0 }), j = () => ({
  x: Qi(),
  y: Qi()
});
function ve(e) {
  return [e("x"), e("y")];
}
function Ta({ top: e, left: t, right: n, bottom: r }) {
  return {
    x: { min: t, max: n },
    y: { min: e, max: r }
  };
}
function Fm({ x: e, y: t }) {
  return { top: t.min, right: e.max, bottom: t.max, left: e.min };
}
function Im(e, t) {
  if (!t)
    return e;
  const n = t({ x: e.left, y: e.top }), r = t({ x: e.right, y: e.bottom });
  return {
    top: n.y,
    left: n.x,
    bottom: r.y,
    right: r.x
  };
}
function Gn(e) {
  return e === void 0 || e === 1;
}
function vr({ scale: e, scaleX: t, scaleY: n }) {
  return !Gn(e) || !Gn(t) || !Gn(n);
}
function Fe(e) {
  return vr(e) || Pa(e) || e.z || e.rotate || e.rotateX || e.rotateY;
}
function Pa(e) {
  return Ji(e.x) || Ji(e.y);
}
function Ji(e) {
  return e && e !== "0%";
}
function un(e, t, n) {
  const r = e - n, i = t * r;
  return n + i;
}
function eo(e, t, n, r, i) {
  return i !== void 0 && (e = un(e, i, r)), un(e, n, r) + t;
}
function gr(e, t = 0, n = 1, r, i) {
  e.min = eo(e.min, t, n, r, i), e.max = eo(e.max, t, n, r, i);
}
function _a(e, { x: t, y: n }) {
  gr(e.x, t.translate, t.scale, t.originPoint), gr(e.y, n.translate, n.scale, n.originPoint);
}
function zm(e, t, n, r = !1) {
  const i = n.length;
  if (!i)
    return;
  t.x = t.y = 1;
  let o, s;
  for (let a = 0; a < i; a++) {
    o = n[a], s = o.projectionDelta;
    const c = o.instance;
    c && c.style && c.style.display === "contents" || (r && o.options.layoutScroll && o.scroll && o !== o.root && it(e, {
      x: -o.scroll.offset.x,
      y: -o.scroll.offset.y
    }), s && (t.x *= s.x.scale, t.y *= s.y.scale, _a(e, s)), r && Fe(o.latestValues) && it(e, o.latestValues));
  }
  t.x = to(t.x), t.y = to(t.y);
}
function to(e) {
  return Number.isInteger(e) || e > 1.0000000000001 || e < 0.999999999999 ? e : 1;
}
function Me(e, t) {
  e.min = e.min + t, e.max = e.max + t;
}
function no(e, t, [n, r, i]) {
  const o = t[i] !== void 0 ? t[i] : 0.5, s = F(e.min, e.max, o);
  gr(e, t[n], t[r], s, t.scale);
}
const jm = ["x", "scaleX", "originX"], Hm = ["y", "scaleY", "originY"];
function it(e, t) {
  no(e.x, t, jm), no(e.y, t, Hm);
}
function Ra(e, t) {
  return Ta(Im(e.getBoundingClientRect(), t));
}
function Wm(e, t, n) {
  const r = Ra(e, n), { scroll: i } = t;
  return i && (Me(r.x, i.offset.x), Me(r.y, i.offset.y)), r;
}
const Um = /* @__PURE__ */ new WeakMap();
class Gm {
  constructor(t) {
    this.openGlobalLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = { x: 0, y: 0 }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = j(), this.visualElement = t;
  }
  start(t, { snapToCursor: n = !1 } = {}) {
    const { presenceContext: r } = this.visualElement;
    if (r && r.isPresent === !1)
      return;
    const i = (c) => {
      this.stopAnimation(), n && this.snapToCursor(Sn(c, "page").point);
    }, o = (c, l) => {
      const { drag: u, dragPropagation: d, onDragStart: f } = this.getProps();
      if (u && !d && (this.openGlobalLock && this.openGlobalLock(), this.openGlobalLock = Fs(u), !this.openGlobalLock))
        return;
      this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), ve((p) => {
        let m = this.getAxisMotionValue(p).get() || 0;
        if (ye.test(m)) {
          const { projection: b } = this.visualElement;
          if (b && b.layout) {
            const w = b.layout.layoutBox[p];
            w && (m = ie(w) * (parseFloat(m) / 100));
          }
        }
        this.originPoint[p] = m;
      }), f && V.update(() => f(c, l), !1, !0);
      const { animationState: h } = this.visualElement;
      h && h.setActive("whileDrag", !0);
    }, s = (c, l) => {
      const { dragPropagation: u, dragDirectionLock: d, onDirectionLock: f, onDrag: h } = this.getProps();
      if (!u && !this.openGlobalLock)
        return;
      const { offset: p } = l;
      if (d && this.currentDirection === null) {
        this.currentDirection = Km(p), this.currentDirection !== null && f && f(this.currentDirection);
        return;
      }
      this.updateAxis("x", l.point, p), this.updateAxis("y", l.point, p), this.visualElement.render(), h && h(c, l);
    }, a = (c, l) => this.stop(c, l);
    this.panSession = new xa(t, {
      onSessionStart: i,
      onStart: o,
      onMove: s,
      onSessionEnd: a
    }, { transformPagePoint: this.visualElement.getTransformPagePoint() });
  }
  stop(t, n) {
    const r = this.isDragging;
    if (this.cancel(), !r)
      return;
    const { velocity: i } = n;
    this.startAnimation(i);
    const { onDragEnd: o } = this.getProps();
    o && V.update(() => o(t, n));
  }
  cancel() {
    this.isDragging = !1;
    const { projection: t, animationState: n } = this.visualElement;
    t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
    const { dragPropagation: r } = this.getProps();
    !r && this.openGlobalLock && (this.openGlobalLock(), this.openGlobalLock = null), n && n.setActive("whileDrag", !1);
  }
  updateAxis(t, n, r) {
    const { drag: i } = this.getProps();
    if (!r || !Gt(t, i, this.currentDirection))
      return;
    const o = this.getAxisMotionValue(t);
    let s = this.originPoint[t] + r[t];
    this.constraints && this.constraints[t] && (s = Vm(s, this.constraints[t], this.elastic[t])), o.set(s);
  }
  resolveConstraints() {
    const { dragConstraints: t, dragElastic: n } = this.getProps(), { layout: r } = this.visualElement.projection || {}, i = this.constraints;
    t && tt(t) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : t && r ? this.constraints = Lm(r.layoutBox, t) : this.constraints = !1, this.elastic = Bm(n), i !== this.constraints && r && this.constraints && !this.hasMutatedConstraints && ve((o) => {
      this.getAxisMotionValue(o) && (this.constraints[o] = qm(r.layoutBox[o], this.constraints[o]));
    });
  }
  resolveRefConstraints() {
    const { dragConstraints: t, onMeasureDragConstraints: n } = this.getProps();
    if (!t || !tt(t))
      return !1;
    const r = t.current;
    re(r !== null, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
    const { projection: i } = this.visualElement;
    if (!i || !i.layout)
      return !1;
    const o = Wm(r, i.root, this.visualElement.getTransformPagePoint());
    let s = Nm(i.layout.layoutBox, o);
    if (n) {
      const a = n(Fm(s));
      this.hasMutatedConstraints = !!a, a && (s = Ta(a));
    }
    return s;
  }
  startAnimation(t) {
    const { drag: n, dragMomentum: r, dragElastic: i, dragTransition: o, dragSnapToOrigin: s, onDragTransitionEnd: a } = this.getProps(), c = this.constraints || {}, l = ve((u) => {
      if (!Gt(u, n, this.currentDirection))
        return;
      let d = c && c[u] || {};
      s && (d = { min: 0, max: 0 });
      const f = i ? 200 : 1e6, h = i ? 40 : 1e7, p = {
        type: "inertia",
        velocity: r ? t[u] : 0,
        bounceStiffness: f,
        bounceDamping: h,
        timeConstant: 750,
        restDelta: 1,
        restSpeed: 10,
        ...o,
        ...d
      };
      return this.startAxisValueAnimation(u, p);
    });
    return Promise.all(l).then(a);
  }
  startAxisValueAnimation(t, n) {
    const r = this.getAxisMotionValue(t);
    return r.start(Gr(t, r, 0, n));
  }
  stopAnimation() {
    ve((t) => this.getAxisMotionValue(t).stop());
  }
  /**
   * Drag works differently depending on which props are provided.
   *
   * - If _dragX and _dragY are provided, we output the gesture delta directly to those motion values.
   * - Otherwise, we apply the delta to the x/y motion values.
   */
  getAxisMotionValue(t) {
    const n = "_drag" + t.toUpperCase(), r = this.visualElement.getProps(), i = r[n];
    return i || this.visualElement.getValue(t, (r.initial ? r.initial[t] : void 0) || 0);
  }
  snapToCursor(t) {
    ve((n) => {
      const { drag: r } = this.getProps();
      if (!Gt(n, r, this.currentDirection))
        return;
      const { projection: i } = this.visualElement, o = this.getAxisMotionValue(n);
      if (i && i.layout) {
        const { min: s, max: a } = i.layout.layoutBox[n];
        o.set(t[n] - F(s, a, 0.5));
      }
    });
  }
  /**
   * When the viewport resizes we want to check if the measured constraints
   * have changed and, if so, reposition the element within those new constraints
   * relative to where it was before the resize.
   */
  scalePositionWithinConstraints() {
    if (!this.visualElement.current)
      return;
    const { drag: t, dragConstraints: n } = this.getProps(), { projection: r } = this.visualElement;
    if (!tt(n) || !r || !this.constraints)
      return;
    this.stopAnimation();
    const i = { x: 0, y: 0 };
    ve((s) => {
      const a = this.getAxisMotionValue(s);
      if (a) {
        const c = a.get();
        i[s] = Om({ min: c, max: c }, this.constraints[s]);
      }
    });
    const { transformTemplate: o } = this.visualElement.getProps();
    this.visualElement.current.style.transform = o ? o({}, "") : "none", r.root && r.root.updateScroll(), r.updateLayout(), this.resolveConstraints(), ve((s) => {
      if (!Gt(s, t, null))
        return;
      const a = this.getAxisMotionValue(s), { min: c, max: l } = this.constraints[s];
      a.set(F(c, l, i[s]));
    });
  }
  addListeners() {
    if (!this.visualElement.current)
      return;
    Um.set(this.visualElement, this);
    const t = this.visualElement.current, n = Ce(t, "pointerdown", (c) => {
      const { drag: l, dragListener: u = !0 } = this.getProps();
      l && u && this.start(c);
    }), r = () => {
      const { dragConstraints: c } = this.getProps();
      tt(c) && (this.constraints = this.resolveRefConstraints());
    }, { projection: i } = this.visualElement, o = i.addEventListener("measure", r);
    i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), r();
    const s = Se(window, "resize", () => this.scalePositionWithinConstraints()), a = i.addEventListener("didUpdate", ({ delta: c, hasLayoutChanged: l }) => {
      this.isDragging && l && (ve((u) => {
        const d = this.getAxisMotionValue(u);
        d && (this.originPoint[u] += c[u].translate, d.set(d.get() + c[u].translate));
      }), this.visualElement.render());
    });
    return () => {
      s(), n(), o(), a && a();
    };
  }
  getProps() {
    const t = this.visualElement.getProps(), { drag: n = !1, dragDirectionLock: r = !1, dragPropagation: i = !1, dragConstraints: o = !1, dragElastic: s = pr, dragMomentum: a = !0 } = t;
    return {
      ...t,
      drag: n,
      dragDirectionLock: r,
      dragPropagation: i,
      dragConstraints: o,
      dragElastic: s,
      dragMomentum: a
    };
  }
}
function Gt(e, t, n) {
  return (t === !0 || t === e) && (n === null || n === e);
}
function Km(e, t = 10) {
  let n = null;
  return Math.abs(e.y) > t ? n = "y" : Math.abs(e.x) > t && (n = "x"), n;
}
class Zm extends Oe {
  constructor(t) {
    super(t), this.removeGroupControls = I, this.removeListeners = I, this.controls = new Gm(t);
  }
  mount() {
    const { dragControls: t } = this.node.getProps();
    t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || I;
  }
  unmount() {
    this.removeGroupControls(), this.removeListeners();
  }
}
const ro = (e) => (t, n) => {
  e && V.update(() => e(t, n));
};
class Ym extends Oe {
  constructor() {
    super(...arguments), this.removePointerDownListener = I;
  }
  onPointerDown(t) {
    this.session = new xa(t, this.createPanHandlers(), { transformPagePoint: this.node.getTransformPagePoint() });
  }
  createPanHandlers() {
    const { onPanSessionStart: t, onPanStart: n, onPan: r, onPanEnd: i } = this.node.getProps();
    return {
      onSessionStart: ro(t),
      onStart: ro(n),
      onMove: r,
      onEnd: (o, s) => {
        delete this.session, i && V.update(() => i(o, s));
      }
    };
  }
  mount() {
    this.removePointerDownListener = Ce(this.node.current, "pointerdown", (t) => this.onPointerDown(t));
  }
  update() {
    this.session && this.session.updateHandlers(this.createPanHandlers());
  }
  unmount() {
    this.removePointerDownListener(), this.session && this.session.end();
  }
}
function Xm() {
  const e = H(pn);
  if (e === null)
    return [!0, null];
  const { isPresent: t, onExitComplete: n, register: r } = e, i = Sr();
  return k(() => r(i), []), !t && n ? [!1, () => n && n(i)] : [!0];
}
const Jt = {
  /**
   * Global flag as to whether the tree has animated since the last time
   * we resized the window
   */
  hasAnimatedSinceResize: !0,
  /**
   * We set this to true once, on the first update. Any nodes added to the tree beyond that
   * update will be given a `data-projection-id` attribute.
   */
  hasEverUpdated: !1
};
function io(e, t) {
  return t.max === t.min ? 0 : e / (t.max - t.min) * 100;
}
const mt = {
  correct: (e, t) => {
    if (!t.target)
      return e;
    if (typeof e == "string")
      if (_.test(e))
        e = parseFloat(e);
      else
        return e;
    const n = io(e, t.target.x), r = io(e, t.target.y);
    return `${n}% ${r}%`;
  }
}, Qm = {
  correct: (e, { treeScale: t, projectionDelta: n }) => {
    const r = e, i = Le.parse(e);
    if (i.length > 5)
      return r;
    const o = Le.createTransformer(e), s = typeof i[0] != "number" ? 1 : 0, a = n.x.scale * t.x, c = n.y.scale * t.y;
    i[0 + s] /= a, i[1 + s] /= c;
    const l = F(a, c, 0.5);
    return typeof i[2 + s] == "number" && (i[2 + s] /= l), typeof i[3 + s] == "number" && (i[3 + s] /= l), o(i);
  }
};
class Jm extends v.Component {
  /**
   * This only mounts projection nodes for components that
   * need measuring, we might want to do it for all components
   * in order to incorporate transforms
   */
  componentDidMount() {
    const { visualElement: t, layoutGroup: n, switchLayoutGroup: r, layoutId: i } = this.props, { projection: o } = t;
    ff(ep), o && (n.group && n.group.add(o), r && r.register && i && r.register(o), o.root.didUpdate(), o.addEventListener("animationComplete", () => {
      this.safeToRemove();
    }), o.setOptions({
      ...o.options,
      onExitComplete: () => this.safeToRemove()
    })), Jt.hasEverUpdated = !0;
  }
  getSnapshotBeforeUpdate(t) {
    const { layoutDependency: n, visualElement: r, drag: i, isPresent: o } = this.props, s = r.projection;
    return s && (s.isPresent = o, i || t.layoutDependency !== n || n === void 0 ? s.willUpdate() : this.safeToRemove(), t.isPresent !== o && (o ? s.promote() : s.relegate() || V.postRender(() => {
      const a = s.getStack();
      (!a || !a.members.length) && this.safeToRemove();
    }))), null;
  }
  componentDidUpdate() {
    const { projection: t } = this.props.visualElement;
    t && (t.root.didUpdate(), queueMicrotask(() => {
      !t.currentAnimation && t.isLead() && this.safeToRemove();
    }));
  }
  componentWillUnmount() {
    const { visualElement: t, layoutGroup: n, switchLayoutGroup: r } = this.props, { projection: i } = t;
    i && (i.scheduleCheckAfterUnmount(), n && n.group && n.group.remove(i), r && r.deregister && r.deregister(i));
  }
  safeToRemove() {
    const { safeToRemove: t } = this.props;
    t && t();
  }
  render() {
    return null;
  }
}
function Aa(e) {
  const [t, n] = Xm(), r = H(kr);
  return v.createElement(Jm, { ...e, layoutGroup: r, switchLayoutGroup: H(Cs), isPresent: t, safeToRemove: n });
}
const ep = {
  borderRadius: {
    ...mt,
    applyTo: [
      "borderTopLeftRadius",
      "borderTopRightRadius",
      "borderBottomLeftRadius",
      "borderBottomRightRadius"
    ]
  },
  borderTopLeftRadius: mt,
  borderTopRightRadius: mt,
  borderBottomLeftRadius: mt,
  borderBottomRightRadius: mt,
  boxShadow: Qm
}, Da = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"], tp = Da.length, oo = (e) => typeof e == "string" ? parseFloat(e) : e, so = (e) => typeof e == "number" || _.test(e);
function np(e, t, n, r, i, o) {
  i ? (e.opacity = F(
    0,
    // TODO Reinstate this if only child
    n.opacity !== void 0 ? n.opacity : 1,
    rp(r)
  ), e.opacityExit = F(t.opacity !== void 0 ? t.opacity : 1, 0, ip(r))) : o && (e.opacity = F(t.opacity !== void 0 ? t.opacity : 1, n.opacity !== void 0 ? n.opacity : 1, r));
  for (let s = 0; s < tp; s++) {
    const a = `border${Da[s]}Radius`;
    let c = ao(t, a), l = ao(n, a);
    if (c === void 0 && l === void 0)
      continue;
    c || (c = 0), l || (l = 0), c === 0 || l === 0 || so(c) === so(l) ? (e[a] = Math.max(F(oo(c), oo(l), r), 0), (ye.test(l) || ye.test(c)) && (e[a] += "%")) : e[a] = l;
  }
  (t.rotate || n.rotate) && (e.rotate = F(t.rotate || 0, n.rotate || 0, r));
}
function ao(e, t) {
  return e[t] !== void 0 ? e[t] : e.borderRadius;
}
const rp = Ma(0, 0.5, Ir), ip = Ma(0.5, 0.95, I);
function Ma(e, t, n) {
  return (r) => r < e ? 0 : r > t ? 1 : n(at(e, t, r));
}
function co(e, t) {
  e.min = t.min, e.max = t.max;
}
function ae(e, t) {
  co(e.x, t.x), co(e.y, t.y);
}
function lo(e, t, n, r, i) {
  return e -= t, e = un(e, 1 / n, r), i !== void 0 && (e = un(e, 1 / i, r)), e;
}
function op(e, t = 0, n = 1, r = 0.5, i, o = e, s = e) {
  if (ye.test(t) && (t = parseFloat(t), t = F(s.min, s.max, t / 100) - s.min), typeof t != "number")
    return;
  let a = F(o.min, o.max, r);
  e === o && (a -= t), e.min = lo(e.min, t, n, a, i), e.max = lo(e.max, t, n, a, i);
}
function uo(e, t, [n, r, i], o, s) {
  op(e, t[n], t[r], t[i], t.scale, o, s);
}
const sp = ["x", "scaleX", "originX"], ap = ["y", "scaleY", "originY"];
function fo(e, t, n, r) {
  uo(e.x, t, sp, n ? n.x : void 0, r ? r.x : void 0), uo(e.y, t, ap, n ? n.y : void 0, r ? r.y : void 0);
}
function ho(e) {
  return e.translate === 0 && e.scale === 1;
}
function ka(e) {
  return ho(e.x) && ho(e.y);
}
function cp(e, t) {
  return e.x.min === t.x.min && e.x.max === t.x.max && e.y.min === t.y.min && e.y.max === t.y.max;
}
function $a(e, t) {
  return Math.round(e.x.min) === Math.round(t.x.min) && Math.round(e.x.max) === Math.round(t.x.max) && Math.round(e.y.min) === Math.round(t.y.min) && Math.round(e.y.max) === Math.round(t.y.max);
}
function mo(e) {
  return ie(e.x) / ie(e.y);
}
class lp {
  constructor() {
    this.members = [];
  }
  add(t) {
    Kr(this.members, t), t.scheduleRender();
  }
  remove(t) {
    if (Cn(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
      const n = this.members[this.members.length - 1];
      n && this.promote(n);
    }
  }
  relegate(t) {
    const n = this.members.findIndex((i) => t === i);
    if (n === 0)
      return !1;
    let r;
    for (let i = n; i >= 0; i--) {
      const o = this.members[i];
      if (o.isPresent !== !1) {
        r = o;
        break;
      }
    }
    return r ? (this.promote(r), !0) : !1;
  }
  promote(t, n) {
    const r = this.lead;
    if (t !== r && (this.prevLead = r, this.lead = t, t.show(), r)) {
      r.instance && r.scheduleRender(), t.scheduleRender(), t.resumeFrom = r, n && (t.resumeFrom.preserveOpacity = !0), r.snapshot && (t.snapshot = r.snapshot, t.snapshot.latestValues = r.animationValues || r.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
      const { crossfade: i } = t.options;
      i === !1 && r.hide();
    }
  }
  exitAnimationComplete() {
    this.members.forEach((t) => {
      const { options: n, resumingFrom: r } = t;
      n.onExitComplete && n.onExitComplete(), r && r.options.onExitComplete && r.options.onExitComplete();
    });
  }
  scheduleRender() {
    this.members.forEach((t) => {
      t.instance && t.scheduleRender(!1);
    });
  }
  /**
   * Clear any leads that have been removed this render to prevent them from being
   * used in future animations and to prevent memory leaks
   */
  removeLeadSnapshot() {
    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0);
  }
}
function po(e, t, n) {
  let r = "";
  const i = e.x.translate / t.x, o = e.y.translate / t.y;
  if ((i || o) && (r = `translate3d(${i}px, ${o}px, 0) `), (t.x !== 1 || t.y !== 1) && (r += `scale(${1 / t.x}, ${1 / t.y}) `), n) {
    const { rotate: c, rotateX: l, rotateY: u } = n;
    c && (r += `rotate(${c}deg) `), l && (r += `rotateX(${l}deg) `), u && (r += `rotateY(${u}deg) `);
  }
  const s = e.x.scale * t.x, a = e.y.scale * t.y;
  return (s !== 1 || a !== 1) && (r += `scale(${s}, ${a})`), r || "none";
}
const up = (e, t) => e.depth - t.depth;
class dp {
  constructor() {
    this.children = [], this.isDirty = !1;
  }
  add(t) {
    Kr(this.children, t), this.isDirty = !0;
  }
  remove(t) {
    Cn(this.children, t), this.isDirty = !0;
  }
  forEach(t) {
    this.isDirty && this.children.sort(up), this.isDirty = !1, this.children.forEach(t);
  }
}
function fp(e, t) {
  const n = performance.now(), r = ({ timestamp: i }) => {
    const o = i - n;
    o >= t && (he(r), e(o - t));
  };
  return V.read(r, !0), () => he(r);
}
function hp(e) {
  window.MotionDebug && window.MotionDebug.record(e);
}
function Va(e) {
  return e instanceof SVGElement && e.tagName !== "svg";
}
function Xr(e, t, n) {
  const r = Z(e) ? e : We(e);
  return r.start(Gr("", r, t, n)), r.animation;
}
const vo = ["", "X", "Y", "Z"], go = 1e3;
let mp = 0;
const Ie = {
  type: "projectionFrame",
  totalNodes: 0,
  resolvedTargetDeltas: 0,
  recalculatedProjection: 0
};
function La({ attachResizeListener: e, defaultParent: t, measureScroll: n, checkIsScrollRoot: r, resetTransform: i }) {
  return class {
    constructor(s = {}, a = t == null ? void 0 : t()) {
      this.id = mp++, this.animationId = 0, this.children = /* @__PURE__ */ new Set(), this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.treeScale = { x: 1, y: 1 }, this.eventHandlers = /* @__PURE__ */ new Map(), this.hasTreeAnimated = !1, this.updateScheduled = !1, this.checkUpdateFailed = () => {
        this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots());
      }, this.updateProjection = () => {
        Ie.totalNodes = Ie.resolvedTargetDeltas = Ie.recalculatedProjection = 0, this.nodes.forEach(gp), this.nodes.forEach(Sp), this.nodes.forEach(xp), this.nodes.forEach(yp), hp(Ie);
      }, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = /* @__PURE__ */ new Map(), this.latestValues = s, this.root = a ? a.root || a : this, this.path = a ? [...a.path, a] : [], this.parent = a, this.depth = a ? a.depth + 1 : 0;
      for (let c = 0; c < this.path.length; c++)
        this.path[c].shouldResetTransform = !0;
      this.root === this && (this.nodes = new dp());
    }
    addEventListener(s, a) {
      return this.eventHandlers.has(s) || this.eventHandlers.set(s, new Zr()), this.eventHandlers.get(s).add(a);
    }
    notifyListeners(s, ...a) {
      const c = this.eventHandlers.get(s);
      c && c.notify(...a);
    }
    hasListeners(s) {
      return this.eventHandlers.has(s);
    }
    /**
     * Lifecycles
     */
    mount(s, a = this.root.hasTreeAnimated) {
      if (this.instance)
        return;
      this.isSVG = Va(s), this.instance = s;
      const { layoutId: c, layout: l, visualElement: u } = this.options;
      if (u && !u.current && u.mount(s), this.root.nodes.add(this), this.parent && this.parent.children.add(this), a && (l || c) && (this.isLayoutDirty = !0), e) {
        let d;
        const f = () => this.root.updateBlockedByResize = !1;
        e(s, () => {
          this.root.updateBlockedByResize = !0, d && d(), d = fp(f, 250), Jt.hasAnimatedSinceResize && (Jt.hasAnimatedSinceResize = !1, this.nodes.forEach(bo));
        });
      }
      c && this.root.registerSharedNode(c, this), this.options.animate !== !1 && u && (c || l) && this.addEventListener("didUpdate", ({ delta: d, hasLayoutChanged: f, hasRelativeTargetChanged: h, layout: p }) => {
        if (this.isTreeAnimationBlocked()) {
          this.target = void 0, this.relativeTarget = void 0;
          return;
        }
        const m = this.options.transition || u.getDefaultTransition() || Rp, { onLayoutAnimationStart: b, onLayoutAnimationComplete: w } = u.getProps(), y = !this.targetLayout || !$a(this.targetLayout, p) || h, g = !f && h;
        if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || g || f && (y || !this.currentAnimation)) {
          this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(d, g);
          const E = {
            ...ba(m, "layout"),
            onPlay: b,
            onComplete: w
          };
          (u.shouldReduceMotion || this.options.layoutRoot) && (E.delay = 0, E.type = !1), this.startAnimation(E);
        } else
          f || bo(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
        this.targetLayout = p;
      });
    }
    unmount() {
      this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
      const s = this.getStack();
      s && s.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, he(this.updateProjection);
    }
    // only on the root
    blockUpdate() {
      this.updateManuallyBlocked = !0;
    }
    unblockUpdate() {
      this.updateManuallyBlocked = !1;
    }
    isUpdateBlocked() {
      return this.updateManuallyBlocked || this.updateBlockedByResize;
    }
    isTreeAnimationBlocked() {
      return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1;
    }
    // Note: currently only running on root node
    startUpdate() {
      this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach(Cp), this.animationId++);
    }
    getTransformTemplate() {
      const { visualElement: s } = this.options;
      return s && s.getProps().transformTemplate;
    }
    willUpdate(s = !0) {
      if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
        this.options.onExitComplete && this.options.onExitComplete();
        return;
      }
      if (!this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty)
        return;
      this.isLayoutDirty = !0;
      for (let u = 0; u < this.path.length; u++) {
        const d = this.path[u];
        d.shouldResetTransform = !0, d.updateScroll("snapshot"), d.options.layoutRoot && d.willUpdate(!1);
      }
      const { layoutId: a, layout: c } = this.options;
      if (a === void 0 && !c)
        return;
      const l = this.getTransformTemplate();
      this.prevTransformTemplateValue = l ? l(this.latestValues, "") : void 0, this.updateSnapshot(), s && this.notifyListeners("willUpdate");
    }
    update() {
      if (this.updateScheduled = !1, this.isUpdateBlocked()) {
        this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(yo);
        return;
      }
      this.isUpdating || this.nodes.forEach(wp), this.isUpdating = !1, this.nodes.forEach(Ep), this.nodes.forEach(pp), this.nodes.forEach(vp), this.clearAllSnapshots();
      const a = performance.now();
      G.delta = Ve(0, 1e3 / 60, a - G.timestamp), G.timestamp = a, G.isProcessing = !0, On.update.process(G), On.preRender.process(G), On.render.process(G), G.isProcessing = !1;
    }
    didUpdate() {
      this.updateScheduled || (this.updateScheduled = !0, queueMicrotask(() => this.update()));
    }
    clearAllSnapshots() {
      this.nodes.forEach(bp), this.sharedNodes.forEach(Tp);
    }
    scheduleUpdateProjection() {
      V.preRender(this.updateProjection, !1, !0);
    }
    scheduleCheckAfterUnmount() {
      V.postRender(() => {
        this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed();
      });
    }
    /**
     * Update measurements
     */
    updateSnapshot() {
      this.snapshot || !this.instance || (this.snapshot = this.measure());
    }
    updateLayout() {
      if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty))
        return;
      if (this.resumeFrom && !this.resumeFrom.instance)
        for (let c = 0; c < this.path.length; c++)
          this.path[c].updateScroll();
      const s = this.layout;
      this.layout = this.measure(!1), this.layoutCorrected = j(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
      const { visualElement: a } = this.options;
      a && a.notify("LayoutMeasure", this.layout.layoutBox, s ? s.layoutBox : void 0);
    }
    updateScroll(s = "measure") {
      let a = !!(this.options.layoutScroll && this.instance);
      this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === s && (a = !1), a && (this.scroll = {
        animationId: this.root.animationId,
        phase: s,
        isRoot: r(this.instance),
        offset: n(this.instance)
      });
    }
    resetTransform() {
      if (!i)
        return;
      const s = this.isLayoutDirty || this.shouldResetTransform, a = this.projectionDelta && !ka(this.projectionDelta), c = this.getTransformTemplate(), l = c ? c(this.latestValues, "") : void 0, u = l !== this.prevTransformTemplateValue;
      s && (a || Fe(this.latestValues) || u) && (i(this.instance, l), this.shouldResetTransform = !1, this.scheduleRender());
    }
    measure(s = !0) {
      const a = this.measurePageBox();
      let c = this.removeElementScroll(a);
      return s && (c = this.removeTransform(c)), Ap(c), {
        animationId: this.root.animationId,
        measuredBox: a,
        layoutBox: c,
        latestValues: {},
        source: this.id
      };
    }
    measurePageBox() {
      const { visualElement: s } = this.options;
      if (!s)
        return j();
      const a = s.measureViewportBox(), { scroll: c } = this.root;
      return c && (Me(a.x, c.offset.x), Me(a.y, c.offset.y)), a;
    }
    removeElementScroll(s) {
      const a = j();
      ae(a, s);
      for (let c = 0; c < this.path.length; c++) {
        const l = this.path[c], { scroll: u, options: d } = l;
        if (l !== this.root && u && d.layoutScroll) {
          if (u.isRoot) {
            ae(a, s);
            const { scroll: f } = this.root;
            f && (Me(a.x, -f.offset.x), Me(a.y, -f.offset.y));
          }
          Me(a.x, u.offset.x), Me(a.y, u.offset.y);
        }
      }
      return a;
    }
    applyTransform(s, a = !1) {
      const c = j();
      ae(c, s);
      for (let l = 0; l < this.path.length; l++) {
        const u = this.path[l];
        !a && u.options.layoutScroll && u.scroll && u !== u.root && it(c, {
          x: -u.scroll.offset.x,
          y: -u.scroll.offset.y
        }), Fe(u.latestValues) && it(c, u.latestValues);
      }
      return Fe(this.latestValues) && it(c, this.latestValues), c;
    }
    removeTransform(s) {
      const a = j();
      ae(a, s);
      for (let c = 0; c < this.path.length; c++) {
        const l = this.path[c];
        if (!l.instance || !Fe(l.latestValues))
          continue;
        vr(l.latestValues) && l.updateSnapshot();
        const u = j(), d = l.measurePageBox();
        ae(u, d), fo(a, l.latestValues, l.snapshot ? l.snapshot.layoutBox : void 0, u);
      }
      return Fe(this.latestValues) && fo(a, this.latestValues), a;
    }
    setTargetDelta(s) {
      this.targetDelta = s, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0;
    }
    setOptions(s) {
      this.options = {
        ...this.options,
        ...s,
        crossfade: s.crossfade !== void 0 ? s.crossfade : !0
      };
    }
    clearMeasurements() {
      this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1;
    }
    forceRelativeParentToResolveTarget() {
      this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== G.timestamp && this.relativeParent.resolveTargetDelta(!0);
    }
    resolveTargetDelta(s = !1) {
      var a;
      const c = this.getLead();
      this.isProjectionDirty || (this.isProjectionDirty = c.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = c.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = c.isSharedProjectionDirty);
      const l = !!this.resumingFrom || this !== c;
      if (!(s || l && this.isSharedProjectionDirty || this.isProjectionDirty || !((a = this.parent) === null || a === void 0) && a.isProjectionDirty || this.attemptToResolveRelativeTarget))
        return;
      const { layout: d, layoutId: f } = this.options;
      if (!(!this.layout || !(d || f))) {
        if (this.resolvedRelativeTargetAt = G.timestamp, !this.targetDelta && !this.relativeTarget) {
          const h = this.getClosestProjectingParent();
          h && h.layout && this.animationProgress !== 1 ? (this.relativeParent = h, this.forceRelativeParentToResolveTarget(), this.relativeTarget = j(), this.relativeTargetOrigin = j(), St(this.relativeTargetOrigin, this.layout.layoutBox, h.layout.layoutBox), ae(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0;
        }
        if (!(!this.relativeTarget && !this.targetDelta)) {
          if (this.target || (this.target = j(), this.targetWithTransforms = j()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), $m(this.target, this.relativeTarget, this.relativeParent.target)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : ae(this.target, this.layout.layoutBox), _a(this.target, this.targetDelta)) : ae(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
            this.attemptToResolveRelativeTarget = !1;
            const h = this.getClosestProjectingParent();
            h && !!h.resumingFrom == !!this.resumingFrom && !h.options.layoutScroll && h.target && this.animationProgress !== 1 ? (this.relativeParent = h, this.forceRelativeParentToResolveTarget(), this.relativeTarget = j(), this.relativeTargetOrigin = j(), St(this.relativeTargetOrigin, this.target, h.target), ae(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0;
          }
          Ie.resolvedTargetDeltas++;
        }
      }
    }
    getClosestProjectingParent() {
      if (!(!this.parent || vr(this.parent.latestValues) || Pa(this.parent.latestValues)))
        return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent();
    }
    isProjecting() {
      return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout);
    }
    calcProjection() {
      var s;
      const a = this.getLead(), c = !!this.resumingFrom || this !== a;
      let l = !0;
      if ((this.isProjectionDirty || !((s = this.parent) === null || s === void 0) && s.isProjectionDirty) && (l = !1), c && (this.isSharedProjectionDirty || this.isTransformDirty) && (l = !1), this.resolvedRelativeTargetAt === G.timestamp && (l = !1), l)
        return;
      const { layout: u, layoutId: d } = this.options;
      if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(u || d))
        return;
      ae(this.layoutCorrected, this.layout.layoutBox);
      const f = this.treeScale.x, h = this.treeScale.y;
      zm(this.layoutCorrected, this.treeScale, this.path, c), a.layout && !a.target && (this.treeScale.x !== 1 || this.treeScale.y !== 1) && (a.target = a.layout.layoutBox);
      const { target: p } = a;
      if (!p) {
        this.projectionTransform && (this.projectionDelta = rt(), this.projectionTransform = "none", this.scheduleRender());
        return;
      }
      this.projectionDelta || (this.projectionDelta = rt(), this.projectionDeltaWithTransform = rt());
      const m = this.projectionTransform;
      Et(this.projectionDelta, this.layoutCorrected, p, this.latestValues), this.projectionTransform = po(this.projectionDelta, this.treeScale), (this.projectionTransform !== m || this.treeScale.x !== f || this.treeScale.y !== h) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", p)), Ie.recalculatedProjection++;
    }
    hide() {
      this.isVisible = !1;
    }
    show() {
      this.isVisible = !0;
    }
    scheduleRender(s = !0) {
      if (this.options.scheduleRender && this.options.scheduleRender(), s) {
        const a = this.getStack();
        a && a.scheduleRender();
      }
      this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0);
    }
    setAnimationOrigin(s, a = !1) {
      const c = this.snapshot, l = c ? c.latestValues : {}, u = { ...this.latestValues }, d = rt();
      (!this.relativeParent || !this.relativeParent.options.layoutRoot) && (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !a;
      const f = j(), h = c ? c.source : void 0, p = this.layout ? this.layout.source : void 0, m = h !== p, b = this.getStack(), w = !b || b.members.length <= 1, y = !!(m && !w && this.options.crossfade === !0 && !this.path.some(_p));
      this.animationProgress = 0;
      let g;
      this.mixTargetDelta = (E) => {
        const x = E / 1e3;
        wo(d.x, s.x, x), wo(d.y, s.y, x), this.setTargetDelta(d), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (St(f, this.layout.layoutBox, this.relativeParent.layout.layoutBox), Pp(this.relativeTarget, this.relativeTargetOrigin, f, x), g && cp(this.relativeTarget, g) && (this.isProjectionDirty = !1), g || (g = j()), ae(g, this.relativeTarget)), m && (this.animationValues = u, np(u, l, this.latestValues, x, y, w)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = x;
      }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0);
    }
    startAnimation(s) {
      this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && (he(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = V.update(() => {
        Jt.hasAnimatedSinceResize = !0, this.currentAnimation = Xr(0, go, {
          ...s,
          onUpdate: (a) => {
            this.mixTargetDelta(a), s.onUpdate && s.onUpdate(a);
          },
          onComplete: () => {
            s.onComplete && s.onComplete(), this.completeAnimation();
          }
        }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0;
      });
    }
    completeAnimation() {
      this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
      const s = this.getStack();
      s && s.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete");
    }
    finishAnimation() {
      this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(go), this.currentAnimation.stop()), this.completeAnimation();
    }
    applyTransformsToTarget() {
      const s = this.getLead();
      let { targetWithTransforms: a, target: c, layout: l, latestValues: u } = s;
      if (!(!a || !c || !l)) {
        if (this !== s && this.layout && l && Na(this.options.animationType, this.layout.layoutBox, l.layoutBox)) {
          c = this.target || j();
          const d = ie(this.layout.layoutBox.x);
          c.x.min = s.target.x.min, c.x.max = c.x.min + d;
          const f = ie(this.layout.layoutBox.y);
          c.y.min = s.target.y.min, c.y.max = c.y.min + f;
        }
        ae(a, c), it(a, u), Et(this.projectionDeltaWithTransform, this.layoutCorrected, a, u);
      }
    }
    registerSharedNode(s, a) {
      this.sharedNodes.has(s) || this.sharedNodes.set(s, new lp()), this.sharedNodes.get(s).add(a);
      const l = a.options.initialPromotionConfig;
      a.promote({
        transition: l ? l.transition : void 0,
        preserveFollowOpacity: l && l.shouldPreserveFollowOpacity ? l.shouldPreserveFollowOpacity(a) : void 0
      });
    }
    isLead() {
      const s = this.getStack();
      return s ? s.lead === this : !0;
    }
    getLead() {
      var s;
      const { layoutId: a } = this.options;
      return a ? ((s = this.getStack()) === null || s === void 0 ? void 0 : s.lead) || this : this;
    }
    getPrevLead() {
      var s;
      const { layoutId: a } = this.options;
      return a ? (s = this.getStack()) === null || s === void 0 ? void 0 : s.prevLead : void 0;
    }
    getStack() {
      const { layoutId: s } = this.options;
      if (s)
        return this.root.sharedNodes.get(s);
    }
    promote({ needsReset: s, transition: a, preserveFollowOpacity: c } = {}) {
      const l = this.getStack();
      l && l.promote(this, c), s && (this.projectionDelta = void 0, this.needsReset = !0), a && this.setOptions({ transition: a });
    }
    relegate() {
      const s = this.getStack();
      return s ? s.relegate(this) : !1;
    }
    resetRotation() {
      const { visualElement: s } = this.options;
      if (!s)
        return;
      let a = !1;
      const { latestValues: c } = s;
      if ((c.rotate || c.rotateX || c.rotateY || c.rotateZ) && (a = !0), !a)
        return;
      const l = {};
      for (let u = 0; u < vo.length; u++) {
        const d = "rotate" + vo[u];
        c[d] && (l[d] = c[d], s.setStaticValue(d, 0));
      }
      s.render();
      for (const u in l)
        s.setStaticValue(u, l[u]);
      s.scheduleRender();
    }
    getProjectionStyles(s = {}) {
      var a, c;
      const l = {};
      if (!this.instance || this.isSVG)
        return l;
      if (this.isVisible)
        l.visibility = "";
      else
        return { visibility: "hidden" };
      const u = this.getTransformTemplate();
      if (this.needsReset)
        return this.needsReset = !1, l.opacity = "", l.pointerEvents = Qt(s.pointerEvents) || "", l.transform = u ? u(this.latestValues, "") : "none", l;
      const d = this.getLead();
      if (!this.projectionDelta || !this.layout || !d.target) {
        const m = {};
        return this.options.layoutId && (m.opacity = this.latestValues.opacity !== void 0 ? this.latestValues.opacity : 1, m.pointerEvents = Qt(s.pointerEvents) || ""), this.hasProjected && !Fe(this.latestValues) && (m.transform = u ? u({}, "") : "none", this.hasProjected = !1), m;
      }
      const f = d.animationValues || d.latestValues;
      this.applyTransformsToTarget(), l.transform = po(this.projectionDeltaWithTransform, this.treeScale, f), u && (l.transform = u(f, l.transform));
      const { x: h, y: p } = this.projectionDelta;
      l.transformOrigin = `${h.origin * 100}% ${p.origin * 100}% 0`, d.animationValues ? l.opacity = d === this ? (c = (a = f.opacity) !== null && a !== void 0 ? a : this.latestValues.opacity) !== null && c !== void 0 ? c : 1 : this.preserveOpacity ? this.latestValues.opacity : f.opacityExit : l.opacity = d === this ? f.opacity !== void 0 ? f.opacity : "" : f.opacityExit !== void 0 ? f.opacityExit : 0;
      for (const m in nn) {
        if (f[m] === void 0)
          continue;
        const { correct: b, applyTo: w } = nn[m], y = l.transform === "none" ? f[m] : b(f[m], d);
        if (w) {
          const g = w.length;
          for (let E = 0; E < g; E++)
            l[w[E]] = y;
        } else
          l[m] = y;
      }
      return this.options.layoutId && (l.pointerEvents = d === this ? Qt(s.pointerEvents) || "" : "none"), l;
    }
    clearSnapshot() {
      this.resumeFrom = this.snapshot = void 0;
    }
    // Only run on root
    resetTree() {
      this.root.nodes.forEach((s) => {
        var a;
        return (a = s.currentAnimation) === null || a === void 0 ? void 0 : a.stop();
      }), this.root.nodes.forEach(yo), this.root.sharedNodes.clear();
    }
  };
}
function pp(e) {
  e.updateLayout();
}
function vp(e) {
  var t;
  const n = ((t = e.resumeFrom) === null || t === void 0 ? void 0 : t.snapshot) || e.snapshot;
  if (e.isLead() && e.layout && n && e.hasListeners("didUpdate")) {
    const { layoutBox: r, measuredBox: i } = e.layout, { animationType: o } = e.options, s = n.source !== e.layout.source;
    o === "size" ? ve((d) => {
      const f = s ? n.measuredBox[d] : n.layoutBox[d], h = ie(f);
      f.min = r[d].min, f.max = f.min + h;
    }) : Na(o, n.layoutBox, r) && ve((d) => {
      const f = s ? n.measuredBox[d] : n.layoutBox[d], h = ie(r[d]);
      f.max = f.min + h, e.relativeTarget && !e.currentAnimation && (e.isProjectionDirty = !0, e.relativeTarget[d].max = e.relativeTarget[d].min + h);
    });
    const a = rt();
    Et(a, r, n.layoutBox);
    const c = rt();
    s ? Et(c, e.applyTransform(i, !0), n.measuredBox) : Et(c, r, n.layoutBox);
    const l = !ka(a);
    let u = !1;
    if (!e.resumeFrom) {
      const d = e.getClosestProjectingParent();
      if (d && !d.resumeFrom) {
        const { snapshot: f, layout: h } = d;
        if (f && h) {
          const p = j();
          St(p, n.layoutBox, f.layoutBox);
          const m = j();
          St(m, r, h.layoutBox), $a(p, m) || (u = !0), d.options.layoutRoot && (e.relativeTarget = m, e.relativeTargetOrigin = p, e.relativeParent = d);
        }
      }
    }
    e.notifyListeners("didUpdate", {
      layout: r,
      snapshot: n,
      delta: c,
      layoutDelta: a,
      hasLayoutChanged: l,
      hasRelativeTargetChanged: u
    });
  } else if (e.isLead()) {
    const { onExitComplete: r } = e.options;
    r && r();
  }
  e.options.transition = void 0;
}
function gp(e) {
  Ie.totalNodes++, e.parent && (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty), e.isSharedProjectionDirty || (e.isSharedProjectionDirty = !!(e.isProjectionDirty || e.parent.isProjectionDirty || e.parent.isSharedProjectionDirty)), e.isTransformDirty || (e.isTransformDirty = e.parent.isTransformDirty));
}
function yp(e) {
  e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1;
}
function bp(e) {
  e.clearSnapshot();
}
function yo(e) {
  e.clearMeasurements();
}
function wp(e) {
  e.isLayoutDirty = !1;
}
function Ep(e) {
  const { visualElement: t } = e.options;
  t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"), e.resetTransform();
}
function bo(e) {
  e.finishAnimation(), e.targetDelta = e.relativeTarget = e.target = void 0, e.isProjectionDirty = !0;
}
function Sp(e) {
  e.resolveTargetDelta();
}
function xp(e) {
  e.calcProjection();
}
function Cp(e) {
  e.resetRotation();
}
function Tp(e) {
  e.removeLeadSnapshot();
}
function wo(e, t, n) {
  e.translate = F(t.translate, 0, n), e.scale = F(t.scale, 1, n), e.origin = t.origin, e.originPoint = t.originPoint;
}
function Eo(e, t, n, r) {
  e.min = F(t.min, n.min, r), e.max = F(t.max, n.max, r);
}
function Pp(e, t, n, r) {
  Eo(e.x, t.x, n.x, r), Eo(e.y, t.y, n.y, r);
}
function _p(e) {
  return e.animationValues && e.animationValues.opacityExit !== void 0;
}
const Rp = {
  duration: 0.45,
  ease: [0.4, 0, 0.1, 1]
}, So = (e) => typeof navigator < "u" && navigator.userAgent.toLowerCase().includes(e), xo = So("applewebkit/") && !So("chrome/") ? Math.round : I;
function Co(e) {
  e.min = xo(e.min), e.max = xo(e.max);
}
function Ap(e) {
  Co(e.x), Co(e.y);
}
function Na(e, t, n) {
  return e === "position" || e === "preserve-aspect" && !mr(mo(t), mo(n), 0.2);
}
const Dp = La({
  attachResizeListener: (e, t) => Se(e, "resize", t),
  measureScroll: () => ({
    x: document.documentElement.scrollLeft || document.body.scrollLeft,
    y: document.documentElement.scrollTop || document.body.scrollTop
  }),
  checkIsScrollRoot: () => !0
}), Kn = {
  current: void 0
}, Oa = La({
  measureScroll: (e) => ({
    x: e.scrollLeft,
    y: e.scrollTop
  }),
  defaultParent: () => {
    if (!Kn.current) {
      const e = new Dp({});
      e.mount(window), e.setOptions({ layoutScroll: !0 }), Kn.current = e;
    }
    return Kn.current;
  },
  resetTransform: (e, t) => {
    e.style.transform = t !== void 0 ? t : "none";
  },
  checkIsScrollRoot: (e) => window.getComputedStyle(e).position === "fixed"
}), Mp = {
  pan: {
    Feature: Ym
  },
  drag: {
    Feature: Zm,
    ProjectionNode: Oa,
    MeasureLayout: Aa
  }
}, kp = /var\((--[a-zA-Z0-9-_]+),? ?([a-zA-Z0-9 ()%#.,-]+)?\)/;
function $p(e) {
  const t = kp.exec(e);
  if (!t)
    return [,];
  const [, n, r] = t;
  return [n, r];
}
const Vp = 4;
function yr(e, t, n = 1) {
  re(n <= Vp, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`);
  const [r, i] = $p(e);
  if (!r)
    return;
  const o = window.getComputedStyle(t).getPropertyValue(r);
  if (o) {
    const s = o.trim();
    return wa(s) ? parseFloat(s) : s;
  } else
    return or(i) ? yr(i, t, n + 1) : i;
}
function Lp(e, { ...t }, n) {
  const r = e.current;
  if (!(r instanceof Element))
    return { target: t, transitionEnd: n };
  n && (n = { ...n }), e.values.forEach((i) => {
    const o = i.get();
    if (!or(o))
      return;
    const s = yr(o, r);
    s && i.set(s);
  });
  for (const i in t) {
    const o = t[i];
    if (!or(o))
      continue;
    const s = yr(o, r);
    s && (t[i] = s, n || (n = {}), n[i] === void 0 && (n[i] = o));
  }
  return { target: t, transitionEnd: n };
}
const Np = /* @__PURE__ */ new Set([
  "width",
  "height",
  "top",
  "left",
  "right",
  "bottom",
  "x",
  "y",
  "translateX",
  "translateY"
]), qa = (e) => Np.has(e), Op = (e) => Object.keys(e).some(qa), Kt = (e) => e === Ge || e === _, To = (e, t) => parseFloat(e.split(", ")[t]), Po = (e, t) => (n, { transform: r }) => {
  if (r === "none" || !r)
    return 0;
  const i = r.match(/^matrix3d\((.+)\)$/);
  if (i)
    return To(i[1], t);
  {
    const o = r.match(/^matrix\((.+)\)$/);
    return o ? To(o[1], e) : 0;
  }
}, qp = /* @__PURE__ */ new Set(["x", "y", "z"]), Bp = Mt.filter((e) => !qp.has(e));
function Fp(e) {
  const t = [];
  return Bp.forEach((n) => {
    const r = e.getValue(n);
    r !== void 0 && (t.push([n, r.get()]), r.set(n.startsWith("scale") ? 1 : 0));
  }), t.length && e.render(), t;
}
const ct = {
  // Dimensions
  width: ({ x: e }, { paddingLeft: t = "0", paddingRight: n = "0" }) => e.max - e.min - parseFloat(t) - parseFloat(n),
  height: ({ y: e }, { paddingTop: t = "0", paddingBottom: n = "0" }) => e.max - e.min - parseFloat(t) - parseFloat(n),
  top: (e, { top: t }) => parseFloat(t),
  left: (e, { left: t }) => parseFloat(t),
  bottom: ({ y: e }, { top: t }) => parseFloat(t) + (e.max - e.min),
  right: ({ x: e }, { left: t }) => parseFloat(t) + (e.max - e.min),
  // Transform
  x: Po(4, 13),
  y: Po(5, 14)
};
ct.translateX = ct.x;
ct.translateY = ct.y;
const Ip = (e, t, n) => {
  const r = t.measureViewportBox(), i = t.current, o = getComputedStyle(i), { display: s } = o, a = {};
  s === "none" && t.setStaticValue("display", e.display || "block"), n.forEach((l) => {
    a[l] = ct[l](r, o);
  }), t.render();
  const c = t.measureViewportBox();
  return n.forEach((l) => {
    const u = t.getValue(l);
    u && u.jump(a[l]), e[l] = ct[l](c, o);
  }), e;
}, zp = (e, t, n = {}, r = {}) => {
  t = { ...t }, r = { ...r };
  const i = Object.keys(t).filter(qa);
  let o = [], s = !1;
  const a = [];
  if (i.forEach((c) => {
    const l = e.getValue(c);
    if (!e.hasValue(c))
      return;
    let u = n[c], d = ht(u);
    const f = t[c];
    let h;
    if (on(f)) {
      const p = f.length, m = f[0] === null ? 1 : 0;
      u = f[m], d = ht(u);
      for (let b = m; b < p && f[b] !== null; b++)
        h ? re(ht(f[b]) === h, "All keyframes must be of the same type") : (h = ht(f[b]), re(h === d || Kt(d) && Kt(h), "Keyframes must be of the same dimension as the current value"));
    } else
      h = ht(f);
    if (d !== h)
      if (Kt(d) && Kt(h)) {
        const p = l.get();
        typeof p == "string" && l.set(parseFloat(p)), typeof f == "string" ? t[c] = parseFloat(f) : Array.isArray(f) && h === _ && (t[c] = f.map(parseFloat));
      } else
        d != null && d.transform && (h != null && h.transform) && (u === 0 || f === 0) ? u === 0 ? l.set(h.transform(u)) : t[c] = d.transform(f) : (s || (o = Fp(e), s = !0), a.push(c), r[c] = r[c] !== void 0 ? r[c] : t[c], l.jump(f));
  }), a.length) {
    const c = a.indexOf("height") >= 0 ? window.pageYOffset : null, l = Ip(t, e, a);
    return o.length && o.forEach(([u, d]) => {
      e.getValue(u).set(d);
    }), e.render(), vn && c !== null && window.scrollTo({ top: c }), { target: l, transitionEnd: r };
  } else
    return { target: t, transitionEnd: r };
};
function jp(e, t, n, r) {
  return Op(t) ? zp(e, t, n, r) : { target: t, transitionEnd: r };
}
const Hp = (e, t, n, r) => {
  const i = Lp(e, t, r);
  return t = i.target, r = i.transitionEnd, jp(e, t, n, r);
}, dn = { current: null }, Qr = { current: !1 };
function Ba() {
  if (Qr.current = !0, !!vn)
    if (window.matchMedia) {
      const e = window.matchMedia("(prefers-reduced-motion)"), t = () => dn.current = e.matches;
      e.addListener(t), t();
    } else
      dn.current = !1;
}
function Wp(e, t, n) {
  const { willChange: r } = t;
  for (const i in t) {
    const o = t[i], s = n[i];
    if (Z(o))
      e.addValue(i, o), ln(r) && r.add(i), process.env.NODE_ENV === "development" && Tn(o.version === "10.16.4", `Attempting to mix Framer Motion versions ${o.version} with 10.16.4 may not work as expected.`);
    else if (Z(s))
      e.addValue(i, We(o, { owner: e })), ln(r) && r.remove(i);
    else if (s !== o)
      if (e.hasValue(i)) {
        const a = e.getValue(i);
        !a.hasAnimated && a.set(o);
      } else {
        const a = e.getStaticValue(i);
        e.addValue(i, We(a !== void 0 ? a : o, { owner: e }));
      }
  }
  for (const i in n)
    t[i] === void 0 && e.removeValue(i);
  return t;
}
const _t = /* @__PURE__ */ new WeakMap(), Fa = Object.keys(Pt), Up = Fa.length, _o = [
  "AnimationStart",
  "AnimationComplete",
  "Update",
  "BeforeLayoutMeasure",
  "LayoutMeasure",
  "LayoutAnimationStart",
  "LayoutAnimationComplete"
], Gp = Mr.length;
class Kp {
  constructor({ parent: t, props: n, presenceContext: r, reducedMotionConfig: i, visualState: o }, s = {}) {
    this.current = null, this.children = /* @__PURE__ */ new Set(), this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = /* @__PURE__ */ new Map(), this.features = {}, this.valueSubscriptions = /* @__PURE__ */ new Map(), this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
      this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection));
    }, this.scheduleRender = () => V.render(this.render, !1, !0);
    const { latestValues: a, renderState: c } = o;
    this.latestValues = a, this.baseTarget = { ...a }, this.initialValues = n.initial ? { ...a } : {}, this.renderState = c, this.parent = t, this.props = n, this.presenceContext = r, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = i, this.options = s, this.isControllingVariants = bn(n), this.isVariantNode = xs(n), this.isVariantNode && (this.variantChildren = /* @__PURE__ */ new Set()), this.manuallyAnimateOnMount = !!(t && t.current);
    const { willChange: l, ...u } = this.scrapeMotionValuesFromProps(n, {});
    for (const d in u) {
      const f = u[d];
      a[d] !== void 0 && Z(f) && (f.set(a[d], !1), ln(l) && l.add(d));
    }
  }
  /**
   * This method takes React props and returns found MotionValues. For example, HTML
   * MotionValues will be found within the style prop, whereas for Three.js within attribute arrays.
   *
   * This isn't an abstract method as it needs calling in the constructor, but it is
   * intended to be one.
   */
  scrapeMotionValuesFromProps(t, n) {
    return {};
  }
  mount(t) {
    this.current = t, _t.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((n, r) => this.bindToMotionValue(r, n)), Qr.current || Ba(), this.shouldReduceMotion = this.reducedMotionConfig === "never" ? !1 : this.reducedMotionConfig === "always" ? !0 : dn.current, process.env.NODE_ENV !== "production" && Tn(this.shouldReduceMotion !== !0, "You have Reduced Motion enabled on your device. Animations may not appear as expected."), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext);
  }
  unmount() {
    _t.delete(this.current), this.projection && this.projection.unmount(), he(this.notifyUpdate), he(this.render), this.valueSubscriptions.forEach((t) => t()), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this);
    for (const t in this.events)
      this.events[t].clear();
    for (const t in this.features)
      this.features[t].unmount();
    this.current = null;
  }
  bindToMotionValue(t, n) {
    const r = Ue.has(t), i = n.on("change", (s) => {
      this.latestValues[t] = s, this.props.onUpdate && V.update(this.notifyUpdate, !1, !0), r && this.projection && (this.projection.isTransformDirty = !0);
    }), o = n.on("renderRequest", this.scheduleRender);
    this.valueSubscriptions.set(t, () => {
      i(), o();
    });
  }
  sortNodePosition(t) {
    return !this.current || !this.sortInstanceNodePosition || this.type !== t.type ? 0 : this.sortInstanceNodePosition(this.current, t.current);
  }
  loadFeatures({ children: t, ...n }, r, i, o) {
    let s, a;
    if (process.env.NODE_ENV !== "production" && i && r) {
      const c = "You have rendered a `motion` component within a `LazyMotion` component. This will break tree shaking. Import and render a `m` component instead.";
      n.ignoreStrict ? Vt(!1, c) : re(!1, c);
    }
    for (let c = 0; c < Up; c++) {
      const l = Fa[c], { isEnabled: u, Feature: d, ProjectionNode: f, MeasureLayout: h } = Pt[l];
      f && (s = f), u(n) && (!this.features[l] && d && (this.features[l] = new d(this)), h && (a = h));
    }
    if (!this.projection && s) {
      this.projection = new s(this.latestValues, this.parent && this.parent.projection);
      const { layoutId: c, layout: l, drag: u, dragConstraints: d, layoutScroll: f, layoutRoot: h } = n;
      this.projection.setOptions({
        layoutId: c,
        layout: l,
        alwaysMeasureLayout: !!u || d && tt(d),
        visualElement: this,
        scheduleRender: () => this.scheduleRender(),
        /**
         * TODO: Update options in an effect. This could be tricky as it'll be too late
         * to update by the time layout animations run.
         * We also need to fix this safeToRemove by linking it up to the one returned by usePresence,
         * ensuring it gets called if there's no potential layout animations.
         *
         */
        animationType: typeof l == "string" ? l : "both",
        initialPromotionConfig: o,
        layoutScroll: f,
        layoutRoot: h
      });
    }
    return a;
  }
  updateFeatures() {
    for (const t in this.features) {
      const n = this.features[t];
      n.isMounted ? n.update() : (n.mount(), n.isMounted = !0);
    }
  }
  triggerBuild() {
    this.build(this.renderState, this.latestValues, this.options, this.props);
  }
  /**
   * Measure the current viewport box with or without transforms.
   * Only measures axis-aligned boxes, rotate and skew must be manually
   * removed with a re-render to work.
   */
  measureViewportBox() {
    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : j();
  }
  getStaticValue(t) {
    return this.latestValues[t];
  }
  setStaticValue(t, n) {
    this.latestValues[t] = n;
  }
  /**
   * Make a target animatable by Popmotion. For instance, if we're
   * trying to animate width from 100px to 100vw we need to measure 100vw
   * in pixels to determine what we really need to animate to. This is also
   * pluggable to support Framer's custom value types like Color,
   * and CSS variables.
   */
  makeTargetAnimatable(t, n = !0) {
    return this.makeTargetAnimatableFromInstance(t, this.props, n);
  }
  /**
   * Update the provided props. Ensure any newly-added motion values are
   * added to our map, old ones removed, and listeners updated.
   */
  update(t, n) {
    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = n;
    for (let r = 0; r < _o.length; r++) {
      const i = _o[r];
      this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
      const o = t["on" + i];
      o && (this.propEventSubscriptions[i] = this.on(i, o));
    }
    this.prevMotionValues = Wp(this, this.scrapeMotionValuesFromProps(t, this.prevProps), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue();
  }
  getProps() {
    return this.props;
  }
  /**
   * Returns the variant definition with a given name.
   */
  getVariant(t) {
    return this.props.variants ? this.props.variants[t] : void 0;
  }
  /**
   * Returns the defined default transition on this component.
   */
  getDefaultTransition() {
    return this.props.transition;
  }
  getTransformPagePoint() {
    return this.props.transformPagePoint;
  }
  getClosestVariantNode() {
    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0;
  }
  getVariantContext(t = !1) {
    if (t)
      return this.parent ? this.parent.getVariantContext() : void 0;
    if (!this.isControllingVariants) {
      const r = this.parent ? this.parent.getVariantContext() || {} : {};
      return this.props.initial !== void 0 && (r.initial = this.props.initial), r;
    }
    const n = {};
    for (let r = 0; r < Gp; r++) {
      const i = Mr[r], o = this.props[i];
      (Tt(o) || o === !1) && (n[i] = o);
    }
    return n;
  }
  /**
   * Add a child visual element to our set of children.
   */
  addVariantChild(t) {
    const n = this.getClosestVariantNode();
    if (n)
      return n.variantChildren && n.variantChildren.add(t), () => n.variantChildren.delete(t);
  }
  /**
   * Add a motion value and bind it to this visual element.
   */
  addValue(t, n) {
    n !== this.values.get(t) && (this.removeValue(t), this.bindToMotionValue(t, n)), this.values.set(t, n), this.latestValues[t] = n.get();
  }
  /**
   * Remove a motion value and unbind any active subscriptions.
   */
  removeValue(t) {
    this.values.delete(t);
    const n = this.valueSubscriptions.get(t);
    n && (n(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState);
  }
  /**
   * Check whether we have a motion value for this key
   */
  hasValue(t) {
    return this.values.has(t);
  }
  getValue(t, n) {
    if (this.props.values && this.props.values[t])
      return this.props.values[t];
    let r = this.values.get(t);
    return r === void 0 && n !== void 0 && (r = We(n, { owner: this }), this.addValue(t, r)), r;
  }
  /**
   * If we're trying to animate to a previously unencountered value,
   * we need to check for it in our state and as a last resort read it
   * directly from the instance (which might have performance implications).
   */
  readValue(t) {
    var n;
    return this.latestValues[t] !== void 0 || !this.current ? this.latestValues[t] : (n = this.getBaseTargetFromProps(this.props, t)) !== null && n !== void 0 ? n : this.readValueFromInstance(this.current, t, this.options);
  }
  /**
   * Set the base target to later animate back to. This is currently
   * only hydrated on creation and when we first read a value.
   */
  setBaseTarget(t, n) {
    this.baseTarget[t] = n;
  }
  /**
   * Find the base target for a value thats been removed from all animation
   * props.
   */
  getBaseTarget(t) {
    var n;
    const { initial: r } = this.props, i = typeof r == "string" || typeof r == "object" ? (n = Fr(this.props, r)) === null || n === void 0 ? void 0 : n[t] : void 0;
    if (r && i !== void 0)
      return i;
    const o = this.getBaseTargetFromProps(this.props, t);
    return o !== void 0 && !Z(o) ? o : this.initialValues[t] !== void 0 && i === void 0 ? void 0 : this.baseTarget[t];
  }
  on(t, n) {
    return this.events[t] || (this.events[t] = new Zr()), this.events[t].add(n);
  }
  notify(t, ...n) {
    this.events[t] && this.events[t].notify(...n);
  }
}
class Ia extends Kp {
  sortInstanceNodePosition(t, n) {
    return t.compareDocumentPosition(n) & 2 ? 1 : -1;
  }
  getBaseTargetFromProps(t, n) {
    return t.style ? t.style[n] : void 0;
  }
  removeValueFromRenderState(t, { vars: n, style: r }) {
    delete n[t], delete r[t];
  }
  makeTargetAnimatableFromInstance({ transition: t, transitionEnd: n, ...r }, { transformValues: i }, o) {
    let s = pm(r, t || {}, this);
    if (i && (n && (n = i(n)), r && (r = i(r)), s && (s = i(s))), o) {
      hm(this, r, s);
      const a = Hp(this, r, s, n);
      n = a.transitionEnd, r = a.target;
    }
    return {
      transition: t,
      transitionEnd: n,
      ...r
    };
  }
}
function Zp(e) {
  return window.getComputedStyle(e);
}
class za extends Ia {
  readValueFromInstance(t, n) {
    if (Ue.has(n)) {
      const r = Ur(n);
      return r && r.default || 0;
    } else {
      const r = Zp(t), i = (_s(n) ? r.getPropertyValue(n) : r[n]) || 0;
      return typeof i == "string" ? i.trim() : i;
    }
  }
  measureInstanceViewportBox(t, { transformPagePoint: n }) {
    return Ra(t, n);
  }
  build(t, n, r, i) {
    Vr(t, n, r, i.transformTemplate);
  }
  scrapeMotionValuesFromProps(t, n) {
    return Br(t, n);
  }
  handleChildMotionValue() {
    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
    const { children: t } = this.props;
    Z(t) && (this.childSubscription = t.on("change", (n) => {
      this.current && (this.current.textContent = `${n}`);
    }));
  }
  renderInstance(t, n, r, i) {
    $s(t, n, r, i);
  }
}
class ja extends Ia {
  constructor() {
    super(...arguments), this.isSVGTag = !1;
  }
  getBaseTargetFromProps(t, n) {
    return t[n];
  }
  readValueFromInstance(t, n) {
    if (Ue.has(n)) {
      const r = Ur(n);
      return r && r.default || 0;
    }
    return n = Vs.has(n) ? n : qr(n), t.getAttribute(n);
  }
  measureInstanceViewportBox() {
    return j();
  }
  scrapeMotionValuesFromProps(t, n) {
    return Ns(t, n);
  }
  build(t, n, r, i) {
    Nr(t, n, r, this.isSVGTag, i.transformTemplate);
  }
  renderInstance(t, n, r, i) {
    Ls(t, n, r, i);
  }
  mount(t) {
    this.isSVGTag = Or(t.tagName), super.mount(t);
  }
}
const Yp = (e, t) => $r(e) ? new ja(t, { enableHardwareAcceleration: !1 }) : new za(t, { enableHardwareAcceleration: !0 }), Xp = {
  layout: {
    ProjectionNode: Oa,
    MeasureLayout: Aa
  }
}, Qp = {
  ...Am,
  ...th,
  ...Mp,
  ...Xp
}, $e = /* @__PURE__ */ uf((e, t) => zf(e, t, Qp, Yp));
function Ha() {
  const e = A(!1);
  return gn(() => (e.current = !0, () => {
    e.current = !1;
  }), []), e;
}
function Jp() {
  const e = Ha(), [t, n] = B(0), r = ue(() => {
    e.current && n(t + 1);
  }, [t]);
  return [ue(() => V.postRender(r), [r]), t];
}
class e0 extends P.Component {
  getSnapshotBeforeUpdate(t) {
    const n = this.props.childRef.current;
    if (n && t.isPresent && !this.props.isPresent) {
      const r = this.props.sizeRef.current;
      r.height = n.offsetHeight || 0, r.width = n.offsetWidth || 0, r.top = n.offsetTop, r.left = n.offsetLeft;
    }
    return null;
  }
  /**
   * Required with getSnapshotBeforeUpdate to stop React complaining.
   */
  componentDidUpdate() {
  }
  render() {
    return this.props.children;
  }
}
function t0({ children: e, isPresent: t }) {
  const n = Sr(), r = A(null), i = A({
    width: 0,
    height: 0,
    top: 0,
    left: 0
  });
  return Ko(() => {
    const { width: o, height: s, top: a, left: c } = i.current;
    if (t || !r.current || !o || !s)
      return;
    r.current.dataset.motionPopId = n;
    const l = document.createElement("style");
    return document.head.appendChild(l), l.sheet && l.sheet.insertRule(`
          [data-motion-pop-id="${n}"] {
            position: absolute !important;
            width: ${o}px !important;
            height: ${s}px !important;
            top: ${a}px !important;
            left: ${c}px !important;
          }
        `), () => {
      document.head.removeChild(l);
    };
  }, [t]), P.createElement(e0, { isPresent: t, childRef: r, sizeRef: i }, P.cloneElement(e, { ref: r }));
}
const Zn = ({ children: e, initial: t, isPresent: n, onExitComplete: r, custom: i, presenceAffectsLayout: o, mode: s }) => {
  const a = En(n0), c = Sr(), l = fe(
    () => ({
      id: c,
      initial: t,
      isPresent: n,
      custom: i,
      onExitComplete: (u) => {
        a.set(u, !0);
        for (const d of a.values())
          if (!d)
            return;
        r && r();
      },
      register: (u) => (a.set(u, !1), () => a.delete(u))
    }),
    /**
     * If the presence of a child affects the layout of the components around it,
     * we want to make a new context value to ensure they get re-rendered
     * so they can detect that layout change.
     */
    o ? void 0 : [n]
  );
  return fe(() => {
    a.forEach((u, d) => a.set(d, !1));
  }, [n]), P.useEffect(() => {
    !n && !a.size && r && r();
  }, [n]), s === "popLayout" && (e = P.createElement(t0, { isPresent: n }, e)), P.createElement(pn.Provider, { value: l }, e);
};
function n0() {
  return /* @__PURE__ */ new Map();
}
function r0(e) {
  return k(() => () => e(), []);
}
const et = (e) => e.key || "";
function i0(e, t) {
  e.forEach((n) => {
    const r = et(n);
    t.set(r, n);
  });
}
function o0(e) {
  const t = [];
  return ce.forEach(e, (n) => {
    je(n) && t.push(n);
  }), t;
}
const s0 = ({ children: e, custom: t, initial: n = !0, onExitComplete: r, exitBeforeEnter: i, presenceAffectsLayout: o = !0, mode: s = "sync" }) => {
  re(!i, "Replace exitBeforeEnter with mode='wait'");
  const a = H(kr).forceRender || Jp()[0], c = Ha(), l = o0(e);
  let u = l;
  const d = A(/* @__PURE__ */ new Map()).current, f = A(u), h = A(/* @__PURE__ */ new Map()).current, p = A(!0);
  if (gn(() => {
    p.current = !1, i0(l, h), f.current = u;
  }), r0(() => {
    p.current = !0, h.clear(), d.clear();
  }), p.current)
    return P.createElement(P.Fragment, null, u.map((y) => P.createElement(Zn, { key: et(y), isPresent: !0, initial: n ? void 0 : !1, presenceAffectsLayout: o, mode: s }, y)));
  u = [...u];
  const m = f.current.map(et), b = l.map(et), w = m.length;
  for (let y = 0; y < w; y++) {
    const g = m[y];
    b.indexOf(g) === -1 && !d.has(g) && d.set(g, void 0);
  }
  return s === "wait" && d.size && (u = []), d.forEach((y, g) => {
    if (b.indexOf(g) !== -1)
      return;
    const E = h.get(g);
    if (!E)
      return;
    const x = m.indexOf(g);
    let C = y;
    if (!C) {
      const T = () => {
        h.delete(g), d.delete(g);
        const S = f.current.findIndex((R) => R.key === g);
        if (f.current.splice(S, 1), !d.size) {
          if (f.current = l, c.current === !1)
            return;
          a(), r && r();
        }
      };
      C = P.createElement(Zn, { key: et(E), isPresent: !1, onExitComplete: T, custom: t, presenceAffectsLayout: o, mode: s }, E), d.set(g, C);
    }
    u.splice(x, 0, C);
  }), u = u.map((y) => {
    const g = y.key;
    return d.has(g) ? y : P.createElement(Zn, { key: et(y), isPresent: !0, presenceAffectsLayout: o, mode: s }, y);
  }), process.env.NODE_ENV !== "production" && s === "wait" && u.length > 1 && console.warn(`You're attempting to animate multiple children within AnimatePresence, but its mode is set to "wait". This will lead to odd visual behaviour.`), P.createElement(P.Fragment, null, d.size ? u : u.map((y) => Pe(y)));
};
function br(e) {
  const t = En(() => We(e)), { isStatic: n } = H(Ar);
  if (n) {
    const [, r] = B(e);
    k(() => t.on("change", r), []);
  }
  return t;
}
const a0 = (e) => typeof e == "object" && e.mix, c0 = (e) => a0(e) ? e.mix : void 0;
function l0(...e) {
  const t = !Array.isArray(e[0]), n = t ? 0 : -1, r = e[0 + n], i = e[1 + n], o = e[2 + n], s = e[3 + n], a = Hr(i, o, {
    mixer: c0(o[0]),
    ...s
  });
  return t ? a(r) : a;
}
function Wa(e, t) {
  const n = br(t()), r = () => n.set(t());
  return r(), gn(() => {
    const i = () => V.update(r, !1, !0), o = e.map((s) => s.on("change", i));
    return () => {
      o.forEach((s) => s()), he(r);
    };
  }), n;
}
function u0(e) {
  wt.current = [], e();
  const t = Wa(wt.current, e);
  return wt.current = void 0, t;
}
function fn(e, t, n, r) {
  if (typeof e == "function")
    return u0(e);
  const i = typeof t == "function" ? t : l0(t, n, r);
  return Array.isArray(e) ? Ro(e, i) : Ro([e], ([o]) => i(o));
}
function Ro(e, t) {
  const n = En(() => []);
  return Wa(e, () => {
    n.length = 0;
    const r = e.length;
    for (let i = 0; i < r; i++)
      n[i] = e[i].get();
    return t(n);
  });
}
function Ua(e, t, n) {
  var r;
  if (typeof e == "string") {
    let i = document;
    t && (re(!!t.current, "Scope provided, but no element detected."), i = t.current), n ? ((r = n[e]) !== null && r !== void 0 || (n[e] = i.querySelectorAll(e)), e = n[e]) : e = i.querySelectorAll(e);
  } else
    e instanceof Element && (e = [e]);
  return Array.from(e || []);
}
function d0() {
  !Qr.current && Ba();
  const [e] = B(dn.current);
  return process.env.NODE_ENV !== "production" && Tn(e !== !0, "You have Reduced Motion enabled on your device. Animations may not appear as expected."), e;
}
function f0(e, t) {
  let n;
  const r = () => {
    const { currentTime: i } = t, s = (i === null ? 0 : i.value) / 100;
    n !== s && e(s), n = s;
  };
  return V.update(r, !0), () => he(r);
}
const h0 = va(() => window.ScrollTimeline !== void 0);
class Ga {
  constructor(t) {
    this.animations = t.filter(Boolean);
  }
  then(t, n) {
    return Promise.all(this.animations).then(t).catch(n);
  }
  /**
   * TODO: Filter out cancelled or stopped animations before returning
   */
  getAll(t) {
    return this.animations[0][t];
  }
  setAll(t, n) {
    for (let r = 0; r < this.animations.length; r++)
      this.animations[r][t] = n;
  }
  attachTimeline(t) {
    const n = this.animations.map((r) => {
      if (h0() && r.attachTimeline)
        r.attachTimeline(t);
      else
        return r.pause(), f0((i) => {
          r.time = r.duration * i;
        }, t);
    });
    return () => {
      n.forEach((r, i) => {
        r && r(), this.animations[i].stop();
      });
    };
  }
  get time() {
    return this.getAll("time");
  }
  set time(t) {
    this.setAll("time", t);
  }
  get speed() {
    return this.getAll("speed");
  }
  set speed(t) {
    this.setAll("speed", t);
  }
  get duration() {
    let t = 0;
    for (let n = 0; n < this.animations.length; n++)
      t = Math.max(t, this.animations[n].duration);
    return t;
  }
  runAll(t) {
    this.animations.forEach((n) => n[t]());
  }
  play() {
    this.runAll("play");
  }
  pause() {
    this.runAll("pause");
  }
  stop() {
    this.runAll("stop");
  }
  cancel() {
    this.runAll("cancel");
  }
  complete() {
    this.runAll("complete");
  }
}
function m0(e) {
  return typeof e == "object" && !Array.isArray(e);
}
function p0(e) {
  const t = {
    presenceContext: null,
    props: {},
    visualState: {
      renderState: {
        transform: {},
        transformOrigin: {},
        style: {},
        vars: {},
        attrs: {}
      },
      latestValues: {}
    }
  }, n = Va(e) ? new ja(t, {
    enableHardwareAcceleration: !1
  }) : new za(t, {
    enableHardwareAcceleration: !0
  });
  n.mount(e), _t.set(e, n);
}
function v0(e, t = 100) {
  const n = Wr({ keyframes: [0, t], ...e }), r = Math.min(ur(n), lr);
  return {
    type: "keyframes",
    ease: (i) => n.next(r * i).value / t,
    duration: be(r)
  };
}
function Ao(e, t, n, r) {
  var i;
  return typeof t == "number" ? t : t.startsWith("-") || t.startsWith("+") ? Math.max(0, e + parseFloat(t)) : t === "<" ? n : (i = r.get(t)) !== null && i !== void 0 ? i : e;
}
const g0 = (e, t, n) => {
  const r = t - e;
  return ((n - e) % r + r) % r + e;
};
function y0(e, t) {
  return Ys(e) ? e[g0(0, e.length, t)] : e;
}
function b0(e, t, n) {
  for (let r = 0; r < e.length; r++) {
    const i = e[r];
    i.at > t && i.at < n && (Cn(e, i), r--);
  }
}
function w0(e, t, n, r, i, o) {
  b0(e, i, o);
  for (let s = 0; s < t.length; s++)
    e.push({
      value: t[s],
      at: F(i, o, r[s]),
      easing: y0(n, s)
    });
}
function E0(e, t) {
  return e.at === t.at ? e.value === null ? 1 : t.value === null ? -1 : 0 : e.at - t.at;
}
const S0 = "easeInOut";
function x0(e, { defaultTransition: t = {}, ...n } = {}, r) {
  const i = t.duration || 0.3, o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), a = {}, c = /* @__PURE__ */ new Map();
  let l = 0, u = 0, d = 0;
  for (let f = 0; f < e.length; f++) {
    const h = e[f];
    if (typeof h == "string") {
      c.set(h, u);
      continue;
    } else if (!Array.isArray(h)) {
      c.set(h.name, Ao(u, h.at, l, c));
      continue;
    }
    let [p, m, b = {}] = h;
    b.at !== void 0 && (u = Ao(u, b.at, l, c));
    let w = 0;
    const y = (g, E, x, C = 0, T = 0) => {
      const S = C0(g), { delay: R = 0, times: N = ha(S), type: W = "keyframes", ...Y } = E;
      let { ease: U = t.ease || "easeOut", duration: M } = E;
      const O = typeof R == "function" ? R(C, T) : R, X = S.length;
      if (X <= 2 && W === "spring") {
        let _e = 100;
        if (X === 2 && _0(S)) {
          const Ze = S[1] - S[0];
          _e = Math.abs(Ze);
        }
        const $ = { ...Y };
        M !== void 0 && ($.duration = Te(M));
        const me = v0($, _e);
        U = me.ease, M = me.duration;
      }
      M ?? (M = i);
      const z = u + O, Ke = z + M;
      N.length === 1 && N[0] === 0 && (N[1] = 1);
      const qe = N.length - S.length;
      qe > 0 && fa(N, qe), S.length === 1 && S.unshift(null), w0(x, S, U, N, z, Ke), w = Math.max(O + M, w), d = Math.max(Ke, d);
    };
    if (Z(p)) {
      const g = Do(p, s);
      y(m, b, Mo("default", g));
    } else {
      const g = Ua(p, r, a), E = g.length;
      for (let x = 0; x < E; x++) {
        m = m, b = b;
        const C = g[x], T = Do(C, s);
        for (const S in m)
          y(m[S], T0(b, S), Mo(S, T), x, E);
      }
      l = u, u += w;
    }
  }
  return s.forEach((f, h) => {
    for (const p in f) {
      const m = f[p];
      m.sort(E0);
      const b = [], w = [], y = [];
      for (let E = 0; E < m.length; E++) {
        const { at: x, value: C, easing: T } = m[E];
        b.push(C), w.push(at(0, d, x)), y.push(T || "easeOut");
      }
      w[0] !== 0 && (w.unshift(0), b.unshift(b[0]), y.unshift(S0)), w[w.length - 1] !== 1 && (w.push(1), b.push(null)), o.has(h) || o.set(h, {
        keyframes: {},
        transition: {}
      });
      const g = o.get(h);
      g.keyframes[p] = b, g.transition[p] = {
        ...t,
        duration: d,
        ease: y,
        times: w,
        ...n
      };
    }
  }), o;
}
function Do(e, t) {
  return !t.has(e) && t.set(e, {}), t.get(e);
}
function Mo(e, t) {
  return t[e] || (t[e] = []), t[e];
}
function C0(e) {
  return Array.isArray(e) ? e : [e];
}
function T0(e, t) {
  return e[t] ? { ...e, ...e[t] } : { ...e };
}
const P0 = (e) => typeof e == "number", _0 = (e) => e.every(P0);
function Ka(e, t, n, r) {
  const i = Ua(e, r), o = i.length;
  re(!!o, "No valid element provided.");
  const s = [];
  for (let a = 0; a < o; a++) {
    const c = i[a];
    _t.has(c) || p0(c);
    const l = _t.get(c), u = { ...n };
    typeof u.delay == "function" && (u.delay = u.delay(a, o)), s.push(...Yr(l, { ...t, transition: u }, {}));
  }
  return new Ga(s);
}
const R0 = (e) => Array.isArray(e) && Array.isArray(e[0]);
function A0(e, t, n) {
  const r = [];
  return x0(e, t, n).forEach(({ keyframes: o, transition: s }, a) => {
    let c;
    Z(a) ? c = Xr(a, o.default, s.default) : c = Ka(a, o, s), r.push(c);
  }), new Ga(r);
}
const D0 = (e) => {
  function t(n, r, i) {
    let o;
    return R0(n) ? o = A0(n, r, e) : m0(r) ? o = Ka(n, r, i, e) : o = Xr(n, r, i), e && e.animations.push(o), o;
  }
  return t;
}, ko = D0(), M0 = typeof window < "u" ? v.useLayoutEffect : () => {
};
function wr(...e) {
  return (...t) => {
    for (let n of e)
      typeof n == "function" && n(...t);
  };
}
let pt = /* @__PURE__ */ new Map(), $o = /* @__PURE__ */ new Set();
function Vo() {
  if (typeof window > "u")
    return;
  let e = (n) => {
    let r = pt.get(n.target);
    r || (r = /* @__PURE__ */ new Set(), pt.set(n.target, r), n.target.addEventListener("transitioncancel", t)), r.add(n.propertyName);
  }, t = (n) => {
    let r = pt.get(n.target);
    if (r && (r.delete(n.propertyName), r.size === 0 && (n.target.removeEventListener("transitioncancel", t), pt.delete(n.target)), pt.size === 0)) {
      for (let i of $o)
        i();
      $o.clear();
    }
  };
  document.body.addEventListener("transitionrun", e), document.body.addEventListener("transitionend", t);
}
typeof document < "u" && (document.readyState !== "loading" ? Vo() : document.addEventListener("DOMContentLoaded", Vo));
function Za(e) {
  for (Lo(e) && (e = e.parentElement); e && !Lo(e); )
    e = e.parentElement;
  return e || document.scrollingElement || document.documentElement;
}
function Lo(e) {
  let t = window.getComputedStyle(e);
  return /(auto|scroll)/.test(t.overflow + t.overflowX + t.overflowY);
}
function Jr(e) {
  var t;
  return typeof window < "u" && window.navigator != null ? e.test(((t = window.navigator.userAgentData) === null || t === void 0 ? void 0 : t.platform) || window.navigator.platform) : !1;
}
function k0() {
  return Jr(/^Mac/i);
}
function $0() {
  return Jr(/^iPhone/i);
}
function V0() {
  return Jr(/^iPad/i) || // iPadOS 13 lies and says it's a Mac, but we can distinguish by detecting touch support.
  k0() && navigator.maxTouchPoints > 1;
}
function L0() {
  return $0() || V0();
}
function le() {
  return le = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var n = arguments[t];
      for (var r in n)
        Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
    }
    return e;
  }, le.apply(this, arguments);
}
function ut(e, t) {
  if (e == null)
    return {};
  var n = {}, r = Object.keys(e), i, o;
  for (o = 0; o < r.length; o++)
    i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n;
}
var No = "calc(100% - env(safe-area-inset-top) - 34px)", Ya = typeof window > "u", N0 = {
  ease: "easeOut",
  duration: 0.2
}, O0 = {
  ease: "linear",
  duration: 0.01
}, q0 = 0.6, B0 = 500;
function Oo(e, t) {
  for (var n = e[0], r = Math.abs(e[0] - t), i = 1; i < e.length; i++) {
    var o = Math.abs(e[i] - t);
    o < r && (n = e[i], r = o);
  }
  return n;
}
function F0(e) {
  var t = document.querySelector("body"), n = document.querySelector("#" + e);
  if (n) {
    var r = 24, i = window.innerHeight, o = (i - r) / i;
    t.style.backgroundColor = "#000", n.style.overflow = "hidden", n.style.willChange = "transform", n.style.transition = "transform 200ms ease-in-out, border-radius 200ms linear", n.style.transform = "translateY(calc(env(safe-area-inset-top) + " + r / 2 + "px)) scale(" + o + ")", n.style.borderTopRightRadius = "10px", n.style.borderTopLeftRadius = "10px";
  }
}
function qo(e) {
  var t = document.querySelector("body"), n = document.getElementById(e);
  function r() {
    n.style.removeProperty("overflow"), n.style.removeProperty("will-change"), n.style.removeProperty("transition"), t.style.removeProperty("background-color"), n.removeEventListener("transitionend", r);
  }
  n && (n.style.removeProperty("border-top-right-radius"), n.style.removeProperty("border-top-left-radius"), n.style.removeProperty("transform"), n.addEventListener("transitionend", r));
}
function I0(e) {
  for (var t = 0; t < e.length; t++)
    if (e[t + 1] > e[t])
      return !1;
  return !0;
}
function Bo(e) {
  var t = e.snapTo, n = e.sheetHeight;
  return t < 0 && console.warn("Snap point is out of bounds. Sheet height is " + n + " but snap point is " + (n + Math.abs(t)) + "."), Math.max(Math.round(t), 0);
}
function ei(e) {
  return function(t) {
    e.forEach(function(n) {
      typeof n == "function" ? n(t) : n && (n.current = t);
    });
  };
}
function z0() {
  return typeof window > "u" ? !1 : "ontouchstart" in window || navigator.maxTouchPoints > 0;
}
var ti = Ya ? k : Er;
function j0(e, t) {
  var n = Xa(e);
  k(function() {
    t && !n && e ? F0(t) : t && !e && n && qo(t);
  }, [e, n]), k(function() {
    return function() {
      t && e && qo(t);
    };
  }, [e]);
}
function H0(e, t) {
  var n = Xa(e), r = A(!1), i = ue(function() {
    r.current ? (t.current.onCloseEnd == null || t.current.onCloseEnd(), r.current = !1) : (t.current.onOpenEnd == null || t.current.onOpenEnd(), r.current = !0);
  }, [e, n]);
  return k(function() {
    !n && e ? t.current.onOpenStart == null || t.current.onOpenStart() : !e && n && (t.current.onCloseStart == null || t.current.onCloseStart());
  }, [e, n]), {
    handleAnimationComplete: i
  };
}
function W0() {
  var e = B(0), t = e[0], n = e[1];
  return ti(function() {
    var r = function() {
      return n(window.innerHeight);
    };
    return window.addEventListener("resize", r), r(), function() {
      return window.removeEventListener("resize", r);
    };
  }, []), t;
}
function Xa(e) {
  var t = A();
  return k(function() {
    t.current = e;
  }), t.current;
}
function Fo(e) {
  var t = A();
  return ti(function() {
    t.current = e;
  }), ue(function() {
    for (var n = t.current, r = arguments.length, i = new Array(r), o = 0; o < r; o++)
      i[o] = arguments[o];
    return n == null ? void 0 : n.apply(void 0, i);
  }, []);
}
var U0 = {
  bottom: 0,
  top: 0,
  left: 0,
  right: 0
};
function Qa() {
  var e = A(null), t = ue(function() {
    return U0;
  }, []);
  return {
    constraintsRef: e,
    onMeasureDragConstraints: t
  };
}
var Ja = /* @__PURE__ */ de(void 0), Pn = function() {
  var t = H(Ja);
  if (!t)
    throw Error("Sheet context error");
  return t;
}, ec = /* @__PURE__ */ de(void 0);
function G0(e) {
  var t = e.children, n = Pn(), r = B(!!n.disableDrag), i = r[0], o = r[1];
  function s() {
    n.disableDrag || o(!1);
  }
  function a() {
    i || o(!0);
  }
  return D(ec.Provider, {
    value: {
      disableDrag: i,
      setDragEnabled: s,
      setDragDisabled: a
    }
  }, t);
}
var tc = function() {
  var t = H(ec);
  if (!t)
    throw Error("Sheet scroller context error");
  return t;
}, Yn = typeof window < "u" && window.visualViewport, K0 = /* @__PURE__ */ new Set(["checkbox", "radio", "range", "color", "file", "image", "button", "submit", "reset"]), Zt = 0, Xn;
function Z0(e) {
  e === void 0 && (e = {});
  var t = e, n = t.isDisabled;
  M0(function() {
    if (!n)
      return Zt++, Zt === 1 && (L0() ? Xn = X0() : Xn = Y0()), function() {
        Zt--, Zt === 0 && Xn();
      };
  }, [n]);
}
function Y0() {
  return wr(xt(document.documentElement, "paddingRight", window.innerWidth - document.documentElement.clientWidth + "px"), xt(document.documentElement, "overflow", "hidden"));
}
function X0() {
  var e, t = 0, n = function(f) {
    e = Za(f.target), !(e === document.documentElement && e === document.body) && (t = f.changedTouches[0].pageY);
  }, r = function(f) {
    if (e === document.documentElement || e === document.body) {
      f.preventDefault();
      return;
    }
    var h = f.changedTouches[0].pageY, p = e.scrollTop, m = e.scrollHeight - e.clientHeight;
    m !== 0 && ((p <= 0 && h > t || p >= m && h < t) && f.preventDefault(), t = h);
  }, i = function(f) {
    var h = f.target;
    zo(h) && h !== document.activeElement && (f.preventDefault(), h.style.transform = "translateY(-2000px)", h.focus(), requestAnimationFrame(function() {
      h.style.transform = "";
    }));
  }, o = function(f) {
    var h = f.target;
    zo(h) && (h.style.transform = "translateY(-2000px)", requestAnimationFrame(function() {
      h.style.transform = "", Yn && (Yn.height < window.innerHeight ? requestAnimationFrame(function() {
        Io(h);
      }) : Yn.addEventListener("resize", function() {
        return Io(h);
      }, {
        once: !0
      }));
    }));
  }, s = function() {
    window.scrollTo(0, 0);
  }, a = window.pageXOffset, c = window.pageYOffset, l = wr(xt(document.documentElement, "paddingRight", window.innerWidth - document.documentElement.clientWidth + "px"), xt(document.documentElement, "overflow", "hidden"), xt(document.body, "marginTop", "-" + c + "px"));
  window.scrollTo(0, 0);
  var u = wr(vt(document, "touchstart", n, {
    passive: !1,
    capture: !0
  }), vt(document, "touchmove", r, {
    passive: !1,
    capture: !0
  }), vt(document, "touchend", i, {
    passive: !1,
    capture: !0
  }), vt(document, "focus", o, !0), vt(window, "scroll", s));
  return function() {
    l(), u(), window.scrollTo(a, c);
  };
}
function xt(e, t, n) {
  var r = e.style[t];
  return e.style[t] = n, function() {
    e.style[t] = r;
  };
}
function vt(e, t, n, r) {
  return e.addEventListener(t, n, r), function() {
    e.removeEventListener(t, n, r);
  };
}
function Io(e) {
  for (var t = document.scrollingElement || document.documentElement; e && e !== t; ) {
    var n = Za(e);
    if (n !== document.documentElement && n !== document.body && n !== e) {
      var r = n.getBoundingClientRect().top, i = e.getBoundingClientRect().top;
      i > r + e.clientHeight && (n.scrollTop += i - r);
    }
    e = n.parentElement;
  }
}
function zo(e) {
  return e instanceof HTMLInputElement && !K0.has(e.type) || e instanceof HTMLTextAreaElement || e instanceof HTMLElement && e.isContentEditable;
}
var xe = {
  wrapper: {
    position: "fixed",
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    overflow: "hidden",
    pointerEvents: "none"
  },
  backdrop: {
    zIndex: 1,
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.2)",
    touchAction: "none",
    border: "none"
  },
  container: {
    zIndex: 2,
    position: "absolute",
    left: 0,
    bottom: 0,
    width: "100%",
    backgroundColor: "#fff",
    borderTopRightRadius: "8px",
    borderTopLeftRadius: "8px",
    boxShadow: "0px -2px 16px rgba(0, 0, 0, 0.3)",
    display: "flex",
    flexDirection: "column",
    pointerEvents: "auto"
  },
  headerWrapper: {
    width: "100%"
  },
  header: {
    height: "40px",
    width: "100%",
    position: "relative",
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  },
  indicator: {
    width: "18px",
    height: "4px",
    borderRadius: "99px",
    backgroundColor: "#ddd"
  },
  content: {
    flexGrow: 1,
    display: "flex",
    flexDirection: "column",
    minHeight: "0px",
    position: "relative"
  },
  scroller: {
    height: "100%",
    overflowY: "auto"
  }
}, Q0 = ["onOpenStart", "onOpenEnd", "onClose", "onCloseStart", "onCloseEnd", "onSnap", "children", "disableScrollLocking", "isOpen", "snapPoints", "rootId", "mountPoint", "style", "detent", "initialSnap", "disableDrag", "prefersReducedMotion", "tweenConfig"], J0 = /* @__PURE__ */ K(function(e, t) {
  var n = e.onOpenStart, r = e.onOpenEnd, i = e.onClose, o = e.onCloseStart, s = e.onCloseEnd, a = e.onSnap, c = e.children, l = e.disableScrollLocking, u = l === void 0 ? !1 : l, d = e.isOpen, f = e.snapPoints, h = e.rootId, p = e.mountPoint, m = e.style, b = e.detent, w = b === void 0 ? "full-height" : b, y = e.initialSnap, g = y === void 0 ? 0 : y, E = e.disableDrag, x = E === void 0 ? !1 : E, C = e.prefersReducedMotion, T = C === void 0 ? !1 : C, S = e.tweenConfig, R = S === void 0 ? N0 : S, N = ut(e, Q0), W = A(null), Y = br(0), U = W0(), M = d0(), O = !!(T || M), X = le({
    type: "tween"
  }, O ? O0 : R), z = br(0), Ke = fn(z, function(q) {
    return q >= U ? -1 : 9999999;
  }), qe = fn(z, function(q) {
    return q >= U ? "hidden" : "visible";
  }), _e = A({
    onOpenStart: n,
    onOpenEnd: r,
    onCloseStart: o,
    onCloseEnd: s
  });
  ti(function() {
    _e.current = {
      onOpenStart: n,
      onOpenEnd: r,
      onCloseStart: o,
      onCloseEnd: s
    };
  }), f && (f = f.map(function(q) {
    return q > 0 && q <= 1 ? Math.round(q * U) : q < 0 ? U + q : q;
  }), console.assert(I0(f) || U === 0, "Snap points need to be in descending order got: [" + f + "]"));
  var $ = Fo(function(q, oe) {
    var Re = oe.delta, se = z.getVelocity();
    se > 0 && Y.set(10), se < 0 && Y.set(-10), z.set(Math.max(z.get() + Re.y, 0));
  }), me = Fo(function(q, oe) {
    var Re = oe.velocity;
    if (Re.y > B0)
      i();
    else {
      var se = W.current, te = se.getBoundingClientRect().height, ne = z.get(), pe = 0;
      if (f) {
        var Ye = f.map(function(ac) {
          return te - Math.min(ac, te);
        });
        w === "content-height" && !Ye.includes(0) && Ye.unshift(0), pe = Oo(Ye, ne);
      } else
        ne / te > q0 && (pe = te);
      if (pe = Bo({
        snapTo: pe,
        sheetHeight: te
      }), ko(z, pe, X), f && a) {
        var rc = Math.abs(Math.round(f[0] - pe)), ic = f.indexOf(Oo(f, rc));
        a(ic);
      }
      var oc = Math.round(te), sc = pe >= oc;
      sc && i();
    }
    Y.set(0);
  });
  k(function() {
    if (!(!f || !a)) {
      var q = d ? g : f.length - 1;
      a(q);
    }
  }, [d]), lc(t, function() {
    return {
      y: z,
      snapTo: function(oe) {
        var Re = W.current;
        if (f && f[oe] !== void 0 && Re !== null) {
          var se = Re.getBoundingClientRect().height, te = f[oe], ne = Bo({
            snapTo: se - te,
            sheetHeight: se
          });
          ko(z, ne, X), a && a(oe), ne >= se && i();
        }
      }
    };
  }), j0(d, h), Z0({
    isDisabled: u === !0 || !d
  });
  var Ze = fe(function() {
    var q = {
      drag: "y",
      dragElastic: 0,
      dragMomentum: !1,
      dragPropagation: !1,
      onDrag: $,
      onDragEnd: me
    };
    return x ? void 0 : q;
  }, [x]), Nt = {
    y: z,
    sheetRef: W,
    isOpen: d,
    initialSnap: g,
    snapPoints: f,
    detent: w,
    indicatorRotation: Y,
    callbacks: _e,
    dragProps: Ze,
    windowHeight: U,
    animationOptions: X,
    reduceMotion: O,
    disableDrag: x
  }, dt = D(Ja.Provider, {
    value: Nt
  }, D($e.div, Object.assign({}, N, {
    ref: t,
    style: le({}, xe.wrapper, {
      zIndex: Ke,
      visibility: qe
    }, m)
  }), D(s0, null, d ? D(G0, null, ce.map(c, function(q, oe) {
    return Pe(q, {
      key: "sheet-child-" + oe
    });
  })) : null)));
  return Ya ? dt : uc(dt, p ?? document.body);
}), ev = ["children", "style", "className"], tv = /* @__PURE__ */ K(function(e, t) {
  var n = e.children, r = e.style, i = r === void 0 ? {} : r, o = e.className, s = o === void 0 ? "" : o, a = ut(e, ev), c = Pn(), l = c.y, u = c.isOpen, d = c.callbacks, f = c.snapPoints, h = c.initialSnap, p = h === void 0 ? 0 : h, m = c.sheetRef, b = c.windowHeight, w = c.detent, y = c.animationOptions, g = c.reduceMotion, E = H0(u, d), x = E.handleAnimationComplete, C = f ? f[0] - f[p] : 0, T = f ? f[0] : null, S = T !== null ? "min(" + T + "px, " + No + ")" : No;
  return D($e.div, Object.assign({}, a, {
    ref: ei([m, t]),
    className: "react-modal-sheet-container " + s,
    style: le({}, xe.container, i, w === "full-height" && {
      height: S
    }, w === "content-height" && {
      maxHeight: S
    }, {
      y: l
    }),
    initial: g ? !1 : {
      y: b
    },
    animate: {
      y: C,
      transition: y
    },
    exit: {
      y: b,
      transition: y
    },
    onAnimationComplete: x
  }), n);
}), nv = ["children", "style", "disableDrag", "className"], rv = /* @__PURE__ */ K(function(e, t) {
  var n = e.children, r = e.style, i = e.disableDrag, o = e.className, s = o === void 0 ? "" : o, a = ut(e, nv), c = Pn(), l = tc(), u = Qa(), d = u.constraintsRef, f = u.onMeasureDragConstraints, h = i || l.disableDrag ? void 0 : c.dragProps;
  return D($e.div, Object.assign({}, a, {
    ref: ei([t, d]),
    className: "react-modal-sheet-content " + s,
    style: le({}, xe.content, r)
  }, h, {
    dragConstraints: d,
    onMeasureDragConstraints: f
  }), n);
}), iv = ["children", "style", "disableDrag"], ov = /* @__PURE__ */ K(function(e, t) {
  var n = e.children, r = e.style, i = e.disableDrag, o = ut(e, iv), s = Pn(), a = s.indicatorRotation, c = s.dragProps, l = Qa(), u = l.constraintsRef, d = l.onMeasureDragConstraints, f = i ? void 0 : c, h = fn(a, function(m) {
    return "translateX(2px) rotate(" + m + "deg)";
  }), p = fn(a, function(m) {
    return "translateX(-2px) rotate(" + -1 * m + "deg)";
  });
  return D($e.div, Object.assign({}, o, {
    ref: ei([t, u]),
    style: le({}, xe.headerWrapper, r)
  }, f, {
    dragConstraints: u,
    onMeasureDragConstraints: d
  }), n || D("div", {
    className: "react-modal-sheet-header",
    style: xe.header
  }, D($e.span, {
    className: "react-modal-sheet-drag-indicator",
    style: le({}, xe.indicator, {
      transform: h
    })
  }), D($e.span, {
    className: "react-modal-sheet-drag-indicator",
    style: le({}, xe.indicator, {
      transform: p
    })
  })));
}), sv = ["style", "className"], jo = function(t) {
  return !!t.onClick || !!t.onTap;
}, av = /* @__PURE__ */ K(function(e, t) {
  var n = e.style, r = n === void 0 ? {} : n, i = e.className, o = i === void 0 ? "" : i, s = ut(e, sv), a = jo(s) ? $e.button : $e.div, c = jo(s) ? "auto" : "none";
  return D(a, Object.assign({}, s, {
    ref: t,
    className: "react-modal-sheet-backdrop " + o,
    style: le({}, xe.backdrop, r, {
      pointerEvents: c
    }),
    initial: {
      opacity: 0
    },
    animate: {
      opacity: 1
    },
    exit: {
      opacity: 0
    }
  }));
}), cv = ["draggableAt", "children", "style", "className"], lv = /* @__PURE__ */ K(function(e, t) {
  var n = e.draggableAt, r = n === void 0 ? "top" : n, i = e.children, o = e.style, s = e.className, a = s === void 0 ? "" : s, c = ut(e, cv), l = tc();
  function u(p) {
    var m = p.scrollTop, b = p.scrollHeight, w = p.clientHeight, y = b > w;
    if (y) {
      var g = m <= 0, E = b - m === w, x = r === "top" && g || r === "bottom" && E || r === "both" && (g || E);
      x ? l.setDragEnabled() : l.setDragDisabled();
    }
  }
  function d(p) {
    u(p.currentTarget);
  }
  function f(p) {
    u(p.currentTarget);
  }
  var h = z0() ? {
    onScroll: d,
    onTouchStart: f
  } : void 0;
  return D("div", Object.assign({}, c, {
    ref: t,
    className: "react-modal-sheet-scroller " + a,
    style: le({}, xe.scroller, o)
  }, h), i);
}), J = J0;
J.Container = tv;
J.Header = ov;
J.Content = rv;
J.Backdrop = av;
J.Scroller = lv;
const Ho = (e) => /* @__PURE__ */ v.createElement("svg", { viewBox: "0 0 48 48", focusable: "false", ...e }, /* @__PURE__ */ v.createElement(
  "path",
  {
    fill: "currentColor",
    d: "M19.876 4.5H43.5v9.34a5.172 5.172 0 01-5.17 5.178h-4.416l-5.166 4.138-1.425-4.134h-1.727v-2.446h3.468l.863 2.503 3.13-2.507h5.273a2.728 2.728 0 002.727-2.732V6.946H22.32v4.4h-2.443V4.5z"
  }
), /* @__PURE__ */ v.createElement(
  "path",
  {
    fill: "currentColor",
    fillRule: "evenodd",
    d: "M16.99 14.656c-3.725 0-6.746 2.992-6.746 6.682 0 3.69 3.02 6.682 6.746 6.682 3.725 0 6.745-2.993 6.745-6.682 0-3.69-3.02-6.682-6.745-6.682zm0 2.446c2.373 0 4.303 1.9 4.303 4.236s-1.93 4.236-4.303 4.236c-2.374 0-4.303-1.9-4.303-4.236s1.93-4.236 4.303-4.236zM9.28 29.471a4.786 4.786 0 00-4.78 4.787V43.5h24.98v-9.242a4.786 4.786 0 00-4.78-4.787H9.28zm-2.337 4.787c0-1.29 1.049-2.34 2.336-2.34H24.7a2.342 2.342 0 012.337 2.34v6.796H6.943v-6.796z",
    clipRule: "evenodd"
  }
));
var uv = { "no-advisor": "mzs9pj4", "one-advisor": "mzs9pj5", "two-advisors": "mzs9pj6" }, dv = "mzs9pj1", fv = "mzs9pj8", hv = "mzs9pj7", mv = { false: "mzs9pj2 mzs9pj0", true: "mzs9pj3 mzs9pj0" };
var pv = "afdy2r1", vv = "afdy2r0", gv = "afdy2r2";
var yv = { icon: "_1vjhm7c1 _1vjhm7c0", advisor: "_1vjhm7c2 _1vjhm7c0" }, bv = "_1vjhm7c4", wv = "_1vjhm7c3";
const Ev = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "m12 15.7-7.65-8-1.3 1.24L12 18.3l8.95-9.36-1.3-1.24-7.65 8Z",
      fill: "currentColor",
      fillRule: "evenodd"
    }
  )
);
var Sv = "whu6990", xv = "whu6991";
const nc = () => /* @__PURE__ */ React.createElement("div", { className: Sv }, /* @__PURE__ */ React.createElement("div", { className: xv })), Cv = ({
  buttonLabel: e,
  buttonAvatars: t,
  ...n
}) => {
  const r = mv.false, i = uv["no-advisor"];
  return we()[0] < Number(Ee.l.replace("px", "")) ? /* @__PURE__ */ v.createElement(Qn, { ...n, label: e }, /* @__PURE__ */ v.createElement(Ho, null)) : /* @__PURE__ */ v.createElement(
    "button",
    {
      ...n,
      className: L(r, i)
    },
    !t && /* @__PURE__ */ v.createElement(Ho, { className: hv }),
    t && /* @__PURE__ */ v.createElement("div", { className: fv }, t),
    e,
    /* @__PURE__ */ v.createElement("div", { className: dv }, /* @__PURE__ */ v.createElement(Ev, null))
  );
}, gg = ({
  type: e = "icon",
  icon: t,
  avatar: n,
  labels: r,
  ...i
}) => {
  const o = yv[e];
  return /* @__PURE__ */ v.createElement("a", { className: o, ...i }, /* @__PURE__ */ v.createElement("div", { className: bv }, t, n), /* @__PURE__ */ v.createElement("div", { className: wv }, r));
};
let Wo = 0;
const Tv = ({
  children: e,
  isActive: t,
  setIsActive: n,
  setIsClosing: r
}) => {
  const o = we()[0] < Number(Ee.l.replace("px", ""));
  return k(() => {
    const s = (a) => {
      if (a.key === "Escape")
        return n(!1);
    };
    window.addEventListener("keydown", s);
  }, []), o ? /* @__PURE__ */ v.createElement(
    J,
    {
      isOpen: t,
      onClose: () => n(!1),
      detent: "content-height"
    },
    /* @__PURE__ */ v.createElement(J.Container, null, /* @__PURE__ */ v.createElement(J.Header, null, /* @__PURE__ */ v.createElement(nc, null)), /* @__PURE__ */ v.createElement(J.Content, null, /* @__PURE__ */ v.createElement(ir, null, e))),
    /* @__PURE__ */ v.createElement(J.Backdrop, { onTap: () => n(!1) })
  ) : /* @__PURE__ */ v.createElement(
    At,
    {
      open: t,
      modal: !1,
      onOpenChange: (s) => {
        s || (r(!0), clearTimeout(Wo), Wo = window.setTimeout(() => {
          r(!1);
        }, 200)), n(s);
      }
    },
    /* @__PURE__ */ v.createElement(
      Dt,
      {
        className: L(pv, Rr.two),
        forceMount: !0
      },
      e
    )
  );
}, yg = ({
  buttonLabel: e,
  children: t,
  buttonAvatars: n
}) => {
  const [r, i] = B(!1), [o, s] = B(!1);
  return /* @__PURE__ */ v.createElement("div", { className: vv }, /* @__PURE__ */ v.createElement(
    Cv,
    {
      buttonLabel: e,
      buttonAvatars: n,
      onClick: () => {
        o || i(!r);
      }
    }
  ), /* @__PURE__ */ v.createElement(
    Tv,
    {
      isActive: r,
      setIsActive: i,
      setIsClosing: s
    },
    t
  ));
}, bg = () => /* @__PURE__ */ v.createElement("hr", { className: gv }), wg = (e) => /* @__PURE__ */ v.createElement("svg", { viewBox: "0 0 48 48", focusable: "false", ...e }, /* @__PURE__ */ v.createElement("g", null, /* @__PURE__ */ v.createElement(
  "path",
  {
    fill: "currentColor",
    d: "M35.9 37.84c.38.92-.08 1.96-1 2.34h-.08c-.92.4-1.98-.04-2.34-.96-.38-.92.08-1.96 1-2.34h.08c.92-.4 1.98.04 2.34.96zM6 30v10.1h21.84v-3.58H9.58v-6.54c0-1.22.98-2.2 2.18-2.2h16.08V24.2H11.76C8.58 24.2 6 26.78 6 29.98V30zm28.64-14.06c-2.5 0-4.7 1.24-6.04 3.14l2.94 2.04c.68-.98 1.82-1.62 3.1-1.62 2.08 0 3.78 1.7 3.78 3.8 0 2.1-1.52 3.62-3.46 3.78h-2.78v7.52h3.58v-4C39.3 30.06 42 27 42 23.32c0-4.06-3.3-7.38-7.36-7.38zm-23.42-2.06c0-4.28 3.46-7.76 7.76-7.76s7.76 3.48 7.76 7.76c0 4.28-3.46 7.76-7.76 7.76s-7.76-3.48-7.76-7.76zm3.58 0c0 2.32 1.88 4.18 4.18 4.18s4.18-1.86 4.18-4.18c0-2.32-1.88-4.18-4.18-4.18s-4.18 1.86-4.18 4.18z"
  }
))), Eg = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "M3 2.9h2.87l.68 2.22H21v4.11c0 2.15-1.75 3.9-3.9 3.9H9.01l.55 1.66h9.21v1.8H8.25L6.91 12.5 4.54 4.7H3V2.9Zm5.44 8.43L7.1 6.92h12.1v2.31a2.1 2.1 0 0 1-2.1 2.1H8.44Zm.08 8.27c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5Zm6.27 0c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5Z",
      fill: "currentColor",
      fillRule: "evenodd"
    }
  )
), Sg = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "M12 5.11c-1.93 0-3.49 1.57-3.49 3.51s1.56 3.51 3.49 3.51 3.49-1.57 3.49-3.51S13.93 5.11 12 5.11ZM6.72 8.62C6.72 5.68 9.08 3.3 12 3.3s5.28 2.38 5.28 5.32-2.36 5.32-5.28 5.32-5.28-2.38-5.28-5.32ZM4.21 20.7l-.78-.45q-.78-.44-.78-.45v-.02c0-.01.02-.03.03-.05.02-.04.06-.1.11-.16.09-.14.22-.32.4-.54.36-.44.9-1.02 1.64-1.6 1.51-1.16 3.84-2.29 7.15-2.29s5.65 1.13 7.15 2.29a9.65 9.65 0 0 1 1.64 1.6c.18.22.31.41.4.54.05.07.08.12.11.16.01.02.02.04.03.05v.02h.01l-.78.45q-.78.44-.78.45v-.02s-.05-.06-.08-.1c-.06-.09-.16-.24-.3-.41-.28-.35-.72-.82-1.34-1.3-1.23-.95-3.18-1.92-6.06-1.92s-4.84.97-6.06 1.92c-.62.48-1.06.95-1.34 1.3-.14.17-.24.32-.3.41-.03.05-.05.08-.07.1v.02H4.2Zm15.58 0Z",
      fill: "currentColor",
      fillRule: "evenodd"
    }
  )
), xg = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "M16.8 4.82c-1.34-1.26-3.13-1.87-4.78-1.87s-3.44.61-4.79 1.86C5.86 6.08 5 7.98 5.17 10.44c.17 2.48 1.77 5.03 3.19 6.87.73.94 1.44 1.73 1.97 2.29.27.28 1.5 1.46 1.5 1.46s1.27-1.16 1.55-1.45c.56-.56 1.31-1.36 2.07-2.3 1.49-1.83 3.17-4.39 3.37-6.86.19-2.45-.66-4.35-2.02-5.62Zm.23 5.48c-.15 1.88-1.5 4.06-2.97 5.87-.71.88-1.42 1.63-1.95 2.16l-.25.25c-.07-.07-.14-.15-.22-.23-.5-.53-1.17-1.28-1.85-2.15-1.39-1.8-2.68-3.98-2.82-5.89-.13-1.93.53-3.3 1.49-4.19.98-.91 2.32-1.37 3.56-1.37s2.57.47 3.55 1.38c.95.89 1.61 2.26 1.46 4.17Z",
      fill: "currentColor"
    }
  ),
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "M12 6.77c-1.54 0-2.81 1.23-2.81 2.78s1.27 2.78 2.81 2.78 2.81-1.24 2.81-2.78S13.54 6.77 12 6.77Zm0 3.76c-.57 0-1.01-.45-1.01-.98s.44-.98 1.01-.98 1.01.45 1.01.98-.44.98-1.01.98Z",
      fill: "currentColor"
    }
  )
);
var Pv = { small: "_1l5ogmzj _1l5ogmzi", medium: "_1l5ogmzk _1l5ogmzi", large: "_1l5ogmzl _1l5ogmzi" };
const Cg = ({ className: e = "", size: t = "small" }) => {
  const n = Pv[t];
  return /* @__PURE__ */ React.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "190",
      height: "72",
      fill: "none",
      viewBox: "0 0 190 72",
      className: L(n, e),
      focusable: "false"
    },
    /* @__PURE__ */ React.createElement("g", { clipPath: "url(#clip0_1707_1691)" }, /* @__PURE__ */ React.createElement(
      "path",
      {
        fill: "currentColor",
        d: "M46.264 56.437h-3.395C48.847 65.796 59.333 72 71.275 72a33.547 33.547 0 0025.943-12.213C103.392 67.238 112.736 72 123.176 72c11.942 0 22.427-6.204 28.406-15.578h-3.41c-5.618 7.737-14.721 12.754-24.996 12.754-10.891 0-20.46-5.633-25.958-14.136-5.498 8.503-15.067 14.136-25.943 14.136-10.29 0-19.393-5.017-24.996-12.739m76.807-11.807v-6.955h11.086v-4.131h-11.086v-6.129h12.453v-4.131h-17.936v25.492h18.507v-4.13h-13.024v-.016zm-22.068 4.131h5.453l7.151-25.492h-4.912l-4.597 17.68-4.011-17.68h-5.168l-4.356 17.756-4.07-17.756h-6.115L87.47 48.76h5.407l4.026-16.344 4.116 16.344zm-22.262 0l-6.58-9.704c1.728-.646 5.483-3.05 5.483-7.376 0-5.438-4.22-8.412-8.667-8.412H57.184V48.76h5.498V27.175h4.672c2.479 0 4.687 1.607 4.687 4.641 0 3.035-2.674 4.702-5.633 4.702-.57 0-1.052 0-1.472-.06l6.94 12.303h6.88zm-63.182 0l9.388-25.492h-5.167l-6.52 18.747v-.045L6.906 23.27H.627l9.539 25.492H15.574zM46.91 35.962c0 5.213-3.32 9.434-7.541 9.434-4.222 0-7.541-4.22-7.541-9.434 0-5.212 3.32-9.433 7.54-9.433 4.222 0 7.541 4.22 7.541 9.433zm-7.541-13.52c-7.376 0-13.355 6.055-13.355 13.52 0 7.466 5.979 13.52 13.354 13.52 7.376 0 13.355-6.054 13.355-13.52 0-7.465-5.979-13.52-13.355-13.52zm108.743-7h3.41C145.528 6.145 135.073-.014 123.191-.014c-10.44 0-19.784 4.762-25.958 12.213C91.043 4.762 81.715 0 71.26 0 59.378 0 48.922 6.174 42.944 15.473h3.41C51.972 7.81 61.045 2.824 71.275 2.824c10.89 0 20.46 5.633 25.958 14.136C102.73 8.457 112.3 2.824 123.19 2.824c10.23 0 19.303 4.972 24.921 12.634m14.541 33.318l-6.579-9.704c1.727-.646 5.483-3.05 5.483-7.376 0-5.438-4.221-8.412-8.668-8.412h-11.807v25.492h5.483V27.19h4.687c2.478 0 4.687 1.607 4.687 4.641 0 3.035-2.674 4.702-5.634 4.702-.571 0-1.051 0-1.472-.06l6.94 12.303h6.88zm3.726 0h5.483V23.27h-5.483v25.507zm22.863 0L178.577 34.64l9.478-11.341h-6.579l-8.893 11.642 9.358 13.85h7.316l-.015-.015z"
      }
    )),
    /* @__PURE__ */ React.createElement("defs", null, /* @__PURE__ */ React.createElement("clipPath", { id: "clip0_1707_1691" }, /* @__PURE__ */ React.createElement(
      "path",
      {
        fill: "#fff",
        d: "M0 0H188.615V72H0z",
        transform: "translate(.627)"
      }
    )))
  );
};
var _v = { lightGrey: "wl5gri9", blue: "wl5gria", green: "wl5grib", orange: "wl5gric", red: "wl5grid", white: "wl5grie", black: "wl5grif" }, Rv = { imageFill: "wl5gri7 wl5gri6", colorFill: "wl5gri8 wl5gri6" }, Av = { imageFill: "wl5gri1 wl5gri0", colorFill: "wl5gri2 wl5gri0" }, Dv = { imageFill: "wl5gri4 wl5gri3", colorFill: "wl5gri5 wl5gri3" };
const Tg = ({
  image: e,
  video: t,
  headline: n,
  cta: r,
  type: i = "imageFill",
  backgroundColor: o = "lightGrey"
}) => {
  const a = we()[0] >= Number(Ee.l.replace("px", "")), c = i === "colorFill" ? _v[o] : "";
  return /* @__PURE__ */ v.createElement("div", { className: L(Av[i], c) }, /* @__PURE__ */ v.createElement("div", { className: Dv[i] }, i === "imageFill" && t && /* @__PURE__ */ v.createElement("div", null, t), e), /* @__PURE__ */ v.createElement("div", { className: Rv[i] }, /* @__PURE__ */ v.createElement("div", null, n), /* @__PURE__ */ v.createElement("div", null, ce.map(r, (l) => je(l) ? Pe(l, {
    layout: a ? "horizontal" : "vertical",
    children: ce.map(l.props.children, (u) => je(u) ? Pe(u, {
      size: a ? "large" : "medium"
    }) : u)
  }) : l))));
};
var Mv = "bb4ht02", kv = "bb4ht0a", $v = "bb4ht00", Vv = { default: "bb4ht0c bb4ht0b", additional: "bb4ht0d bb4ht0b" }, Lv = { green: "bb4ht03", blue: "bb4ht04", purple: "bb4ht05", red: "bb4ht06", orange: "bb4ht07", yellow: "bb4ht08", anthracite: "bb4ht09" }, Nv = "bb4ht01";
const Pg = ({
  children: e,
  subline: t,
  spaceBelow: n,
  strongColor: r = "green"
}) => {
  const i = n ? Vv[n] : "", o = t ? kv : "", s = Lv[r];
  return /* @__PURE__ */ React.createElement("div", { className: L(i, $v, s) }, /* @__PURE__ */ React.createElement(
    "div",
    {
      className: L(Mv, o)
    },
    e
  ), t && /* @__PURE__ */ React.createElement("p", { className: Nv }, t));
};
var Ov = "zjytp2", qv = "zjytp1", Bv = "zjytp0";
const _g = ({
  logo: e,
  text: t,
  images: n
}) => /* @__PURE__ */ React.createElement("div", { className: L(Ne, Bv) }, /* @__PURE__ */ React.createElement("div", { className: qv }, e, /* @__PURE__ */ React.createElement("div", null, t)), /* @__PURE__ */ React.createElement("div", { className: Ov }, n));
var Fv = "_1llv8oz1", Iv = { spacingVertical: "_1llv8oz2 _1llv8oz0", spacingBottom: "_1llv8oz3 _1llv8oz0" };
const Rg = ({
  children: e,
  variant: t = "spacingVertical",
  borderBottom: n
}) => {
  const r = n ? Fv : "";
  return /* @__PURE__ */ React.createElement(
    "section",
    {
      className: L(
        Iv[t],
        r
      )
    },
    /* @__PURE__ */ React.createElement(ef, null, e)
  );
};
var zv = "qtlqkt0";
const Ag = ({ children: e }) => /* @__PURE__ */ v.createElement("div", { className: L(zv, Ne) }, e);
var jv = "_1u0x3zt0";
const Dg = ({ children: e }) => /* @__PURE__ */ React.createElement("div", { className: L(jv, Ne) }, e);
var Hv = "_19agmar2", Wv = "_19agmar1", Uv = "_19agmar0";
const Mg = ({
  headline: e,
  button: t
}) => /* @__PURE__ */ React.createElement("div", { className: L(Ne, Uv) }, /* @__PURE__ */ React.createElement("div", { className: Wv }, e), /* @__PURE__ */ React.createElement("div", { className: Hv }, t)), Gv = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement(
    "path",
    {
      d: "M3 12a9 9 0 1 1 18.001.001A9 9 0 0 1 3 12Zm2.06-1.92c-.17.61-.26 1.25-.26 1.92s.09 1.31.26 1.92h2.97c-.07-.63-.11-1.27-.11-1.92s.04-1.29.11-1.92H5.06Zm.77-1.8h2.49c.23-1.05.55-2.04.95-2.95a7.234 7.234 0 0 0-3.44 2.95Zm5.73-3.47c-.59.97-1.07 2.16-1.39 3.47h3.64c-.33-1.31-.81-2.5-1.4-3.47-.14 0-.28-.01-.42-.01-.15 0-.29 0-.44.01Zm3.15.51c.4.91.73 1.91.96 2.96h2.5a7.255 7.255 0 0 0-3.46-2.96Zm4.24 4.76h-2.98c.07.63.11 1.27.11 1.92s-.04 1.29-.11 1.92h2.98c.17-.61.26-1.25.26-1.92s-.09-1.31-.26-1.92Zm-.77 5.64h-2.5c-.23 1.05-.56 2.05-.96 2.96a7.202 7.202 0 0 0 3.46-2.96Zm-5.75 3.47c.59-.97 1.07-2.16 1.4-3.47h-3.65c.32 1.31.8 2.5 1.38 3.47.15 0 .3.01.44.01s.28 0 .42-.01Zm-3.15-.52c-.4-.91-.72-1.9-.94-2.95H5.85c.79 1.31 2 2.36 3.43 2.95Zm.58-4.75h4.31c.08-.63.12-1.27.12-1.92s-.04-1.29-.12-1.92H9.86c-.08.63-.12 1.27-.12 1.92s.04 1.29.12 1.92Z",
      fill: "currentColor",
      fillRule: "evenodd"
    }
  )
);
var Kv = "_16ls4wa1", Zv = "_16ls4wa0", Yv = "_16ls4wa4", Xv = "_16ls4wa9", Qv = "_16ls4wa3", Jv = "_16ls4wa8", eg = "_16ls4wa5", tg = "_16ls4wa2", ng = "_16ls4waa", rg = "_16ls4wa6", ig = "_16ls4wa7";
let Uo = 0;
const og = ({
  children: e,
  isActive: t,
  setIsActive: n,
  setIsClosing: r
}) => we()[0] < Number(Ee.m.replace("px", "")) ? /* @__PURE__ */ v.createElement(
  J,
  {
    isOpen: t,
    onClose: () => n(!1),
    detent: "content-height"
  },
  /* @__PURE__ */ v.createElement(J.Container, null, /* @__PURE__ */ v.createElement(J.Header, null, /* @__PURE__ */ v.createElement(nc, null)), /* @__PURE__ */ v.createElement(J.Content, null, /* @__PURE__ */ v.createElement(ir, null, /* @__PURE__ */ v.createElement("div", { className: Xv }, e)))),
  /* @__PURE__ */ v.createElement(J.Backdrop, { onTap: () => n(!1) })
) : /* @__PURE__ */ v.createElement(
  At,
  {
    open: t,
    modal: !0,
    onOpenChange: (s) => {
      s || (r(!0), clearTimeout(Uo), Uo = window.setTimeout(() => {
        r(!1);
      }, 200)), n(s);
    }
  },
  /* @__PURE__ */ v.createElement(Pr, { className: Qv }),
  /* @__PURE__ */ v.createElement(Dt, { className: Kv }, /* @__PURE__ */ v.createElement(ir, null, /* @__PURE__ */ v.createElement("div", { className: tg }, /* @__PURE__ */ v.createElement(
    Es,
    {
      onClick: () => n(!1),
      icon: /* @__PURE__ */ v.createElement(en, null)
    }
  ), e)))
), kg = ({
  title: e,
  buttonLabel: t,
  modalTitle: n,
  suggestedLanguages: r,
  suggestedLabel: i,
  languages: o
}) => {
  const [s, a] = B(!1), [c, l] = B(!1);
  return k(() => {
    const u = (d) => {
      if (d.key === "Escape")
        return a(!1);
    };
    window.addEventListener("keydown", u);
  }, []), /* @__PURE__ */ v.createElement("div", { className: Zv }, e, /* @__PURE__ */ v.createElement(
    "button",
    {
      onClick: () => {
        c || a(!s);
      },
      className: ng
    },
    /* @__PURE__ */ v.createElement(Gv, null),
    /* @__PURE__ */ v.createElement(st, { variant: "paragraph16", fontWeight: "medium" }, t)
  ), /* @__PURE__ */ v.createElement(
    og,
    {
      isActive: s,
      setIsActive: a,
      setIsClosing: l
    },
    /* @__PURE__ */ v.createElement(
      st,
      {
        component: "h3",
        fontWeight: "bold",
        className: Jv
      },
      n
    ),
    /* @__PURE__ */ v.createElement("div", { className: Yv }, /* @__PURE__ */ v.createElement(
      st,
      {
        variant: "paragraph12",
        fontWeight: "regular",
        className: ig
      },
      i
    ), (r == null ? void 0 : r.length) > 0 && /* @__PURE__ */ v.createElement("div", { className: rg }, r.map((u, d) => /* @__PURE__ */ v.createElement("div", { key: d }, u))), /* @__PURE__ */ v.createElement("div", { className: eg }, o == null ? void 0 : o.map((u, d) => /* @__PURE__ */ v.createElement("div", { key: d }, u))))
  ));
}, $g = (e) => /* @__PURE__ */ React.createElement(
  "svg",
  {
    focusable: "false",
    ...e,
    width: "24",
    height: "16",
    viewBox: "0 0 24 16",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  },
  /* @__PURE__ */ React.createElement("g", { clipPath: "url(#clip0_1858_5368)" }, /* @__PURE__ */ React.createElement("path", { d: "M0 10.6667H24V16H0V10.6667Z", fill: "#FFCE00" }), /* @__PURE__ */ React.createElement("path", { d: "M0 0H24V5.33333H0V0Z", fill: "black" }), /* @__PURE__ */ React.createElement("path", { d: "M0 5.33334H24V10.6667H0V5.33334Z", fill: "#DD0000" })),
  /* @__PURE__ */ React.createElement(
    "rect",
    {
      x: "0.5",
      y: "0.5",
      width: "23",
      height: "15",
      stroke: "black",
      strokeOpacity: "0.2"
    }
  ),
  /* @__PURE__ */ React.createElement("defs", null, /* @__PURE__ */ React.createElement("clipPath", { id: "clip0_1858_5368" }, /* @__PURE__ */ React.createElement("rect", { width: "24", height: "16", fill: "white" })))
), Vg = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 32 32",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement("g", { clipPath: "url(#clip0_2050_3075)" }, /* @__PURE__ */ v.createElement(
    "mask",
    {
      id: "mask0_2050_3075",
      style: { maskType: "luminance" },
      width: "32",
      height: "32",
      x: "0",
      y: "0",
      maskUnits: "userSpaceOnUse"
    },
    /* @__PURE__ */ v.createElement(
      "path",
      {
        fill: "#fff",
        d: "M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z"
      }
    )
  ), /* @__PURE__ */ v.createElement("g", { mask: "url(#mask0_2050_3075)" }, /* @__PURE__ */ v.createElement(
    "path",
    {
      fill: "currentColor",
      d: "M16.005 0c-6.68 0-8.633.007-9.013.038-1.37.114-2.224.33-3.153.793A6.386 6.386 0 002 2.177C.985 3.231.37 4.528.147 6.07c-.108.748-.14.9-.146 4.723-.002 1.275 0 2.951 0 5.2 0 6.677.007 8.63.04 9.008.11 1.335.32 2.174.762 3.092a6.741 6.741 0 004.369 3.57c.66.17 1.388.263 2.323.308.396.017 4.435.029 8.476.029 4.04 0 8.082-.005 8.468-.025 1.083-.05 1.712-.135 2.407-.315a6.699 6.699 0 004.368-3.577c.435-.896.655-1.767.755-3.032.021-.276.03-4.671.03-9.062 0-4.39-.01-8.778-.031-9.054-.1-1.285-.321-2.15-.77-3.062a6.343 6.343 0 00-1.37-1.877C28.77.985 27.477.369 25.934.146c-.747-.108-.896-.14-4.72-.146h-5.209.001z"
    }
  ), /* @__PURE__ */ v.createElement(
    "path",
    {
      style: {
        fill: `${_r.color.icon.inverted}`
      },
      d: "M16.001 5.76c-2.781 0-3.13.012-4.222.062-1.09.05-1.835.222-2.486.476a5.015 5.015 0 00-1.814 1.18c-.57.57-.92 1.141-1.182 1.814-.253.651-.426 1.396-.475 2.486-.05 1.092-.062 1.441-.062 4.222 0 2.78.012 3.129.062 4.221.05 1.09.222 1.834.475 2.486a5.016 5.016 0 001.181 1.814c.57.57 1.14.92 1.814 1.181.651.254 1.396.426 2.486.476 1.092.05 1.44.062 4.221.062s3.13-.012 4.222-.062c1.09-.05 1.835-.222 2.487-.476a5.01 5.01 0 001.812-1.181c.57-.57.92-1.14 1.182-1.814.252-.651.425-1.396.476-2.486.049-1.092.062-1.44.062-4.22 0-2.782-.013-3.13-.062-4.223-.051-1.09-.224-1.835-.476-2.486a5.026 5.026 0 00-1.182-1.814c-.57-.57-1.139-.92-1.813-1.18-.653-.254-1.398-.427-2.487-.476-1.093-.05-1.44-.062-4.222-.062H16zm-.919 1.846h.919c2.734 0 3.058.01 4.138.058.998.046 1.54.213 1.901.353.478.186.819.407 1.177.766.358.358.58.7.766 1.177.14.361.307.903.353 1.901.049 1.08.06 1.404.06 4.137 0 2.733-.011 3.057-.06 4.136-.046.999-.213 1.54-.353 1.901a3.167 3.167 0 01-.766 1.177c-.359.358-.699.58-1.177.765-.36.141-.903.308-1.901.353-1.08.05-1.404.06-4.138.06s-3.058-.01-4.138-.06c-.998-.046-1.54-.212-1.901-.353a3.172 3.172 0 01-1.178-.765 3.177 3.177 0 01-.766-1.177c-.14-.361-.308-.903-.353-1.901-.049-1.08-.059-1.404-.059-4.138 0-2.735.01-3.057.06-4.137.045-.998.212-1.54.352-1.901.185-.478.408-.82.766-1.178.358-.358.7-.58 1.178-.766.36-.141.903-.307 1.901-.353.945-.043 1.31-.055 3.22-.058v.003zm6.385 1.7a1.229 1.229 0 100 2.458 1.229 1.229 0 000-2.459zm-5.466 1.436a5.259 5.259 0 100 10.517 5.259 5.259 0 000-10.517zm0 1.845a3.413 3.413 0 110 6.827 3.413 3.413 0 010-6.827z"
    }
  ))),
  /* @__PURE__ */ v.createElement("defs", null, /* @__PURE__ */ v.createElement("clipPath", { id: "clip0_2050_3075" }, /* @__PURE__ */ v.createElement("path", { fill: "#fff", d: "M0 0H32V32H0z" })))
), Lg = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 32 32",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement("g", { clipPath: "url(#a)" }, /* @__PURE__ */ v.createElement(
    "path",
    {
      fill: "currentColor",
      d: "M16 0C7.164 0 0 7.164 0 16c0 6.778 4.217 12.573 10.169 14.904-.14-1.265-.266-3.213.055-4.594.291-1.249 1.877-7.953 1.877-7.953s-.478-.959-.478-2.375c0-2.225 1.289-3.886 2.894-3.886 1.366 0 2.024 1.024 2.024 2.253 0 1.372-.874 3.425-1.325 5.326-.376 1.592.799 2.892 2.37 2.892 2.844 0 5.029-2.998 5.029-7.327 0-3.83-2.753-6.51-6.683-6.51-4.553 0-7.225 3.415-7.225 6.945 0 1.374.53 2.85 1.19 3.651.131.158.15.298.111.459-.12.505-.39 1.592-.444 1.814-.07.293-.231.356-.534.215-2-.93-3.248-3.852-3.248-6.198 0-5.048 3.668-9.682 10.572-9.682 5.55 0 9.864 3.954 9.864 9.24s-3.477 9.952-8.303 9.952c-1.621 0-3.146-.843-3.668-1.837 0 0-.802 3.055-.997 3.803-.36 1.39-1.336 3.132-1.988 4.194 1.497.464 3.088.714 4.737.714 8.836 0 16-7.164 16-16S24.836 0 16 0Z"
    }
  )),
  /* @__PURE__ */ v.createElement("defs", null, /* @__PURE__ */ v.createElement("clipPath", { id: "a" }, /* @__PURE__ */ v.createElement("path", { fill: "#fff", d: "M0 0h32v32H0z" })))
), Ng = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 32 32",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement("g", { clipPath: "url(#a)" }, /* @__PURE__ */ v.createElement(
    "path",
    {
      fill: "currentColor",
      d: "M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16Z"
    }
  ), /* @__PURE__ */ v.createElement(
    "path",
    {
      style: {
        fill: `${_r.color.icon.inverted}`
      },
      d: "M26.222 10.866a2.672 2.672 0 0 0-1.887-1.887C22.67 8.533 16 8.533 16 8.533s-6.67 0-8.335.446a2.676 2.676 0 0 0-1.886 1.887C5.334 12.53 5.334 16 5.334 16s0 3.47.446 5.134c.244.917.967 1.64 1.886 1.887 1.664.445 8.335.445 8.335.445s6.67 0 8.334-.445a2.676 2.676 0 0 0 1.887-1.887c.445-1.664.445-5.134.445-5.134s0-3.47-.445-5.134ZM13.867 19.2v-6.4L19.41 16l-5.542 3.2Z"
    }
  )),
  /* @__PURE__ */ v.createElement("defs", null, /* @__PURE__ */ v.createElement("clipPath", { id: "a" }, /* @__PURE__ */ v.createElement("path", { fill: "#fff", d: "M0 0h32v32H0z" })))
), Og = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 32 32",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement("g", { clipPath: "url(#a)" }, /* @__PURE__ */ v.createElement(
    "path",
    {
      fill: "currentColor",
      d: "M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16Z"
    }
  ), /* @__PURE__ */ v.createElement(
    "path",
    {
      style: {
        fill: `${_r.color.icon.inverted}`
      },
      fillRule: "evenodd",
      d: "M14.197 11.25c0 .099-.08.18-.18.183-2.325.09-4.202 1.902-4.36 4.18a.186.186 0 0 1-.186.173.187.187 0 0 1-.187-.195c.147-2.488 2.187-4.473 4.719-4.57a.186.186 0 0 1 .194.185v.043ZM14.104 9c3.924 0 7.104 3.028 7.104 6.763s-3.18 6.763-7.104 6.763a7.415 7.415 0 0 1-2.363-.384L8.204 24.36l.867-3.805.034.012-.024-.022C7.795 19.32 7 17.63 7 15.763 7 12.028 10.18 9 14.104 9Zm9.984 0c.955 0 1.728 1.17 1.728 2.614 0 1.086-.439 2.018-1.063 2.412v7.714c0 .387-.298.7-.665.7-.367 0-.664-.313-.664-.7v-7.713c-.625-.394-1.064-1.326-1.064-2.413 0-1.444.774-2.614 1.728-2.614Z",
      clipRule: "evenodd"
    }
  )),
  /* @__PURE__ */ v.createElement("defs", null, /* @__PURE__ */ v.createElement("clipPath", { id: "a" }, /* @__PURE__ */ v.createElement("path", { fill: "#fff", d: "M0 0h32v32H0z" })))
);
var sg = "_5yj2ss0";
var ag = "_12sdaeq0", cg = "_12sdaeq1";
const qg = ({ children: e }) => /* @__PURE__ */ React.createElement("div", { className: L(ag, Ne) }, e), Bg = ({
  header: e,
  links: t
}) => (
  // <DarkTheme>
  /* @__PURE__ */ React.createElement("div", { className: L(cg, sg) }, e, t && /* @__PURE__ */ React.createElement("ul", null, t.map((n, r) => /* @__PURE__ */ React.createElement("li", { key: r }, n))))
), Fg = (e) => /* @__PURE__ */ v.createElement(
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 32 32",
    focusable: "false",
    ...e
  },
  /* @__PURE__ */ v.createElement("g", { clipPath: "url(#a)" }, /* @__PURE__ */ v.createElement(
    "path",
    {
      fill: "currentColor",
      d: "M32 16c0-8.837-7.163-16-16-16S0 7.163 0 16c0 7.986 5.85 14.606 13.5 15.806V20.625H9.435V16H13.5v-3.525c0-4.01 2.39-6.224 6.045-6.224 1.751 0 3.581.313 3.581.313V10.5h-2.017c-1.986 0-2.607 1.232-2.607 2.498V16h4.437l-.709 4.625h-3.728v11.18C26.15 30.607 32 23.986 32 16Z"
    }
  ), /* @__PURE__ */ v.createElement(
    "path",
    {
      fill: "none",
      d: "M22.227 20.625 22.936 16h-4.438v-3c0-1.267.619-2.5 2.608-2.5h2.017V6.565s-1.83-.313-3.582-.313c-3.655 0-6.044 2.214-6.044 6.224V16H9.434v4.625h4.063v11.18a16.11 16.11 0 0 0 5.001 0v-11.18h3.729Z"
    }
  )),
  /* @__PURE__ */ v.createElement("defs", null, /* @__PURE__ */ v.createElement("clipPath", { id: "a" }, /* @__PURE__ */ v.createElement("path", { fill: "none", d: "M0 0h32v32H0z" })))
);
export {
  yg as AdvisorDropdown,
  gg as AdvisorDropdownMenuItem,
  wg as AdvisorUnassigned,
  wd as Button,
  pg as ButtonGroup,
  jd as DropdownItem,
  Fg as Facebook,
  Ag as FooterLinks,
  Rg as FooterSection,
  Dg as FooterSmallLinks,
  Bg as FooterSocialLinkBlock,
  qg as FooterSocialLinks,
  $g as Germany,
  mg as Header,
  Qn as HeaderButton,
  Pg as Headline,
  Tg as Hero,
  Vg as Instagram,
  kg as LanguageSelector,
  xg as Location,
  wl as Menu,
  hg as NavItem,
  Mg as NewsletterSubscription,
  Lg as Pinterest,
  _g as ProductStripe,
  Og as Rezeptwelt,
  tn as Search,
  bg as SectionSeparator,
  Eg as ShoppingCart,
  ir as Theme,
  st as Typography,
  Sg as User,
  Cg as Vorwerk,
  Ng as Youtube
};
